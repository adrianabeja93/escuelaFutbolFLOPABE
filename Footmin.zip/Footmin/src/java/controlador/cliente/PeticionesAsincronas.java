/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.cliente;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.entidades.Jugador;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "PeticionesAsincronas", urlPatterns = {"/PeticionesAsincronas"})
public class PeticionesAsincronas extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=ISO-8859-15");

        //PARA SABER QUE FUNCION VAMOS A EJECUTAR
        String function = request.getParameter("fn");
        //para que no de nunca nullpointerexception
        if (function == null) {
            function = "";
        }

        //FUNCIONES DEL CLIENTE
        //funcion para saber si el usuario existe ya o no en la bbdd
        if (function.equals("existeUsuario")) {
            metodosSQL msql = new metodosSQL();
            String data = request.getParameter("data");
            if (data == null) {
                data = "";
            }
            String result;

            try {
                result = msql.existeCliente(data).getNombreUsuario();
                result = "Este nombre de usuario ya está en uso";

            } catch (NullPointerException e) {
                result = "Nombre de usuario disponible";
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //FUNCIONES DEL JUGADOR
        //función para dar de alta en la aplicación a un nuevo jugador
        if (function.equals("crearJugador")) {
            metodosSQL msql = new metodosSQL();

            String nombre = request.getParameter("nombre");

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

            //el usuario va a meter los dos apellidos dentro de un mismo campo
            //entonces los separaremos por un delimitador que será el espacio
            //para poder guardalos por separados en la BBDD
            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellidos").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            String dni = request.getParameter("dni");
            String nacimiento = request.getParameter("nacimiento");

            if (dni == null) {
                dni = "";
            }
            String result;

            Jugador j = new Jugador();
            j.setActivo(1);
            j.setNombre(nombre);
            j.setApellido1(ape1);
            j.setApellido2(ape2);
            j.setDni(dni);

            try {
                j.setFechaNacimiento(formatoFecha.parse(nacimiento));
            } catch (ParseException ex) {
                System.err.println("Error al formatear fecha");
            }

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            j.setTutorLegal(c);

            msql.crearJugador(j);

            result = "Se ha inscrito al nuevo jugador";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //función para ver los jugadores de un cliente
        if (function.equals("listarJugadores")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            //EN ESTA LISTA IREMOS GUARDANDO LOS JUGADORES EN FORMATO JSON
            List<Jugador> jugadores = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            result = msql.listajugadoresCliente(c);
            jugadores = msql.listajugadoresCliente(c);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                //PARA TRANSFORMAR NUESTROS OBJETOS JAVA A JSON
                //LA BIBLIOTECA GSON NO FUNCIONA SI UN OBJETO TIENE DEPENDENCIA DE OTRO
                //ASÍ QUE MOMENTANEAMENTE DEJAREMOS EL TUTOR LEGAL A NULL
                jugador.setTutorLegal(null);
            }

            //AHORA SI PODREMOS REALIZAR LA CONVERSIÓN
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
