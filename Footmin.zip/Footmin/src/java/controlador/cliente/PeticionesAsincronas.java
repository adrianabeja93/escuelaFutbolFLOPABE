/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.cliente;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.NoResultException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.entidades.ClienteClub;
import modelo.entidades.Club;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoJugador;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorEntrenamiento;
import modelo.entidades.Partido;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "PeticionesAsincronas", urlPatterns = {"/PeticionesAsincronas"})
public class PeticionesAsincronas extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=ISO-8859-15");

        //PARA SABER QUE FUNCION VAMOS A EJECUTAR
        String function = request.getParameter("fn");
        //para que no de nunca nullpointerexception
        if (function == null) {
            function = "";
        }

        //FUNCIONES DEL CLIENTE
        //funcion para saber si el usuario existe ya o no en la bbdd
        if (function.equals("existeUsuario")) {
            metodosSQL msql = new metodosSQL();
            String data = request.getParameter("data");
            if (data == null) {
                data = "";
            }
            String result;

            try {
                result = msql.getCliente(data).getNombreUsuario();
                result = "Este nombre de usuario ya está en uso";

            } catch (NullPointerException e) {
                result = "Nombre de usuario disponible";
            }
            //Vamos a comprobar que el nombre de usuario no esté creado en ninguna de las dos tablas de logueo
            if (result.equals("Nombre de usuario disponible")) {
                try {
                    result = msql.getEmpleado(data).getNombreUsuario();
                    result = "Este nombre de usuario ya está en uso";

                } catch (NullPointerException e) {
                    result = "Nombre de usuario disponible";
                }
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("datosUsuario")) {
            metodosSQL msql = new metodosSQL();
            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            Gson gson = new Gson();

            c.setClienteClubCollection(null);
            c.setJugadorCollection(null);

            String json = gson.toJson(c);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("modificaCampo")) {
            metodosSQL msql = new metodosSQL();
            Cliente c = (Cliente) request.getSession().getAttribute("usuario");
            c = msql.getCliente(c.getNombreUsuario());
            String result = "Campo editado correctamente";
            String campo = request.getParameter("campo");
            String valor = request.getParameter("valor");

            if (campo.equals("nombre")) {
                c.setNombre(valor);

            } else if (campo.equals("apellidos")) {
                String apellidos[];
                apellidos = new String[2];
                apellidos = valor.split(" ");
                String ape1 = apellidos[0];
                String ape2;

                try {
                    ape2 = apellidos[1];
                } catch (ArrayIndexOutOfBoundsException e) {
                    ape2 = "";
                }
                c.setApellido1(ape1);
                c.setApellido2(ape2);
            } else if (campo.equals("dni")) {
                c.setDni(valor);
            } else if (campo.equals("fechaNacimiento")) {
                try {
                    SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
                    c.setFechaNacimiento(formatoFecha.parse(valor));
                } catch (ParseException ex) {
                    System.err.println("Error al formatear fecha");
                }
            } else if (campo.equals("password")) {
                String pass = null;
                try {
                    pass = msql.codificarSHA256(valor);
                } catch (NoSuchAlgorithmException ex) {
                    System.err.println("Error al cifrar contraseña");
                }
                c.setPassword(pass);
            } else if (campo.equals("telefono")) {
                c.setTelefono(valor);
            } else if (campo.equals("email")) {
                c.setEmail(valor);
            }

            try {
                msql.editCliente(c);
                //para que se nos actualice el usuario al instante volvermos a meterlo en una variable de sesion, ya editado
                request.getSession().setAttribute("usuario", c);
            } catch (Exception ex) {
                Logger.getLogger(PeticionesAsincronas.class.getName()).log(Level.SEVERE, null, ex);
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

//        ------------------------------------------------------------------------
//        ----------------------FUNCIONES MIS JUGADORES---------------------------
//        ------------------------------------------------------------------------
        //función para dar de alta en la aplicación a un nuevo jugador
        if (function.equals("crearJugador")) {
            metodosSQL msql = new metodosSQL();

            String nombre = request.getParameter("nombre");

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

            //el usuario va a meter los dos apellidos dentro de un mismo campo
            //entonces los separaremos por un delimitador que será el espacio
            //para poder guardalos por separados en la BBDD
            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellidos").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            String dni = request.getParameter("dni");
            String nacimiento = request.getParameter("nacimiento");

            if (dni == null) {
                dni = "";
            }
            String result;

            Jugador j = new Jugador();
            j.setActivo(1);
            j.setNombre(nombre);
            j.setApellido1(ape1);
            j.setApellido2(ape2);
            j.setDni(dni);

            try {
                j.setFechaNacimiento(formatoFecha.parse(nacimiento));
            } catch (ParseException ex) {
                System.err.println("Error al formatear fecha");
            }

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            j.setTutorLegal(c);

            msql.crearJugador(j);

            result = "Se ha inscrito al nuevo jugador";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //funcion para asociarse a un nuevo club
        if (function.equals("nuevoClub")) {
            metodosSQL msql = new metodosSQL();
            String cod = request.getParameter("codigo");
            String result = null, temporada = null;
            Club c = null;
            ClienteClub cc = null;
            Cliente cliente = (Cliente) request.getSession().getAttribute("usuario");
            temporada = msql.calculaTemporada(new Date());
            ClienteClub cc2 = new ClienteClub();

            try {
                c = msql.getClub(cod);
                try {
                    result = "Ya estás registrado en este club";
                    cc = msql.getClienteClub(cliente, c, temporada);
                    System.out.println(cc);
                } catch (NoResultException e) {
                    //significará que no hay vinculación entre el club y el cliente esta temporada.
                    cc2.setClub(c);
                    cc2.setUsuario(cliente);
                    cc2.setTemporada(temporada);
                    msql.crearClienteClub(cc2);
                    result = "Te has inscrito en un nuevo club";
                }
            } catch (NoResultException e) {
                result = "El código de club es erroneo";

            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //función para ver los jugadores de un cliente
        if (function.equals("listarJugadores")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            //EN ESTA LISTA IREMOS GUARDANDO LOS JUGADORES EN FORMATO JSON
            List<Jugador> jugadores = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            result = msql.listajugadoresCliente(c);
            jugadores = msql.listajugadoresCliente(c);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                //PARA TRANSFORMAR NUESTROS OBJETOS JAVA A JSON
                //LA BIBLIOTECA GSON NO FUNCIONA SI UN OBJETO TIENE DEPENDENCIA DE OTRO
                //ASÍ QUE MOMENTANEAMENTE DEJAREMOS EL TUTOR LEGAL A NULL
                jugador.setTutorLegal(null);
                jugador.setJugadorEntrenamientoCollection(null);
                jugador.setEquipoJugadorCollection(null);
                jugador.setJugadorPartidoCollection(null);
            }

            //AHORA SI PODREMOS REALIZAR LA CONVERSIÓN
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //VER LOS DATOS PERSONALES DE UN JUGADOR
        if (function.equals("datosPersonalesJugador")) {
            metodosSQL msql = new metodosSQL();

            Jugador j;

            int id = Integer.parseInt(request.getParameter("idJugador"));

            j = msql.getJugador(id);
            j.setTutorLegal(null);
            j.setJugadorEntrenamientoCollection(null);
            j.setJugadorPartidoCollection(null);
            j.setEquipoJugadorCollection(null);

            Gson gson = new Gson();
            String json = gson.toJson(j);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //VER EL CLUB Y EQUIPO DE UN JUGADOR
        if (function.equals("clubCategoria")) {
            metodosSQL msql = new metodosSQL();
            Jugador j;
            int id = Integer.parseInt(request.getParameter("idJugador"));
            String temporada = msql.calculaTemporada(new Date());

            j = msql.getJugador(id);

            List<Object> clubEquipo = msql.getEquipoClubJugador(j, temporada);

            Gson gson = new Gson();
            String json = gson.toJson(clubEquipo);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //EDITAR DATOS PERSONALES DEL JUGADOR
        if (function.equals("editarJugador")) {
            metodosSQL msql = new metodosSQL();

            Jugador j;

            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellidos").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            int id = Integer.parseInt(request.getParameter("idJugador"));

            j = msql.getJugador(id);

            j.setNombre(request.getParameter("nombre"));
            j.setApellido1(ape1);
            j.setApellido2(ape2);
            j.setDni(request.getParameter("dni"));

            msql.editJugador(j);

            String result = "Se ha editado al jugador correctamente";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("categoriaJugador")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            int idClub = Integer.parseInt(request.getParameter("idClub"));
            Club c = msql.getClub(idClub);

            String result = msql.calculaCategoria(j.getFechaNacimiento());

            List<Equipo> equipos = msql.getEquiposClubCategoria(c, result);

            Gson gson = new Gson();
            for (Equipo eq : equipos) {
                eq.setClub(null);
                eq.setEquipoEmpleadoCollection(null);
                eq.setEquipoJugadorCollection(null);
            }

            String json = gson.toJson(equipos);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("vinculaEquipo")) {
            metodosSQL msql = new metodosSQL();
            int idJugador = Integer.parseInt(request.getParameter("idJugador"));
            int idEquipo = Integer.parseInt(request.getParameter("idEquipo"));
            String temporada = msql.calculaTemporada(new Date());
            Equipo e = msql.getEquipo(idEquipo);
            Jugador j = msql.getJugador(idJugador);
            String result = null;

            EquipoJugador equipoJugador = new EquipoJugador();
            equipoJugador.setEquipo(e);
            equipoJugador.setJugador(j);
            equipoJugador.setTemporada(temporada);

            try {
                msql.crearEquipoJugador(equipoJugador);
                result = "Se ha vinculado el jugador al equipo";
            } catch (Exception ex) {
                result = "No se ha podido vincular el jugador al club";
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

//        ------------------------------------------------------------------------
//        ----------------------FUNCIONES ENTRENAMIENTOS--------------------------
//        ------------------------------------------------------------------------
        //función para ver los proximos entrenos de los jugadores de un cliente
        if (function.equals("proximosEntrenamientosCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            Date fechaActual = new Date();

            result = msql.proximosEntrenamientosCliente(c.getNombreUsuario(), fechaActual);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            System.out.println(json);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para obtener las temporadas del cliente en la aplicacion
        if (function.equals("temporadasCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            result = msql.temporadasCliente(c);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            System.out.println(json);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para obtener la asistencia de un jugador en un mes
        if (function.equals("asistenciaJugador")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;
            int idJug = Integer.parseInt(request.getParameter("id"));
            int mes = Integer.parseInt(request.getParameter("mes"));
            Jugador jugador = msql.getJugador(idJug);
            int year;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            String año[];
            año = new String[2];
            año = request.getParameter("temporada").split("/");
            String año1 = año[0];
            String año2 = año[1];

            Calendar primeroMes = Calendar.getInstance();
            Calendar ultimoMes = Calendar.getInstance();

            //una temporada de fútbol empieza desde agosto y dura hasta junio
            //es decir la temporada 2019/2020 empezaria en Agosto de 2019 y acabaría en Junio de 2020
            //como para la busqueda necesitamos el año si el mes es menor de 7 cogeremos el segundo año del parametro temporada ya que estaremos a mitad de temporada
            //si por el contrario el mes es mayor cogeremos el primer año del parametro temporada
            if (mes < 7) {
                year = Integer.parseInt(año2);
                primeroMes.set(Calendar.YEAR, year);
                ultimoMes.set(Calendar.YEAR, year);
            } else if (mes > 7) {
                year = Integer.parseInt(año1);
                primeroMes.set(Calendar.YEAR, year);
                ultimoMes.set(Calendar.YEAR, year);
            }

            //meses con 31 días
            if (mes == 0 || mes == 2 || mes == 4 || mes == 6 || mes == 7 || mes == 9 || mes == 11) {
                primeroMes.set(Calendar.MONTH, mes);
                primeroMes.set(Calendar.DAY_OF_MONTH, 1);

                ultimoMes.set(Calendar.MONTH, mes);
                ultimoMes.set(Calendar.DAY_OF_MONTH, 31);
            }

            //meses con 30 días
            if (mes == 3 || mes == 5 || mes == 8 || mes == 10) {
                primeroMes.set(Calendar.MONTH, mes);
                primeroMes.set(Calendar.DAY_OF_MONTH, 1);

                ultimoMes.set(Calendar.MONTH, mes);
                ultimoMes.set(Calendar.DAY_OF_MONTH, 30);
            }

            //febrero
            if (mes == 1) {
                primeroMes.set(Calendar.MONTH, mes);
                primeroMes.set(Calendar.DAY_OF_MONTH, 1);

                ultimoMes.set(Calendar.MONTH, mes);
                ultimoMes.set(Calendar.DAY_OF_MONTH, 28);
            }

            //gettime me devuelve un DATE
            result = msql.entrenosJugador(jugador, primeroMes.getTime(), ultimoMes.getTime());

            Gson gson = new Gson();

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //AÑADIR JUSTIFICACION
        if (function.equals("justificacion")) {
            metodosSQL msql = new metodosSQL();
            Long id = Long.parseLong(request.getParameter("idSesion"));

            JugadorEntrenamiento je;

            je = msql.getJugadorEntrenamiento(id);

            je.setJustificacion(request.getParameter("justificacion"));
            je.setJustificado(1);

            msql.editJugadorEntrenamiento(je);

            String result = "Falta de asistencia justificada";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //función para ver los proximos partidos de los jugadores de un cliente
        if (function.equals("proximosPartidosCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            Date fechaActual = new Date();

            result = msql.proximosPartidosCliente(c, fechaActual);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            System.out.println(json);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para ver los ultimos partidos de los jugadores de un cliente
        if (function.equals("ultimosPartidosCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            Date fechaActual = new Date();

            result = msql.ultimosPartidosCliente(c, fechaActual);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            System.out.println(json);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para obtener los clubes a los que está vinculado un cliente
        if (function.equals("clubesCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Club> result = null;

            Cliente c = (Cliente) request.getSession().getAttribute("usuario");

            result = msql.clubesCliente(c);

            Gson gson = new Gson();
            for (Club club : result) {
                club.setClienteClubCollection(null);
                club.setClubEmpleadoCollection(null);
                club.setEquipoCollection(null);

            }

            //AHORA SI PODREMOS REALIZAR LA CONVERSIÓN
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para ver los partidos de un club vinculado a un cliente
        if (function.equals("partidosCliente")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;
            String temporada, jornada, categoria, club;
            temporada = request.getParameter("temporada");
            jornada = request.getParameter("jornada");
            categoria = request.getParameter("categoria");
            club = request.getParameter("club");

            result = msql.partidosCliente(temporada, categoria, jornada, club);

            Gson gson = new Gson();

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para ver la convocatoria
        if (function.equals("convocados")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            Long id = Long.parseLong(request.getParameter("idPartido"));

            Partido p = msql.getPartido(id);

            result = msql.convocados(p);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                jugador.setTutorLegal(null);
                jugador.setJugadorEntrenamientoCollection(null);
                jugador.setEquipoJugadorCollection(null);
                jugador.setJugadorPartidoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //función para ver la no convocatoria
        if (function.equals("noConvocados")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            Long id = Long.parseLong(request.getParameter("idPartido"));

            Partido p = msql.getPartido(id);

            result = msql.noConvocados(p);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                jugador.setTutorLegal(null);
                jugador.setJugadorEntrenamientoCollection(null);
                jugador.setEquipoJugadorCollection(null);
                jugador.setJugadorPartidoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //funcion para conseguir ell resumen de un partido
        if (function.equals("resumen")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;
            Long id = Long.parseLong(request.getParameter("idPartido"));

            Partido p = msql.getPartido(id);

            result = msql.resumenPartido(p);

            Gson gson = new Gson();
            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver los clubes asociados de un cliente 
        if (function.equals("clubesAsociados")) {
            metodosSQL msql = new metodosSQL();
            List<Club> result = null;
            Cliente c = (Cliente) request.getSession().getAttribute("usuario");
            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoClub(c, temporada);

            Gson gson = new Gson();

            for (Club club : result) {
                club.setClienteClubCollection(null);
                club.setClubEmpleadoCollection(null);
                club.setEquipoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numEquipos")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));

            c = msql.getClub(id);

            result = msql.numEquiposClub(c);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numJugTemp")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));
            String temporada = null;
            Date date = new Date();

            c = msql.getClub(id);
            temporada = msql.calculaTemporada(date);

            result = msql.numJugadoresClubTemporada(c, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
