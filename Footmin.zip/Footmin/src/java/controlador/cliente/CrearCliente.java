/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.cliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "CrearCliente", urlPatterns = {"/CrearCliente"})
public class CrearCliente extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nomUsu = request.getParameter("nombreUsuario");

        if (nomUsu != null) {

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

            //el usuario va a meter los dos apellidos dentro de un mismo campo
            //entonces los separaremos por un delimitador que será el espacio
            //para poder guardalos por separados en la BBDD
            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellido").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            metodosSQL msql = new metodosSQL();

            Cliente cc = msql.getCliente(nomUsu);

            if (cc == null) {
                Cliente c = new Cliente();
                c.setNombreUsuario(nomUsu);
                c.setNombre(request.getParameter("nombre"));

                String pass = null;
                try {
                    //guardamos contraseña cifrada en la BBDD para más seguridad
                    pass = msql.codificarSHA256(request.getParameter("pass"));
                } catch (NoSuchAlgorithmException ex) {
                    System.err.println("Error al cifrar contraseña");
                }
                c.setPassword(pass);

                c.setApellido1(ape1);
                c.setApellido2(ape2);

                c.setDni(request.getParameter("dni"));
                c.setEmail(request.getParameter("email"));
                c.setActivo(1);
                c.setTelefono(request.getParameter("tlf"));
                try {
                    c.setFechaNacimiento(formatoFecha.parse(request.getParameter("fechaNacimiento")));
                } catch (ParseException ex) {
                    System.err.println("Error al formatear fecha");
                }

                msql.crearCliente(c);

                response.sendRedirect("cliente/principalCliente.jsp");
                return;

            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
