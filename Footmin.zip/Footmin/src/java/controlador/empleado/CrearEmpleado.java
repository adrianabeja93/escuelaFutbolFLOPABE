/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.empleado;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Empleado;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "CrearEmpleado", urlPatterns = {"/CrearEmpleado"})
public class CrearEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nomUsu = request.getParameter("nombreUsuario");

        if (nomUsu != null) {

            //el usuario va a meter los dos apellidos dentro de un mismo campo
            //entonces los separaremos por un delimitador que será el espacio
            //para poder guardalos por separados en la BBDD
            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellido").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            metodosSQL msql = new metodosSQL();

            Empleado ee = msql.getEmpleado(nomUsu);

            if (ee == null) {
                Empleado e = new Empleado();
                e.setNombreUsuario(nomUsu);
                e.setNombre(request.getParameter("nombre"));

                String pass = null;
                try {
                    //guardamos contraseña cifrada en la BBDD para más seguridad
                    pass = msql.codificarSHA256(request.getParameter("pass"));
                } catch (NoSuchAlgorithmException ex) {
                    System.err.println("Error al cifrar contraseña");
                }
                e.setPassword(pass);
                e.setApellido1(ape1);
                e.setApellido2(ape2);
                e.setTipo("Administrador");
                e.setDni(request.getParameter("dni"));
                e.setEmail(request.getParameter("email"));
                e.setActivo(1);
                e.setTitulacion(request.getParameter("titulacion"));
                e.setTelefono(request.getParameter("tlf"));
                

                msql.crearEmpleado(e);

                response.sendRedirect("administrador/principalAdministrador.jsp");
                return;

            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
