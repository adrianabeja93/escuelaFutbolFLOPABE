/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.empleado;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.NoResultException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.entidades.Club;
import modelo.entidades.ClubEmpleado;
import modelo.entidades.Empleado;
import modelo.entidades.Entrenamiento;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoJugador;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorEntrenamiento;
import modelo.entidades.Partido;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "PeticionesAsincronasEmpleado", urlPatterns = {"/PeticionesAsincronasEmpleado"})
public class PeticionesAsincronasEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=ISO-8859-15");

        //PARA SABER QUE FUNCION VAMOS A EJECUTAR
        String function = request.getParameter("fn");
        //para que no de nunca nullpointerexception
        if (function == null) {
            function = "";
        }

        //funcion para ver el club asociado a un empleado 
        if (function.equals("clubEmpleado")) {
            metodosSQL msql = new metodosSQL();
            List<Club> result = null;
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoClub(e, temporada);

            Gson gson = new Gson();

            for (Club club : result) {
                club.setClienteClubCollection(null);
                club.setClubEmpleadoCollection(null);
                club.setEquipoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numEquipos")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));

            c = msql.getClub(id);

            result = msql.numEquiposClub(c);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numJugTemp")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));
            String temporada = null;
            Date date = new Date();

            c = msql.getClub(id);
            temporada = msql.calculaTemporada(date);

            result = msql.numJugadoresClubTemporada(c, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("crearClub")) {
            metodosSQL msql = new metodosSQL();
            Club c = new Club();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            SimpleDateFormat fecha = new SimpleDateFormat("yyyy-MM-dd");
            String codigo = request.getParameter("codigo");
            String nombre = request.getParameter("nombre");
            String result;

            //vamos a controlar que en la BBDD no existan un club con el mismo nombre ni con el mismo código
            try {
                Club caux = msql.getClubNombre(nombre);
                result = "Este nombre de club ya está siendo utilizado en nuestro servidores";
            } catch (NoResultException ex) {
                try {
                    Club caux2 = msql.getClub(codigo);
                    result = "Este código de club ya está siendo utilizado en nuestro servidores";
                } catch (NoResultException exx) {
                    c.setNombre(nombre);
                    c.setDireccion(request.getParameter("direccion"));
                    c.setEstadio(request.getParameter("estadio"));
                    c.setEmail(request.getParameter("email"));
                    c.setCodClub(codigo);
                    c.setTelefono(request.getParameter("telefono"));
                    try {
                        c.setFechaFundacion(fecha.parse(request.getParameter("fechaFundacion")));
                    } catch (ParseException pex) {
                        Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, pex);
                    }

                    msql.crearClub(c);
                    result = "Se ha registrado el club correctamente";
                }
            }
            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("vinculaClubAdmin")) {
            metodosSQL msql = new metodosSQL();
            Club c = new Club();
            ClubEmpleado ce = new ClubEmpleado();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            String temporada;
            Date date = new Date();

            temporada = msql.calculaTemporada(date);
            c = msql.getClub(request.getParameter("codigo"));

            ce.setClub(c);
            ce.setTemporada(temporada);
            ce.setEmpleado(e);

            msql.crearClubEmpleado(ce);
        }

        //funcion para ver información relativa al equipo que un empleado dirige actualmente
        if (function.equals("infoEquipo")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoEquipoEmpleado(e, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //función para ver los jugadores de un equipo
        if (function.equals("jugadoresEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            int id = Integer.parseInt(request.getParameter("idEquipo"));
            Equipo e = msql.getEquipo(id);
            Date date = new Date();
            String temporada;

            temporada = msql.calculaTemporada(date);
            result = msql.listajugadoresEquipo(e, temporada);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                //PARA TRANSFORMAR NUESTROS OBJETOS JAVA A JSON
                //LA BIBLIOTECA GSON NO FUNCIONA SI UN OBJETO TIENE DEPENDENCIA DE OTRO
                //ASÍ QUE MOMENTANEAMENTE DEJAREMOS EL TUTOR LEGAL A NULL
                jugador.setTutorLegal(null);
                jugador.setJugadorEntrenamientoCollection(null);
                jugador.setEquipoJugadorCollection(null);
                jugador.setJugadorPartidoCollection(null);
            }

            //AHORA SI PODREMOS REALIZAR LA CONVERSIÓN
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("federado")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            EquipoJugador ej = msql.getEquipoJugador(j, temporada);

            ej.setEquipo(null);
            ej.setJugador(null);

            Gson gson = new Gson();

            String json = gson.toJson(ej);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("partidosDisputados")) {
            metodosSQL msql = new metodosSQL();
            Object num;
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            num = msql.numPartidosJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(num);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("entrenosDisputados")) {
            Object num;
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            num = msql.numEntrenosJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(num);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //para ver las estadisticas de un jugador en una temporada
        if (function.equals("estadisticas")) {
            List<Object> estadisticas;
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            estadisticas = msql.estadisticasJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(estadisticas);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

//        ------------------------------------------------------------------------
//        ----------------------FUNCIONES ENTRENAMIENTOS--------------------------
//        ------------------------------------------------------------------------
        //función para ver los proximos entrenos de un equipo
        if (function.equals("proximosEntrenamientosEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Entrenamiento> result = null;
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");

            Equipo eq = msql.getEquipo(e, temporada);

            result = msql.getProxEntrenamientoEquipo(eq, fechaActual);

            Gson gson = new Gson();

            for (Entrenamiento entrenamiento : result) {
                entrenamiento.setJugadorEntrenamientoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("crearSesion")) {
            metodosSQL msql = new metodosSQL();
            Entrenamiento e = new Entrenamiento();
            SimpleDateFormat fecha = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date inicioSesion = null, finalizacionSesion = null;
            String result, temporada;
            temporada = msql.calculaTemporada(new Date());
            Empleado empleado = (Empleado) request.getSession().getAttribute("usuario");

            try {
                inicioSesion = fecha.parse(request.getParameter("fecha") + " " + request.getParameter("horaInicio"));
            } catch (ParseException ex) {
                Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                finalizacionSesion = fecha.parse(request.getParameter("fecha") + " " + request.getParameter("horaFinalizacion"));
            } catch (ParseException ex) {
                Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, ex);
            }

            e.setFechaHoraComienzo(inicioSesion);
            e.setFechaHoraFinalizacion(finalizacionSesion);
            e.setComentarioSesion(request.getParameter("descripcion"));
            e.setSuspendido(0);

            msql.crearEntrenamiento(e);

            //toca añadir los jugadores a la sesión
            Entrenamiento entreno = msql.getEntrenamiento(e.getIdEntrenamiento());

            //para saber que equipo entrena el empleado
            Equipo equipoEmpleado = msql.getEquipo(empleado, temporada);

            //CONSEGUIMOS los jugadores de ese equipo
            List<Jugador> jugadores = msql.listajugadoresEquipo(equipoEmpleado, temporada);

            //y ahora añadimos los jugadores a la sesión que hemos creado
            for (Jugador jugador : jugadores) {
                JugadorEntrenamiento je = new JugadorEntrenamiento();
                System.out.println(jugador);
                je.setEntrenamiento(entreno);
                je.setAsiste(0);
                je.setJugador(jugador);
                msql.crearJugadorEntrenamiento(je);
            }

            result = "Se ha creado la nueva sesión de entrenamiento";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("suspenderSesion")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("id"));

            Entrenamiento e = msql.getEntrenamiento(id);

            e.setSuspendido(1);

            msql.editEntrenamiento(e);
        }

        if (function.equals("sesionesTemporada")) {

            metodosSQL msql = new metodosSQL();
            List<Entrenamiento> result = null;

            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            String temp = msql.calculaTemporada(new Date());

            //cogemos el equipo que dirige el empleado esa temporada
            Equipo eq = msql.getEquipo(e, temp);

            result = msql.getEntrenamientoEquipoTemp(eq, temp);

            Gson gson = new Gson();

            for (Entrenamiento entreno : result) {
                entreno.setJugadorEntrenamientoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("asistenciaEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;
            int id = Integer.parseInt(request.getParameter("id"));

            Entrenamiento e = msql.getEntrenamiento(id);

            result = msql.getAsistenciaSesion(e);

            Gson gson = new Gson();
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("descripcion")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idSesion"));
            Entrenamiento e = msql.getEntrenamiento(id);
            String result = "Añadida descripción";

            e.setDescripcionSesion(request.getParameter("descripcion"));
            msql.editEntrenamiento(e);

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("modificaAsistencia")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("id"));
            JugadorEntrenamiento je = msql.getJugadorEntrenamiento(id);

            if (je.getAsiste() == 0) {
                je.setAsiste(1);
            } else {
                je.setAsiste(0);
            }

            msql.editJugadorEntrenamiento(je);

        }

        if (function.equals("comportamiento")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idSesion"));
            JugadorEntrenamiento je = msql.getJugadorEntrenamiento(id);
            String result = "Añadido comportamiento";

            je.setComportamientoJugador(request.getParameter("comportamiento"));
            msql.editJugadorEntrenamiento(je);

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("proximosPartidosEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Partido> result = null;
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");

            Equipo eq = msql.getEquipo(e, temporada);

            result = msql.getProximosPartidosEquipo(eq, fechaActual);

            Gson gson = new Gson();

            for (Partido partido : result) {
                partido.setJugadorPartidoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("club")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);
            
            
            Gson gson = new Gson();

            c.setClienteClubCollection(null);
            c.setClubEmpleadoCollection(null);
            c.setEquipoCollection(null);

            String json = gson.toJson(c);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
