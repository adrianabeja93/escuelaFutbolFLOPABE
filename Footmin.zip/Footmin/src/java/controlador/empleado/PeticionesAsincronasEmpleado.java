/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.empleado;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.entidades.Club;
import modelo.entidades.Empleado;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "PeticionesAsincronasEmpleado", urlPatterns = {"/PeticionesAsincronasEmpleado"})
public class PeticionesAsincronasEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //PARA SABER QUE FUNCION VAMOS A EJECUTAR
        String function = request.getParameter("fn");
        //para que no de nunca nullpointerexception
        if (function == null) {
            function = "";
        }

        //funcion para ver el club asociado a un empleado 
        if (function.equals("clubEmpleado")) {
            metodosSQL msql = new metodosSQL();
            List<Club> result = null;
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoClub(e, temporada);

            Gson gson = new Gson();

            for (Club club : result) {
                club.setClienteClubCollection(null);
                club.setClubEmpleadoCollection(null);
                club.setEquipoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numEquipos")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));

            c = msql.getClub(id);

            result = msql.numEquiposClub(c);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numJugTemp")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));
            String temporada = null;
            Date date = new Date();

            c = msql.getClub(id);
            temporada = msql.calculaTemporada(date);

            result = msql.numJugadoresClubTemporada(c, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
