/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.empleado;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.NoResultException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.entidades.Cliente;
import modelo.entidades.Club;
import modelo.entidades.ClubEmpleado;
import modelo.entidades.Empleado;
import modelo.entidades.Entrenamiento;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoEmpleado;
import modelo.entidades.EquipoJugador;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorEntrenamiento;
import modelo.entidades.JugadorPartido;
import modelo.entidades.Partido;
import modelo.metodosSQL;

/**
 *
 * @author adrian
 */
@WebServlet(name = "PeticionesAsincronasEmpleado", urlPatterns = {"/PeticionesAsincronasEmpleado"})
public class PeticionesAsincronasEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=ISO-8859-15");

        //PARA SABER QUE FUNCION VAMOS A EJECUTAR
        String function = request.getParameter("fn");
        //para que no de nunca nullpointerexception
        if (function == null) {
            function = "";
        }

        //funcion para ver el club asociado a un empleado 
        if (function.equals("clubEmpleado")) {
            metodosSQL msql = new metodosSQL();
            List<Club> result = null;
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoClub(e, temporada);

            Gson gson = new Gson();

            for (Club club : result) {
                club.setClienteClubCollection(null);
                club.setClubEmpleadoCollection(null);
                club.setEquipoCollection(null);
            }

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numEquipos")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));

            c = msql.getClub(id);

            result = msql.numEquiposClub(c);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //funcion para ver el numero de equipos de un club
        if (function.equals("numJugTemp")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Club c = null;
            int id = Integer.parseInt(request.getParameter("idClub"));
            String temporada = null;
            Date date = new Date();

            c = msql.getClub(id);
            temporada = msql.calculaTemporada(date);

            result = msql.numJugadoresClubTemporada(c, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("crearClub")) {
            metodosSQL msql = new metodosSQL();
            Club c = new Club();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            SimpleDateFormat fecha = new SimpleDateFormat("yyyy-MM-dd");
            String codigo = request.getParameter("codigo");
            String nombre = request.getParameter("nombre");
            String result;

            //vamos a controlar que en la BBDD no existan un club con el mismo nombre ni con el mismo código
            try {
                Club caux = msql.getClubNombre(nombre);
                result = "Este nombre de club ya está siendo utilizado en nuestro servidores";
            } catch (NoResultException ex) {
                try {
                    Club caux2 = msql.getClub(codigo);
                    result = "Este código de club ya está siendo utilizado en nuestro servidores";
                } catch (NoResultException exx) {
                    c.setNombre(nombre);
                    c.setDireccion(request.getParameter("direccion"));
                    c.setEstadio(request.getParameter("estadio"));
                    c.setEmail(request.getParameter("email"));
                    c.setCodClub(codigo);
                    c.setTelefono(request.getParameter("telefono"));
                    try {
                        c.setFechaFundacion(fecha.parse(request.getParameter("fechaFundacion")));
                    } catch (ParseException pex) {
                        Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, pex);
                    }

                    msql.crearClub(c);
                    result = "Se ha registrado el club correctamente";
                }
            }
            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("vinculaClubAdmin")) {
            metodosSQL msql = new metodosSQL();
            Club c = new Club();
            ClubEmpleado ce = new ClubEmpleado();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            String temporada;
            Date date = new Date();

            temporada = msql.calculaTemporada(date);
            c = msql.getClub(request.getParameter("codigo"));

            ce.setClub(c);
            ce.setTemporada(temporada);
            ce.setEmpleado(e);

            msql.crearClubEmpleado(ce);
        }

        //funcion para ver información relativa al equipo que un empleado dirige actualmente
        if (function.equals("infoEquipo")) {
            metodosSQL msql = new metodosSQL();
            Object result = null;
            Empleado e;
            String empleado = request.getParameter("idEmpleado");
            //vamos a utilizar la misma funcion para el empleado de la función o para cualquier otro así que...
            if (empleado == null) {
                //si no se manda id por parametro entonces cogeremos al empleado de la sesion
                e = (Empleado) request.getSession().getAttribute("usuario");
            } else {
                e = msql.getEmpleado(empleado);
            }

            Date d = new Date();
            String temporada;
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");

            temporada = msql.calculaTemporada(d);

            result = msql.infoEquipoEmpleado(e, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(result);
            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //función para ver los jugadores de un equipo
        if (function.equals("jugadoresEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Jugador> result = null;
            int id = Integer.parseInt(request.getParameter("idEquipo"));
            Equipo e = msql.getEquipo(id);
            Date date = new Date();
            String temporada;

            temporada = msql.calculaTemporada(date);
            result = msql.listajugadoresEquipo(e, temporada);

            Gson gson = new Gson();
            for (Jugador jugador : result) {
                //PARA TRANSFORMAR NUESTROS OBJETOS JAVA A JSON
                //LA BIBLIOTECA GSON NO FUNCIONA SI UN OBJETO TIENE DEPENDENCIA DE OTRO
                //ASÍ QUE MOMENTANEAMENTE DEJAREMOS EL TUTOR LEGAL A NULL
                jugador.setTutorLegal(null);
                jugador.setJugadorEntrenamientoCollection(null);
                jugador.setEquipoJugadorCollection(null);
                jugador.setJugadorPartidoCollection(null);
            }

            //AHORA SI PODREMOS REALIZAR LA CONVERSIÓN
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("federado")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            EquipoJugador ej = msql.getEquipoJugador(j, temporada);

            ej.setEquipo(null);
            ej.setJugador(null);

            Gson gson = new Gson();

            String json = gson.toJson(ej);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("partidosDisputados")) {
            metodosSQL msql = new metodosSQL();
            Object num;
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            num = msql.numPartidosJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(num);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("entrenosDisputados")) {
            Object num;
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            num = msql.numEntrenosJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(num);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //para ver las estadisticas de un jugador en una temporada
        if (function.equals("estadisticas")) {
            List<Object> estadisticas;
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idJugador"));
            Jugador j = msql.getJugador(id);
            Date date = new Date();
            String temporada = msql.calculaTemporada(date);

            estadisticas = msql.estadisticasJugadorTemporada(j, temporada);

            Gson gson = new Gson();

            String json = gson.toJson(estadisticas);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

//        ------------------------------------------------------------------------
//        ----------------------FUNCIONES ENTRENAMIENTOS--------------------------
//        ------------------------------------------------------------------------
        //función para ver los proximos entrenos de un equipo
        if (function.equals("proximosEntrenamientosEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Entrenamiento> result = null;
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");

            Equipo eq = msql.getEquipo(e, temporada);

            result = msql.getProxEntrenamientoEquipo(eq, fechaActual);

            Gson gson = new Gson();

            for (Entrenamiento entrenamiento : result) {
                entrenamiento.setJugadorEntrenamientoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("crearSesion")) {
            metodosSQL msql = new metodosSQL();
            Entrenamiento e = new Entrenamiento();
            SimpleDateFormat fecha = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            Date inicioSesion = null, finalizacionSesion = null;
            String result, temporada;
            temporada = msql.calculaTemporada(new Date());
            Empleado empleado = (Empleado) request.getSession().getAttribute("usuario");

            try {
                inicioSesion = fecha.parse(request.getParameter("fecha") + " " + request.getParameter("horaInicio"));
            } catch (ParseException ex) {
                Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                finalizacionSesion = fecha.parse(request.getParameter("fecha") + " " + request.getParameter("horaFinalizacion"));
            } catch (ParseException ex) {
                Logger.getLogger(PeticionesAsincronasEmpleado.class.getName()).log(Level.SEVERE, null, ex);
            }

            e.setFechaHoraComienzo(inicioSesion);
            e.setFechaHoraFinalizacion(finalizacionSesion);
            e.setComentarioSesion(request.getParameter("descripcion"));
            e.setSuspendido(0);

            msql.crearEntrenamiento(e);

            //toca añadir los jugadores a la sesión
            Entrenamiento entreno = msql.getEntrenamiento(e.getIdEntrenamiento());

            //para saber que equipo entrena el empleado
            Equipo equipoEmpleado = msql.getEquipo(empleado, temporada);

            //CONSEGUIMOS los jugadores de ese equipo
            List<Jugador> jugadores = msql.listajugadoresEquipo(equipoEmpleado, temporada);

            //y ahora añadimos los jugadores a la sesión que hemos creado
            for (Jugador jugador : jugadores) {
                JugadorEntrenamiento je = new JugadorEntrenamiento();
                System.out.println(jugador);
                je.setEntrenamiento(entreno);
                je.setAsiste(0);
                je.setJugador(jugador);
                msql.crearJugadorEntrenamiento(je);
            }

            result = "Se ha creado la nueva sesión de entrenamiento";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("suspenderSesion")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("id"));

            Entrenamiento e = msql.getEntrenamiento(id);

            e.setSuspendido(1);

            msql.editEntrenamiento(e);
        }

        if (function.equals("sesionesTemporada")) {

            metodosSQL msql = new metodosSQL();
            List<Entrenamiento> result = null;

            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            String temp = msql.calculaTemporada(new Date());

            //cogemos el equipo que dirige el empleado esa temporada
            Equipo eq = msql.getEquipo(e, temp);

            result = msql.getEntrenamientoEquipoTemp(eq, temp);

            Gson gson = new Gson();

            for (Entrenamiento entreno : result) {
                entreno.setJugadorEntrenamientoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //VER LA ASISTENCIA A UN ENTRENO DE TODOS LOS JUGADOIRES DEL EQUIPO
        if (function.equals("asistenciaEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Object> result = null;
            int id = Integer.parseInt(request.getParameter("id"));

            Entrenamiento e = msql.getEntrenamiento(id);

            result = msql.getAsistenciaSesion(e);

            Gson gson = new Gson();
            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //AÑADIR DESCRIPCION DE ENTRENAMIENTO
        if (function.equals("descripcion")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idSesion"));
            Entrenamiento e = msql.getEntrenamiento(id);
            String result = "Añadida descripción";

            e.setDescripcionSesion(request.getParameter("descripcion"));
            msql.editEntrenamiento(e);

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //MODIFICAR SI ASISTE AL ENTRENAMIENTO O NO 
        if (function.equals("modificaAsistencia")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("id"));
            JugadorEntrenamiento je = msql.getJugadorEntrenamiento(id);

            if (je.getAsiste() == 0) {
                je.setAsiste(1);
            } else {
                je.setAsiste(0);
            }

            msql.editJugadorEntrenamiento(je);

        }

        //AÑADIR COMPORTAMIENTO A UN JUGADOR EN UNA SESION DE ENTRENO
        if (function.equals("comportamiento")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("idSesion"));
            JugadorEntrenamiento je = msql.getJugadorEntrenamiento(id);
            String result = "Añadido comportamiento";

            je.setComportamientoJugador(request.getParameter("comportamiento"));
            msql.editJugadorEntrenamiento(je);

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        //PROXIMOS PARTIDOS DEL EQUIPO AL QUE PERTENECE EL EMPLEADO
        if (function.equals("proximosPartidosEquipo")) {
            metodosSQL msql = new metodosSQL();
            List<Partido> result = null;
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");

            Equipo eq = msql.getEquipo(e, temporada);

            result = msql.getProximosPartidosEquipo(eq, fechaActual);

            Gson gson = new Gson();

            for (Partido partido : result) {
                partido.setJugadorPartidoCollection(null);
            }

            String json = gson.toJson(result);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //INFORMACION DEL CLUB EN EL QUE ESTA EL EMPLEADO
        if (function.equals("club")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            Gson gson = new Gson();

            c.setClienteClubCollection(null);
            c.setClubEmpleadoCollection(null);
            c.setEquipoCollection(null);

            String json = gson.toJson(c);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //LISTA DE TODOS LOS JUGADORES QUE PUEDEN DISPUTAR UN PARTIDO
        if (function.equals("jugadoresPartido")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            int id = Integer.parseInt(request.getParameter("id"));
            List<Object> jugadores = null;
            Partido p = msql.getPartido(id);
            jugadores = msql.getJugadoresPartido(p);

            Gson gson = new Gson();

            String json = gson.toJson(jugadores);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        //PARA MODIFICAR SI ESTÁ CONVOCADO O NO
        if (function.equals("realizaConvocatoria")) {
            metodosSQL msql = new metodosSQL();
            int id = Integer.parseInt(request.getParameter("id"));
            JugadorPartido jp = msql.getJugadorPartido(id);

            if (jp.getConvocado() == 0) {
                jp.setConvocado(1);
            } else {
                jp.setConvocado(0);
            }

            msql.editJugadorPartido(jp);

        }

        //PARA CONSEGUIR EL NUMERO DE LOS EMPLEADOS DE UN CLUB
        if (function.equals("numEmpleados")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            Object num = msql.numEmpleadoClubTemp(c, temporada);

            Object emp[];
            emp = new Object[2];
            //guardamos el numero de empleados y la temporada para pasarlos
            emp[0] = num;
            emp[1] = temporada;

            Gson gson = new Gson();

            String json = gson.toJson(emp);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //METODO PARA LISTAR TODOS LOS EMPLEADOS DE UN CLUB
        if (function.equals("listarEmpleados")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            List<Empleado> empleados = msql.getEmpleadosClubTemp(c, temporada);

            Gson gson = new Gson();

            for (Empleado emp : empleados) {
                emp.setClubEmpleadoCollection(null);
                emp.setEquipoEmpleadoCollection(null);
            }

            String json = gson.toJson(empleados);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("crearEmpleado")) {
            metodosSQL msql = new metodosSQL();
            String nombre = request.getParameter("nombre");

            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");

            //el usuario va a meter los dos apellidos dentro de un mismo campo
            //entonces los separaremos por un delimitador que será el espacio
            //para poder guardalos por separados en la BBDD
            String apellidos[];
            apellidos = new String[2];
            apellidos = request.getParameter("apellidos").split(" ");
            String ape1 = apellidos[0];
            String ape2;

            //es posible que el usuario tenga un solo apellido
            //controlaremos la excepción
            try {
                ape2 = apellidos[1];
            } catch (ArrayIndexOutOfBoundsException e) {
                ape2 = "";
            }

            String dni = request.getParameter("dni");

            if (dni == null) {
                dni = "";
            }
            String result;

            Empleado e = new Empleado();
            e.setActivo(1);
            e.setNombre(nombre);
            e.setApellido1(ape1);
            e.setApellido2(ape2);
            e.setDni(dni);
            e.setEmail(request.getParameter("email"));
            e.setNombreUsuario(request.getParameter("nomUsu"));
            //codificaremos la contraseña
            String pass = null;
            try {
                //guardamos contraseña cifrada en la BBDD para más seguridad
                pass = msql.codificarSHA256(request.getParameter("pass"));
            } catch (NoSuchAlgorithmException ex) {
                System.err.println("Error al cifrar contraseña");
            }
            e.setPassword(pass);
            e.setTelefono(request.getParameter("tlf"));
            e.setTipo("NoAdmin");
            e.setTitulacion(request.getParameter("formacion"));
            msql.crearEmpleado(e);

            //vamos a vincular el empleado que vamos a crear al club del ADMIN
            Empleado admin = (Empleado) request.getSession().getAttribute("usuario");
            String temporada = msql.calculaTemporada(new Date());
            Club c = msql.getClubEmpleado(admin, temporada);
            ClubEmpleado ce = new ClubEmpleado();
            ce.setClub(c);
            ce.setEmpleado(e);
            ce.setTemporada(temporada);
            msql.crearClubEmpleado(ce);

            result = "Se ha inscrito al nuevo empleado";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }

        }

        //PARA CONSEGUIR EL NUMERO DE EQUIPOS DE UN CLUB
        if (function.equals("numEquiposClub")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            Object num = msql.numEquiposClub(c);

            Object emp[];
            emp = new Object[2];
            //guardamos el numero de empleados y la temporada para pasarlos
            emp[0] = num;
            emp[1] = temporada;

            Gson gson = new Gson();

            String json = gson.toJson(emp);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        //METODO PARA LISTAR TODOS LOS EQUIPOS DE UN CLUB
        if (function.equals("listarEquiposClub")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            List<Equipo> equipos = msql.getEquiposClub(c);

            Gson gson = new Gson();

            for (Equipo eq : equipos) {
                eq.setEquipoEmpleadoCollection(null);
                eq.setEquipoJugadorCollection(null);
                eq.setClub(null);
            }

            String json = gson.toJson(equipos);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("entrenadorEquipo")) {
            metodosSQL msql = new metodosSQL();
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            int equipo = Integer.parseInt(request.getParameter("id"));
            Equipo e = msql.getEquipo(equipo);
            String json = null;

            try {
                Empleado emp = msql.getEmpleado(e, temporada);

                Gson gson = new Gson();
                emp.setClubEmpleadoCollection(null);
                emp.setEquipoEmpleadoCollection(null);

                json = gson.toJson(emp);

            } catch (NoResultException ne) {
                Empleado emp = null;
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }

        }

        if (function.equals("crearEquipo")) {
            metodosSQL msql = new metodosSQL();
            Equipo eq = new Equipo();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            eq.setActivo(1);
            eq.setCategoria(request.getParameter("categoria"));
            eq.setGrupo(request.getParameter("grupo"));
            eq.setClub(c);

            msql.crearEquipo(eq);

            String result = "Se ha inscrito el nuevo equipo";

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

        if (function.equals("asignaEntrenador")) {
            metodosSQL msql = new metodosSQL();
            Empleado e = (Empleado) request.getSession().getAttribute("usuario");
            Date fechaActual = new Date();
            String temporada = msql.calculaTemporada(fechaActual);
            Club c = (Club) msql.getClubEmpleado(e, temporada);

            List<Empleado> entrenadores = msql.getEmpleadosSinEquiposAsignados(c, temporada);

            Gson gson = new Gson();

            for (Empleado emp : entrenadores) {
                emp.setClubEmpleadoCollection(null);
                emp.setEquipoEmpleadoCollection(null);
            }

            String json = gson.toJson(entrenadores);

            try (PrintWriter out = response.getWriter()) {
                out.print(json);
            }
        }

        if (function.equals("asignacion")) {
            metodosSQL msql = new metodosSQL();
            int idEquipo = Integer.parseInt(request.getParameter("idEquipo"));
            Empleado e = msql.getEmpleado(request.getParameter("entrenador"));
            Equipo eq = msql.getEquipo(idEquipo);
            String temporada = msql.calculaTemporada(new Date());
            String result = null;

            EquipoEmpleado ee = new EquipoEmpleado();
            ee.setEmpleado(e);
            ee.setTemporada(temporada);
            ee.setPuesto(request.getParameter("puesto"));
            ee.setEquipo(eq);

            try {
                msql.crearEquipoEmpleado(ee);
                result = "Se ha asignado al entrenador";
            } catch (Exception ex) {
                result = "No se ha podido vincular entrenador y equipo";
            }

            try (PrintWriter out = response.getWriter()) {
                out.print(result);
            }
        }

    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
