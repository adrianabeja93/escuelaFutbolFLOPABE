/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import modelo.dao.ClienteClubJpaController;
import modelo.dao.ClienteJpaController;
import modelo.dao.JugadorJpaController;
import modelo.entidades.Cliente;
import modelo.entidades.ClienteClub;
import modelo.entidades.Club;
import modelo.entidades.Jugador;

/**
 *
 * @author adrian
 */
public class metodosSQL {

    //UNIDAD DE PERSISTENCIA
    public static final String PU = "FootminPU";

    //codificar contraseña
    public String codificarSHA256(String mensaje) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(mensaje.getBytes(StandardCharsets.UTF_8));
        StringBuffer hexString = new StringBuffer();

        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(hash[i] & 0xff);

            if (hex.length() == 1) {
                hexString.append("0");
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLIENTE---------------------------------
    //---------------------------------------------------------------------------
    public Cliente loginCliente(String login, String password) {
        Cliente c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();
        Query consulta = em.createNamedQuery("Cliente.findByNombreUsuario");
        consulta.setParameter("nombreUsuario", login);
        List<Cliente> resultado = consulta.getResultList();

        if (resultado.size() > 0) {
            if (resultado.get(0).getPassword().equals(password)) {
                c = resultado.get(0);
            }
        }
        em.close();
        return c;
    }

    public void crearCliente(Cliente c) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClienteJpaController cjc = new ClienteJpaController(emf);

        try {
            cjc.create(c);

        } catch (Exception ex) {
            System.err.println("Error al crear cliente " + ex.getMessage());
        }
        emf.close();
    }

    public Cliente existeCliente(String login) {
        Cliente c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);

        ClienteJpaController cjc = new ClienteJpaController(emf);

        c = cjc.findCliente(login);

        emf.close();
        return c;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLIENTE_CLUB----------------------------
    //---------------------------------------------------------------------------
    public ClienteClub clienteClub(String nombreUsuario) {
        ClienteClub cc = null;
        Cliente c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        ClienteJpaController cjc = new ClienteJpaController(emf);
        c = cjc.findCliente(nombreUsuario);

        Query consulta = em.createQuery("SELECT cc FROM ClienteClub cc WHERE cc.usuario = :nombreUsuario");
        consulta.setParameter("nombreUsuario", c);

        cc = (ClienteClub) consulta.getSingleResult();
        em.close();
        emf.close();
        return cc;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLUB------------------------------------
    //---------------------------------------------------------------------------
    //---------------------------------------------------------------------------
    //---------------------METODOS JUGADOR---------------------------------------
    //---------------------------------------------------------------------------
    public void crearJugador(Jugador j) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        JugadorJpaController jjc = new JugadorJpaController(emf);

        try {
            jjc.create(j);

        } catch (Exception ex) {
            System.err.println("Error al crear jugador " + ex.getMessage());
        }
        emf.close();
    }
    
        public List<Jugador> listajugadoresCliente(Cliente usuario) {

        List jugadores = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los jugadores del cliente
        Query consulta = em.createQuery("SELECT j FROM Jugador j where j.tutorLegal = :usuario order by j.apellido1");
        consulta.setParameter("usuario", usuario);
        
        jugadores = consulta.getResultList();

        em.close();
        return jugadores;
    }
}
