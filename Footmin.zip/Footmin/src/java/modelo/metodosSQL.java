/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import controlador.cliente.exceptions.NonexistentEntityException;
import controlador.cliente.exceptions.RollbackFailureException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import modelo.dao.ClienteClubJpaController;
import modelo.dao.ClienteJpaController;
import modelo.dao.ClubEmpleadoJpaController;
import modelo.dao.ClubJpaController;
import modelo.dao.EmpleadoJpaController;
import modelo.dao.EntrenamientoJpaController;
import modelo.dao.EquipoJpaController;
import modelo.dao.JugadorEntrenamientoJpaController;
import modelo.dao.JugadorJpaController;
import modelo.dao.PartidoJpaController;
import modelo.entidades.Cliente;
import modelo.entidades.ClienteClub;
import modelo.entidades.Club;
import modelo.entidades.ClubEmpleado;
import modelo.entidades.Empleado;
import modelo.entidades.Entrenamiento;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoJugador;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorEntrenamiento;
import modelo.entidades.JugadorPartido;
import modelo.entidades.Partido;

/**
 *
 * @author adrian
 */
public class metodosSQL {

    //UNIDAD DE PERSISTENCIA
    public static final String PU = "FootminPU";

    //codificar contraseña
    public String codificarSHA256(String mensaje) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(mensaje.getBytes(StandardCharsets.UTF_8));
        StringBuffer hexString = new StringBuffer();

        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(hash[i] & 0xff);

            if (hex.length() == 1) {
                hexString.append("0");
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLIENTE---------------------------------
    //---------------------------------------------------------------------------
    public Cliente loginCliente(String login, String password) {
        Cliente c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();
        Query consulta = em.createNamedQuery("Cliente.findByNombreUsuario");
        consulta.setParameter("nombreUsuario", login);
        List<Cliente> resultado = consulta.getResultList();

        if (resultado.size() > 0) {
            if (resultado.get(0).getPassword().equals(password)) {
                c = resultado.get(0);
            }
        }
        em.close();
        return c;
    }

    public void crearCliente(Cliente c) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClienteJpaController cjc = new ClienteJpaController(emf);

        try {
            cjc.create(c);

        } catch (Exception ex) {
            System.err.println("Error al crear cliente " + ex.getMessage());
        }
        emf.close();
    }

    public Cliente getCliente(String nomUsu) {
        Cliente c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);

        ClienteJpaController cjc = new ClienteJpaController(emf);

        c = cjc.findCliente(nomUsu);

        emf.close();
        return c;
    }

    public void editCliente(Cliente c) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClienteJpaController cjc = new ClienteJpaController(emf);

        cjc.edit(c);

        emf.close();
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLIENTE_CLUB----------------------------
    //---------------------------------------------------------------------------
    //FUNCION PARA CREAR CLIENTE_CLUB
    public void crearClienteClub(ClienteClub cc) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClienteClubJpaController ccjc = new ClienteClubJpaController(emf);

        try {
            ccjc.create(cc);

        } catch (Exception ex) {
            System.err.println("Error al crear clienteClub " + ex.getMessage());
        }
        emf.close();
    }

    public ClienteClub getClienteClub(Cliente c, Club club, String temporada) {
        ClienteClub cc = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT cc FROM ClienteClub cc"
                + " WHERE cc.usuario = :usuario AND cc.club = :club AND cc.temporada = :temp");
        consulta.setParameter("usuario", c);
        consulta.setParameter("club", club);
        consulta.setParameter("temp", temporada);

        cc = (ClienteClub) consulta.getSingleResult();

        em.close();
        return cc;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLUB------------------------------------
    //---------------------------------------------------------------------------
    public void crearClub(Club c) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClubJpaController cjc = new ClubJpaController(emf);

        try {
            cjc.create(c);

        } catch (Exception ex) {
            System.err.println("Error al crear club " + ex.getMessage());
        }
        emf.close();
    }

    public Club getClub(int id) {

        Club c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        ClubJpaController cjc = new ClubJpaController(emf);

        c = cjc.findClub(id);

        return c;
    }

    public Club getClub(String codigo) {

        Club c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNamedQuery("Club.findByCodClub");
        consulta.setParameter("codClub", codigo);

        c = (Club) consulta.getSingleResult();

        return c;
    }

    public Club getClubNombre(String nombre) {

        Club c = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNamedQuery("Club.findByNombre");
        consulta.setParameter("nombre", nombre);

        c = (Club) consulta.getSingleResult();

        return c;
    }

    //CLUBES A LOS QUE ESTÁ VINCULADO EL CLIENTE
    public List<Club> clubesCliente(Cliente usuario) {
        List clubes = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los clubes del cliente
        Query consulta = em.createQuery("SELECT DISTINCT c FROM Club c JOIN ClienteClub cc "
                + " where cc.usuario = :usuario order by c.nombre");
        consulta.setParameter("usuario", usuario);

        clubes = consulta.getResultList();

        em.close();
        return clubes;
    }

    //Información de los clubes asociados de un cliente en la temporada actual
    public List<Club> infoClub(Cliente usuario, String temporada) {
        List infoClub = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT c FROM Club c JOIN c.clienteClubCollection cc"
                + " WHERE cc.usuario = :usuario AND cc.temporada = :temp");
        consulta.setParameter("usuario", usuario);
        consulta.setParameter("temp", temporada);

        infoClub = consulta.getResultList();

        em.close();
        return infoClub;
    }

    //Información de los clubes asociados de un empleado en la temporada actual
    public List<Club> infoClub(Empleado usuario, String temporada) {
        List infoClub = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT c FROM Club c JOIN c.clubEmpleadoCollection ce"
                + " WHERE ce.empleado = :usuario AND ce.temporada = :temp");
        consulta.setParameter("usuario", usuario);
        consulta.setParameter("temp", temporada);

        infoClub = consulta.getResultList();

        em.close();
        return infoClub;
    }
    
        public Club getClubEmpleado(Empleado usuario, String temporada) {
        Club infoClub = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT DISTINCT c FROM Club c JOIN c.clubEmpleadoCollection ce"
                + " WHERE ce.empleado = :usuario AND ce.temporada = :temp");
        consulta.setParameter("usuario", usuario);
        consulta.setParameter("temp", temporada);

        infoClub = (Club) consulta.getSingleResult();

        em.close();
        return infoClub;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL CLUBEMPLEADO----------------------------
    //---------------------------------------------------------------------------
    public void crearClubEmpleado(ClubEmpleado ce) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        ClubEmpleadoJpaController cejc = new ClubEmpleadoJpaController(emf);

        try {
            cejc.create(ce);

        } catch (Exception ex) {
            System.err.println("Error al crear club_empleado " + ex.getMessage());
        }
        emf.close();
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL EQUIPO----------------------------------
    //---------------------------------------------------------------------------  
    public Equipo getEquipo(int id) {

        Equipo e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        EquipoJpaController ejc = new EquipoJpaController(emf);

        e = ejc.findEquipo(id);

        return e;
    }

    //buscar el equipo que está entrenando un empleado actualmente
    public Equipo getEquipo(Empleado emp, String temporada) {

        Equipo e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT e FROM Equipo e JOIN e.equipoEmpleadoCollection ee"
                + " WHERE ee.empleado = :usuario AND ee.temporada = :temp");
        consulta.setParameter("usuario", emp);
        consulta.setParameter("temp", temporada);

        e = (Equipo) consulta.getSingleResult();

        em.close();

        return e;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS DEL EQUIPOEMPLEADO----------------------------
    //---------------------------------------------------------------------------
    public Object infoEquipoEmpleado(Empleado e, String temporada) {
        Object info = new Object();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT e.categoria, e.grupo, ee.temporada, ee.puesto, e.idEquipo FROM Equipo e JOIN e.equipoEmpleadoCollection ee"
                + " WHERE ee.empleado = :usuario AND ee.temporada = :temp");
        consulta.setParameter("usuario", e);
        consulta.setParameter("temp", temporada);

        info = consulta.getResultList();

        em.close();

        return info;
    }

    //---------------------------------------------------------------------------
    //---------------------METODOS JUGADOR---------------------------------------
    //---------------------------------------------------------------------------
    public void crearJugador(Jugador j) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        JugadorJpaController jjc = new JugadorJpaController(emf);

        try {
            jjc.create(j);

        } catch (Exception ex) {
            System.err.println("Error al crear jugador " + ex.getMessage());
        }
        emf.close();
    }

    public List<Jugador> listajugadoresCliente(Cliente usuario) {

        List jugadores = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los jugadores del cliente
        Query consulta = em.createQuery("SELECT j FROM Jugador j where j.tutorLegal = :usuario order by j.apellido1, j.apellido2, j.nombre");
        consulta.setParameter("usuario", usuario);

        jugadores = consulta.getResultList();

        em.close();
        return jugadores;
    }

    public List<Jugador> listajugadoresEquipo(Equipo e, String temporada) {

        List jugadores = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los jugadores del equipo
        Query consulta = em.createQuery("SELECT j FROM Jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE ej.equipo = :equipo AND ej.temporada = :temporada ORDER BY j.apellido1, j.apellido2, j.nombre");
        consulta.setParameter("equipo", e);
        consulta.setParameter("temporada", temporada);

        jugadores = consulta.getResultList();

        em.close();
        return jugadores;
    }

    public Jugador getJugador(int id) {

        Jugador j = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        JugadorJpaController jjc = new JugadorJpaController(emf);

        j = jjc.findJugador(id);

        return j;
    }

    public Jugador editJugador(Jugador j) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        JugadorJpaController jjc = new JugadorJpaController(emf);

        try {
            jjc.edit(j);
        } catch (Exception ex) {
            Logger.getLogger(metodosSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return j;
    }

    public Object numJugadoresClubTemporada(Club c, String temporada) {
        Object num = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT count(ej) FROM EquipoJugador ej JOIN ej.equipo e where e.club = :club AND ej.temporada = :temp");
        consulta.setParameter("club", c);
        consulta.setParameter("temp", temporada);

        num = consulta.getSingleResult();

        return num;
    }

    //---------------------------------------------------------------------------
    //---------------------METODOS JUGADOR-EQUIPO---------------------------------------
    //---------------------------------------------------------------------------
    public EquipoJugador getEquipoJugador(Jugador j, String temporada) {
        EquipoJugador ej = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT ej FROM EquipoJugador ej "
                + " WHERE ej.jugador = :jugador AND ej.temporada = :temp");
        consulta.setParameter("jugador", j);
        consulta.setParameter("temp", temporada);

        ej = (EquipoJugador) consulta.getSingleResult();

        em.close();

        return ej;
    }

    public Object numPartidosJugadorTemporada(Jugador j, String temporada) {
        Object num = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT count(jp) FROM JugadorPartido jp JOIN jp.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE jp.jugador = :jugador AND ej.temporada = :temp AND jp.convocado = 1");
        consulta.setParameter("jugador", j);
        consulta.setParameter("temp", temporada);

        num = consulta.getSingleResult();

        return num;
    }

    public Object numEntrenosJugadorTemporada(Jugador j, String temporada) {
        Object num = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT count(je) FROM JugadorEntrenamiento je JOIN je.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE je.jugador = :jugador AND ej.temporada = :temp AND je.asiste = 1");
        consulta.setParameter("jugador", j);
        consulta.setParameter("temp", temporada);

        num = consulta.getSingleResult();

        return num;
    }

    public Object numEquiposClub(Club c) {
        Object num = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT count(e) FROM Equipo e where e.club = :club");
        consulta.setParameter("club", c);

        num = consulta.getSingleResult();

        return num;
    }

    //FUNCION PARA CONSEGUIR LAS TEMPORADAS EN LAS QUE LLEVA EL CLIENTE UTILIZANDO LA APLICACIÓN
    public List<Object> temporadasCliente(Cliente usuario) {

        List temporadas = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todas las temporadas del cliente en la aplicación
        //utilizaremos distincT en la consulta porque hay que tener en cuenta que el campo temporada se puede repetir
        //ya que un cliente puede estar en más de un club dentro de una misma temporada
        Query consulta = em.createQuery("SELECT DISTINCT cc.temporada FROM ClienteClub cc where cc.usuario = :usuario order by cc.temporada");
        consulta.setParameter("usuario", usuario);

        temporadas = consulta.getResultList();

        em.close();
        return temporadas;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS ENTRENAMIENTO-------------------------------
    //---------------------------------------------------------------------------
    //FUNCION QUE ME DEVUELVE LOS PROXIMOS ENTRENAMIENTOS DE LOS JUGADORES DE UN CLIENTE
    public List<Object> proximosEntrenamientosCliente(String nomUsuario, Date fecha) {

        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        List proximosEntrenos = null;
        String date = formatoFecha.format(fecha);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNativeQuery("select DATE_FORMAT(e.fechaHoraComienzo, '%Y-%m-%d') DATEONLY,"
                + " DATE_FORMAT(e.fechaHoraComienzo, '%H:%i') TIMEONLY,"
                + " DATE_FORMAT(e.fechaHoraFinalizacion, '%H:%i') TIMEONLY, eq.categoria, "
                + "eq.grupo, c.nombre as club, j.nombre, j.apellido1, j.apellido2, e.descripcionSesion "
                + "from Entrenamiento e join Jugador_Entrenamiento je on e.idEntrenamiento = je.entrenamiento "
                + "join Jugador j on je.jugador = j.idJugador "
                + "join Equipo_Jugador ej on j.idJugador = ej.jugador "
                + "join Equipo eq on ej.equipo = eq.idEquipo join Club c on eq.club = c.idClub "
                + "where j.tutorLegal = '" + nomUsuario + "' and e.fechaHoraComienzo > '" + date + "' order by e.fechaHoraComienzo");

        proximosEntrenos = consulta.getResultList();

        em.close();
        return proximosEntrenos;
    }

    public Entrenamiento editEntrenamiento(Entrenamiento e) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        EntrenamientoJpaController ejc = new EntrenamientoJpaController(emf);

        try {
            ejc.edit(e);
        } catch (Exception ex) {
            Logger.getLogger(metodosSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return e;
    }

    public void crearEntrenamiento(Entrenamiento e) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntrenamientoJpaController ejc = new EntrenamientoJpaController(emf);

        try {
            ejc.create(e);

        } catch (Exception ex) {
            System.err.println("Error al crear Entrenamiento " + ex.getMessage());
        }
        emf.close();
    }

    public Entrenamiento getEntrenamiento(long id) {

        Entrenamiento e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        EntrenamientoJpaController ejc = new EntrenamientoJpaController(emf);

        e = ejc.findEntrenamiento(id);

        return e;
    }

    public List<Entrenamiento> getProxEntrenamientoEquipo(Equipo equipo, Date fechaActual) {

        List<Entrenamiento> e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT DISTINCT e FROM Entrenamiento e JOIN e.jugadorEntrenamientoCollection je JOIN je.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE ej.equipo = :equipo AND e.fechaHoraComienzo > :fechaActual AND e.suspendido = 0 ORDER BY e.fechaHoraComienzo");

        consulta.setParameter("equipo", equipo);
        consulta.setParameter("fechaActual", fechaActual);
        e = consulta.getResultList();

        em.close();

        return e;
    }

    public List<Entrenamiento> getEntrenamientoEquipoTemp(Equipo equipo, String temporada) {

        List<Entrenamiento> e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT DISTINCT e FROM Entrenamiento e JOIN e.jugadorEntrenamientoCollection je JOIN je.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE ej.equipo = :equipo AND ej.temporada = :temporada AND e.suspendido = 0 ORDER BY e.fechaHoraComienzo DESC");

        consulta.setParameter("equipo", equipo);
        consulta.setParameter("temporada", temporada);
        e = consulta.getResultList();

        em.close();

        return e;
    }

    //FUNCION PARA CONSEGUIR LAS SESIONES DE ENTRENAMIENTO DE UN JUGADOR EN UN MES
    public List<Object> entrenosJugador(Jugador jugador, Date primeroMes, Date ultimoMes) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        List proximosEntrenos = null;
        List je = null;
        String primeroMesFor = formatoFecha.format(primeroMes);
        String ultimoMesFor = formatoFecha.format(ultimoMes);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNativeQuery("SELECT DATE_FORMAT(e.fechaHoraComienzo, '%d-%m-%Y') DATEONLY,"
                + " je.asiste, je.justificado, je.justificacion, je.comportamientoJugador, je.id"
                + " FROM Jugador_Entrenamiento je JOIN Entrenamiento e ON je.entrenamiento = e.idEntrenamiento"
                + " where je.jugador = '" + jugador.getIdJugador() + "' AND (e.fechaHoraComienzo > '" + primeroMesFor + "' AND e.fechaHoraComienzo < '" + ultimoMesFor + "')"
                + " order by e.fechaHoraComienzo");

        je = consulta.getResultList();

        em.close();
        return je;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS JUGADOR ENTRENAMIENTO-----------------------
    //---------------------------------------------------------------------------
    public void crearJugadorEntrenamiento(JugadorEntrenamiento je) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        JugadorEntrenamientoJpaController jejc = new JugadorEntrenamientoJpaController(emf);

        try {
            jejc.create(je);

        } catch (Exception ex) {
            System.err.println("Error al crear jugadorEntrenamiento " + ex.getMessage());
        }
        emf.close();
    }

    //función para editar jugadorentrenamiento
    public JugadorEntrenamiento editJugadorEntrenamiento(JugadorEntrenamiento je) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        JugadorEntrenamientoJpaController jjec = new JugadorEntrenamientoJpaController(emf);

        try {
            jjec.edit(je);
        } catch (Exception ex) {
            Logger.getLogger(metodosSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return je;
    }

    //función para BUSCAR jugadorentrenamiento
    public JugadorEntrenamiento getJugadorEntrenamiento(long id) {

        JugadorEntrenamiento je = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        JugadorEntrenamientoJpaController jjec = new JugadorEntrenamientoJpaController(emf);

        je = jjec.findJugadorEntrenamiento(id);

        return je;
    }

    public List<Object> getAsistenciaSesion(Entrenamiento e) {
        List<Object> asistencia = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT j.nombre, j.apellido1, j.apellido2, je.asiste, je.justificacion, je.comportamientoJugador, je.id"
                + " FROM JugadorEntrenamiento je JOIN je.jugador j"
                + " WHERE je.entrenamiento = :entrenamiento ORDER BY j.apellido1, j.apellido2, j.nombre");

        consulta.setParameter("entrenamiento", e);
        asistencia = consulta.getResultList();

        em.close();

        return asistencia;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS PARTIDO---------Ñ---------------------------
    //---------------------------------------------------------------------------
    public Partido getPartido(long id) {

        Partido p = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        PartidoJpaController pjc = new PartidoJpaController(emf);

        p = pjc.findPartido(id);

        return p;
    }

    //FUNCION PARA CONSEGUIR LOS PROXIMOS PARTIDOS DE LOS JUGADORES DE UN CLIENTE 
    public List<Object> proximosPartidosCliente(Cliente c, Date fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        List proximosPartidos = null;
        String date = formatoFecha.format(fecha);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNativeQuery("SELECT DISTINCT DATE_FORMAT(p.fechaHora, '%d-%m-%Y') DATEONLY,"
                + " DATE_FORMAT(p.fechaHora, '%H:%i') TIMEONLY,"
                + " eq.categoria, eq.grupo, p.rival, c.nombre, p.jornada, p.fechaHora, p.idPartido"
                + " FROM Partido p JOIN Jugador_Partido jp ON p.idPartido = jp.partido"
                + " JOIN Jugador j ON jp.jugador = j.idJugador"
                + " JOIN Equipo_Jugador ej ON j.idJugador = ej.jugador"
                + " JOIN Equipo eq ON ej.equipo = eq.idEquipo"
                + " JOIN Club c ON eq.club = c.idClub"
                + " WHERE j.tutorLegal = '" + c.getNombreUsuario() + "' AND p.fechaHora > '" + date + "'"
                + " ORDER BY p.fechaHora");

        proximosPartidos = consulta.getResultList();

        em.close();
        return proximosPartidos;
    }

    //FUNCION PARA CONSEGUIR LOS ULTIMOS PARTIDOS DISPUTADOS DE LOS JUGADORES DE UN CLIENTE 
    public List<Object> ultimosPartidosCliente(Cliente c, Date fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        List ultimosPartidos = null;
        String date = formatoFecha.format(fecha);

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNativeQuery("SELECT DISTINCT DATE_FORMAT(p.fechaHora, '%d-%m-%Y') DATEONLY,"
                + " eq.categoria, eq.grupo, p.rival, p.marcadorRival, p.marcadorLocal, c.nombre, p.jornada, p.fechaHora, p.idPartido"
                + " FROM Partido p JOIN Jugador_Partido jp ON p.idPartido = jp.partido"
                + " JOIN Jugador j ON jp.jugador = j.idJugador"
                + " JOIN Equipo_Jugador ej ON j.idJugador = ej.jugador"
                + " JOIN Equipo eq ON ej.equipo = eq.idEquipo"
                + " JOIN Club c ON eq.club = c.idClub"
                + " WHERE j.tutorLegal = '" + c.getNombreUsuario() + "' AND p.fechaHora < '" + date + "'"
                + " ORDER BY p.fechaHora limit 5");

        ultimosPartidos = consulta.getResultList();

        em.close();
        return ultimosPartidos;
    }

    //FUNCION PARA CONSEGUIR LOS PARTIDOS DE LOS CLUBS VINCULADOS AL CLIENTE DE UNA JORNADA DENTRO DE LA TEMPORADA CORRESPONDIENTE
    public List<Object> partidosCliente(String temporada, String categoria, String jornada, String club) {

        List partidosCliente = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createNativeQuery("SELECT DISTINCT DATE_FORMAT(p.fechaHora, '%d-%m-%Y') DATEONLY,"
                + " eq.categoria, eq.grupo, p.rival, p.marcadorRival, p.marcadorLocal, c.nombre, p.jornada, p.fechaHora, p.idPartido"
                + " FROM Partido p JOIN Jugador_Partido jp ON p.idPartido = jp.partido"
                + " JOIN Jugador j ON jp.jugador = j.idJugador"
                + " JOIN Equipo_Jugador ej ON j.idJugador = ej.jugador"
                + " JOIN Equipo eq ON ej.equipo = eq.idEquipo"
                + " JOIN Club c ON eq.club = c.idClub"
                + " WHERE ej.temporada = '" + temporada + "'"
                + " AND eq.categoria = '" + categoria + "' AND p.jornada= '" + jornada + "' AND c.nombre = '" + club + "'"
                + " ORDER BY p.fechaHora");

        partidosCliente = consulta.getResultList();

        em.close();
        return partidosCliente;
    }

    public List<Partido> getProximosPartidosEquipo(Equipo equipo, Date fechaActual) {
        List partidos = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT DISTINCT p FROM Partido p JOIN p.jugadorPartidoCollection jp JOIN jp.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE ej.equipo = :equipo AND p.fechaHora > :fechaActual ORDER BY p.fechaHora DESC");

        consulta.setParameter("equipo", equipo);
        consulta.setParameter("fechaActual", fechaActual);
        partidos = consulta.getResultList();

        em.close();

        return partidos;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS JUGADORPARTIDO------------------------------
    //---------------------------------------------------------------------------
    //FUNCION PARA VER LA LISTA DE JUGADORES CONVOCADOS PARA UN PARTIDO
    public List<Jugador> convocados(Partido p) {
        List convocatoria = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los jugadores que puede participar en el partido
        //independientemente de si están convocados o no, luego mostraremos quien si lo está y quien no
        Query consulta = em.createQuery("SELECT DISTINCT j FROM JugadorPartido jp JOIN jp.jugador j"
                + " WHERE jp.partido = :partido AND jp.convocado = 1 ORDER BY j.apellido1, j.apellido2, j.nombre");
        consulta.setParameter("partido", p);

        convocatoria = consulta.getResultList();

        em.close();
        return convocatoria;
    }

    //FUNCION PARA VER LA LISTA DE JUGADORES NO CONVOCADOS PARA UN PARTIDO
    public List<Jugador> noConvocados(Partido p) {
        List convocatoria = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        //sacamos la lista con todos los jugadores que puede participar en el partido
        //independientemente de si están convocados o no, luego mostraremos quien si lo está y quien no
        Query consulta = em.createQuery("SELECT DISTINCT j FROM JugadorPartido jp JOIN jp.jugador j"
                + " WHERE jp.partido = :partido AND jp.convocado = 0 ORDER BY j.apellido1, j.apellido2, j.nombre");
        consulta.setParameter("partido", p);

        convocatoria = consulta.getResultList();

        em.close();
        return convocatoria;
    }

    //FUNCION PARA VER LAS ESTADISTICAS DE UN EQUIPO EN EL PARTIDO
    public List<Object> resumenPartido(Partido p) {
        List resumen = null;

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT j.nombre, j.apellido1, j.apellido2, jp.goles, jp.asistencias, jp.tarjetasAmarillas, jp.tarjetaRoja"
                + " FROM JugadorPartido jp JOIN jp.jugador j"
                + " WHERE jp.partido = :partido ORDER BY j.apellido1, j.apellido2, j.nombre");
        consulta.setParameter("partido", p);

        resumen = consulta.getResultList();

        em.close();
        return resumen;
    }

    //FUNCION PARA SABER EN QUE TEMPORADA ESTAMOS SEGUN UNA FECHA
    public String calculaTemporada(Date d) {
        String temporada = null, aux;
        SimpleDateFormat fecha = new SimpleDateFormat("dd-MM-yyyy");
        String date[] = new String[3];
        int mes, anyo1, anyo2;

        //primero convertimos la fecha en string y separaremos mes y año
        aux = fecha.format(d);
        date = aux.split("-");

        //mes lo vamos a transformar en int para poder comparar. Si el mes es más de 7 la primera mitad de la temporada
        mes = Integer.parseInt(date[1]);

        if (mes > 7) {
            anyo1 = Integer.parseInt(date[2]);
            anyo2 = anyo1 + 1;
        } else {
            //segunda mitad de la temporada por lo tanto aunque el año sea 2020 la temporada habría empezado en verano de 2019
            anyo2 = Integer.parseInt(date[2]);
            anyo1 = anyo2 - 1;
        }
        temporada = String.valueOf(anyo1) + "/" + String.valueOf(anyo2);

        //devolvemos temporada formato: 2020/2021 (ej)
        return temporada;
    }

    public List<Object> estadisticasJugadorTemporada(Jugador j, String temporada) {
        List<Object> estad = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();

        Query consulta = em.createQuery("SELECT sum(jp.goles), sum(jp.asistencias), sum(jp.minutosDisputados), sum(jp.tarjetasAmarillas),"
                + " sum(jp.tarjetaRoja) FROM JugadorPartido jp JOIN jp.jugador j JOIN j.equipoJugadorCollection ej"
                + " WHERE jp.jugador = :jugador AND ej.temporada = :temp");
        consulta.setParameter("jugador", j);
        consulta.setParameter("temp", temporada);

        estad = consulta.getResultList();

        return estad;
    }

    //---------------------------------------------------------------------------
    //-----------------------METODOS EMPLEADO------------------------------------
    //---------------------------------------------------------------------------
    public void crearEmpleado(Empleado e) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EmpleadoJpaController ejc = new EmpleadoJpaController(emf);

        try {
            ejc.create(e);

        } catch (Exception ex) {
            System.err.println("Error al crear empleado " + ex.getMessage());
        }
        emf.close();
    }

    public Empleado getEmpleado(String nomUsu) {
        Empleado e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);

        EmpleadoJpaController ejc = new EmpleadoJpaController(emf);

        e = ejc.findEmpleado(nomUsu);

        emf.close();
        return e;
    }

    public Empleado loginEmpleado(String login, String password) {
        Empleado e = null;
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PU);
        EntityManager em = emf.createEntityManager();
        Query consulta = em.createNamedQuery("Empleado.findByNombreUsuario");
        consulta.setParameter("nombreUsuario", login);
        List<Empleado> resultado = consulta.getResultList();

        if (resultado.size() > 0) {
            if (resultado.get(0).getPassword().equals(password)) {
                e = resultado.get(0);
            }
        }
        em.close();
        return e;
    }
}
