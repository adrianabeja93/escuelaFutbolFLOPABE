/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Jugador_Entrenamiento")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "JugadorEntrenamiento.findAll", query = "SELECT j FROM JugadorEntrenamiento j")
    , @NamedQuery(name = "JugadorEntrenamiento.findByComportamientoJugador", query = "SELECT j FROM JugadorEntrenamiento j WHERE j.comportamientoJugador = :comportamientoJugador")
    , @NamedQuery(name = "JugadorEntrenamiento.findByAsiste", query = "SELECT j FROM JugadorEntrenamiento j WHERE j.asiste = :asiste")
    , @NamedQuery(name = "JugadorEntrenamiento.findById", query = "SELECT j FROM JugadorEntrenamiento j WHERE j.id = :id")
    , @NamedQuery(name = "JugadorEntrenamiento.findByJustificado", query = "SELECT j FROM JugadorEntrenamiento j WHERE j.justificado = :justificado")
    , @NamedQuery(name = "JugadorEntrenamiento.findByJustificacion", query = "SELECT j FROM JugadorEntrenamiento j WHERE j.justificacion = :justificacion")})
public class JugadorEntrenamiento implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 400)
    @Column(name = "comportamientoJugador")
    private String comportamientoJugador;
    @Column(name = "asiste")
    private int asiste;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Column(name = "justificado")
    private Integer justificado;
    @Size(max = 400)
    @Column(name = "justificacion")
    private String justificacion;
    @JoinColumn(name = "entrenamiento", referencedColumnName = "idEntrenamiento")
    @ManyToOne(optional = false)
    private Entrenamiento entrenamiento;
    @JoinColumn(name = "jugador", referencedColumnName = "idJugador")
    @ManyToOne(optional = false)
    private Jugador jugador;

    public JugadorEntrenamiento() {
    }

    public JugadorEntrenamiento(Long id) {
        this.id = id;
    }

    public String getComportamientoJugador() {
        return comportamientoJugador;
    }

    public void setComportamientoJugador(String comportamientoJugador) {
        this.comportamientoJugador = comportamientoJugador;
    }

    public int getAsiste() {
        return asiste;
    }

    public void setAsiste(int asiste) {
        this.asiste = asiste;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getJustificado() {
        return justificado;
    }

    public void setJustificado(Integer justificado) {
        this.justificado = justificado;
    }

    public String getJustificacion() {
        return justificacion;
    }

    public void setJustificacion(String justificacion) {
        this.justificacion = justificacion;
    }

    public Entrenamiento getEntrenamiento() {
        return entrenamiento;
    }

    public void setEntrenamiento(Entrenamiento entrenamiento) {
        this.entrenamiento = entrenamiento;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof JugadorEntrenamiento)) {
            return false;
        }
        JugadorEntrenamiento other = (JugadorEntrenamiento) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.JugadorEntrenamiento[ id=" + id + " ]";
    }
    
}
