/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Equipo_Empleado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EquipoEmpleado.findAll", query = "SELECT e FROM EquipoEmpleado e")
    , @NamedQuery(name = "EquipoEmpleado.findByTemporada", query = "SELECT e FROM EquipoEmpleado e WHERE e.temporada = :temporada")
    , @NamedQuery(name = "EquipoEmpleado.findByPuesto", query = "SELECT e FROM EquipoEmpleado e WHERE e.puesto = :puesto")
    , @NamedQuery(name = "EquipoEmpleado.findById", query = "SELECT e FROM EquipoEmpleado e WHERE e.id = :id")})
public class EquipoEmpleado implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 20)
    @Column(name = "temporada")
    private String temporada;
    @Size(max = 45)
    @Column(name = "puesto")
    private String puesto;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @JoinColumn(name = "empleado", referencedColumnName = "nombreUsuario")
    @ManyToOne(optional = false)
    private Empleado empleado;
    @JoinColumn(name = "equipo", referencedColumnName = "idEquipo")
    @ManyToOne(optional = false)
    private Equipo equipo;

    public EquipoEmpleado() {
    }

    public EquipoEmpleado(Long id) {
        this.id = id;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EquipoEmpleado)) {
            return false;
        }
        EquipoEmpleado other = (EquipoEmpleado) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.EquipoEmpleado[ id=" + id + " ]";
    }
    
}
