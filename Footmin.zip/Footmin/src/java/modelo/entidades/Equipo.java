/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Equipo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Equipo.findAll", query = "SELECT e FROM Equipo e")
    , @NamedQuery(name = "Equipo.findByIdEquipo", query = "SELECT e FROM Equipo e WHERE e.idEquipo = :idEquipo")
    , @NamedQuery(name = "Equipo.findByCategoria", query = "SELECT e FROM Equipo e WHERE e.categoria = :categoria")
    , @NamedQuery(name = "Equipo.findByGrupo", query = "SELECT e FROM Equipo e WHERE e.grupo = :grupo")
    , @NamedQuery(name = "Equipo.findByActivo", query = "SELECT e FROM Equipo e WHERE e.activo = :activo")
    , @NamedQuery(name = "Equipo.findByNumMaxJug", query = "SELECT e FROM Equipo e WHERE e.numMaxJug = :numMaxJug")})
public class Equipo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEquipo")
    private Integer idEquipo;
    @Size(max = 20)
    @Column(name = "categoria")
    private String categoria;
    @Size(max = 10)
    @Column(name = "grupo")
    private String grupo;
    @Column(name = "activo")
    private Short activo;
    @Column(name = "numMaxJug")
    private Integer numMaxJug;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "equipo")
    private Collection<EquipoEmpleado> equipoEmpleadoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "equipo")
    private Collection<EquipoJugador> equipoJugadorCollection;
    @JoinColumn(name = "club", referencedColumnName = "idClub")
    @ManyToOne(optional = false)
    private Club club;

    public Equipo() {
    }

    public Equipo(Integer idEquipo) {
        this.idEquipo = idEquipo;
    }

    public Integer getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(Integer idEquipo) {
        this.idEquipo = idEquipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public Short getActivo() {
        return activo;
    }

    public void setActivo(Short activo) {
        this.activo = activo;
    }

    public Integer getNumMaxJug() {
        return numMaxJug;
    }

    public void setNumMaxJug(Integer numMaxJug) {
        this.numMaxJug = numMaxJug;
    }

    @XmlTransient
    public Collection<EquipoEmpleado> getEquipoEmpleadoCollection() {
        return equipoEmpleadoCollection;
    }

    public void setEquipoEmpleadoCollection(Collection<EquipoEmpleado> equipoEmpleadoCollection) {
        this.equipoEmpleadoCollection = equipoEmpleadoCollection;
    }

    @XmlTransient
    public Collection<EquipoJugador> getEquipoJugadorCollection() {
        return equipoJugadorCollection;
    }

    public void setEquipoJugadorCollection(Collection<EquipoJugador> equipoJugadorCollection) {
        this.equipoJugadorCollection = equipoJugadorCollection;
    }

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEquipo != null ? idEquipo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Equipo)) {
            return false;
        }
        Equipo other = (Equipo) object;
        if ((this.idEquipo == null && other.idEquipo != null) || (this.idEquipo != null && !this.idEquipo.equals(other.idEquipo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Equipo[ idEquipo=" + idEquipo + " ]";
    }
    
}
