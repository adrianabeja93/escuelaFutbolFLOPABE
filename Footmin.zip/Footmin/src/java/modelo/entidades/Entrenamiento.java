/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Entrenamiento")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Entrenamiento.findAll", query = "SELECT e FROM Entrenamiento e")
    , @NamedQuery(name = "Entrenamiento.findByIdEntrenamiento", query = "SELECT e FROM Entrenamiento e WHERE e.idEntrenamiento = :idEntrenamiento")
    , @NamedQuery(name = "Entrenamiento.findByFechaHoraComienzo", query = "SELECT e FROM Entrenamiento e WHERE e.fechaHoraComienzo = :fechaHoraComienzo")
    , @NamedQuery(name = "Entrenamiento.findByFechaHoraFinalizacion", query = "SELECT e FROM Entrenamiento e WHERE e.fechaHoraFinalizacion = :fechaHoraFinalizacion")
    , @NamedQuery(name = "Entrenamiento.findByComentarioSesion", query = "SELECT e FROM Entrenamiento e WHERE e.comentarioSesion = :comentarioSesion")
    , @NamedQuery(name = "Entrenamiento.findBySuspendido", query = "SELECT e FROM Entrenamiento e WHERE e.suspendido = :suspendido")
    , @NamedQuery(name = "Entrenamiento.findByDescripcionSesion", query = "SELECT e FROM Entrenamiento e WHERE e.descripcionSesion = :descripcionSesion")
    , @NamedQuery(name = "Entrenamiento.findByNumMaxEntrenoSimultaneo", query = "SELECT e FROM Entrenamiento e WHERE e.numMaxEntrenoSimultaneo = :numMaxEntrenoSimultaneo")})
public class Entrenamiento implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEntrenamiento")
    private Long idEntrenamiento;
    @Column(name = "fechaHoraComienzo")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHoraComienzo;
    @Column(name = "fechaHoraFinalizacion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHoraFinalizacion;
    @Size(max = 400)
    @Column(name = "comentarioSesion")
    private String comentarioSesion;
    @Column(name = "suspendido")
    private Short suspendido;
    @Size(max = 400)
    @Column(name = "descripcionSesion")
    private String descripcionSesion;
    @Column(name = "numMaxEntrenoSimultaneo")
    private Integer numMaxEntrenoSimultaneo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "entrenamiento")
    private Collection<JugadorEntrenamiento> jugadorEntrenamientoCollection;

    public Entrenamiento() {
    }

    public Entrenamiento(Long idEntrenamiento) {
        this.idEntrenamiento = idEntrenamiento;
    }

    public Long getIdEntrenamiento() {
        return idEntrenamiento;
    }

    public void setIdEntrenamiento(Long idEntrenamiento) {
        this.idEntrenamiento = idEntrenamiento;
    }

    public Date getFechaHoraComienzo() {
        return fechaHoraComienzo;
    }

    public void setFechaHoraComienzo(Date fechaHoraComienzo) {
        this.fechaHoraComienzo = fechaHoraComienzo;
    }

    public Date getFechaHoraFinalizacion() {
        return fechaHoraFinalizacion;
    }

    public void setFechaHoraFinalizacion(Date fechaHoraFinalizacion) {
        this.fechaHoraFinalizacion = fechaHoraFinalizacion;
    }

    public String getComentarioSesion() {
        return comentarioSesion;
    }

    public void setComentarioSesion(String comentarioSesion) {
        this.comentarioSesion = comentarioSesion;
    }

    public Short getSuspendido() {
        return suspendido;
    }

    public void setSuspendido(Short suspendido) {
        this.suspendido = suspendido;
    }

    public String getDescripcionSesion() {
        return descripcionSesion;
    }

    public void setDescripcionSesion(String descripcionSesion) {
        this.descripcionSesion = descripcionSesion;
    }

    public Integer getNumMaxEntrenoSimultaneo() {
        return numMaxEntrenoSimultaneo;
    }

    public void setNumMaxEntrenoSimultaneo(Integer numMaxEntrenoSimultaneo) {
        this.numMaxEntrenoSimultaneo = numMaxEntrenoSimultaneo;
    }

    @XmlTransient
    public Collection<JugadorEntrenamiento> getJugadorEntrenamientoCollection() {
        return jugadorEntrenamientoCollection;
    }

    public void setJugadorEntrenamientoCollection(Collection<JugadorEntrenamiento> jugadorEntrenamientoCollection) {
        this.jugadorEntrenamientoCollection = jugadorEntrenamientoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEntrenamiento != null ? idEntrenamiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Entrenamiento)) {
            return false;
        }
        Entrenamiento other = (Entrenamiento) object;
        if ((this.idEntrenamiento == null && other.idEntrenamiento != null) || (this.idEntrenamiento != null && !this.idEntrenamiento.equals(other.idEntrenamiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Entrenamiento[ idEntrenamiento=" + idEntrenamiento + " ]";
    }
    
}
