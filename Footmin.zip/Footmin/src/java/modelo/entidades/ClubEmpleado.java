/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Club_Empleado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ClubEmpleado.findAll", query = "SELECT c FROM ClubEmpleado c")
    , @NamedQuery(name = "ClubEmpleado.findByTemporada", query = "SELECT c FROM ClubEmpleado c WHERE c.temporada = :temporada")
    , @NamedQuery(name = "ClubEmpleado.findById", query = "SELECT c FROM ClubEmpleado c WHERE c.id = :id")})
public class ClubEmpleado implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 45)
    @Column(name = "temporada")
    private String temporada;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private int id;
    @JoinColumn(name = "club", referencedColumnName = "idClub")
    @ManyToOne(optional = false)
    private Club club;
    @JoinColumn(name = "empleado", referencedColumnName = "nombreUsuario")
    @ManyToOne(optional = false)
    private Empleado empleado;

    public ClubEmpleado() {
    }

    public ClubEmpleado(int id) {
        this.id = id;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }


    @Override
    public String toString() {
        return "modelo.entidades.ClubEmpleado[ id=" + id + " ]";
    }
    
}
