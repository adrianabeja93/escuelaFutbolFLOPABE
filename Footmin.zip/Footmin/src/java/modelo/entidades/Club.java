/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Club")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Club.findAll", query = "SELECT c FROM Club c")
    , @NamedQuery(name = "Club.findByIdClub", query = "SELECT c FROM Club c WHERE c.idClub = :idClub")
    , @NamedQuery(name = "Club.findByCodClub", query = "SELECT c FROM Club c WHERE c.codClub = :codClub")
    , @NamedQuery(name = "Club.findByDireccion", query = "SELECT c FROM Club c WHERE c.direccion = :direccion")
    , @NamedQuery(name = "Club.findByNombre", query = "SELECT c FROM Club c WHERE c.nombre = :nombre")
    , @NamedQuery(name = "Club.findByFechaFundacion", query = "SELECT c FROM Club c WHERE c.fechaFundacion = :fechaFundacion")
    , @NamedQuery(name = "Club.findByEstadio", query = "SELECT c FROM Club c WHERE c.estadio = :estadio")
    , @NamedQuery(name = "Club.findByEmail", query = "SELECT c FROM Club c WHERE c.email = :email")
    , @NamedQuery(name = "Club.findByTelefono", query = "SELECT c FROM Club c WHERE c.telefono = :telefono")})
public class Club implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idClub")
    private Integer idClub;
    @Size(max = 45)
    @Column(name = "codClub")
    private String codClub;
    @Size(max = 80)
    @Column(name = "direccion")
    private String direccion;
    @Size(max = 45)
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "fechaFundacion")
    @Temporal(TemporalType.DATE)
    private Date fechaFundacion;
    @Size(max = 45)
    @Column(name = "estadio")
    private String estadio;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Correo electrónico no válido")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 55)
    @Column(name = "email")
    private String email;
    @Size(max = 12)
    @Column(name = "telefono")
    private String telefono;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "club")
    private Collection<ClubEmpleado> clubEmpleadoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "club")
    private Collection<Equipo> equipoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "club")
    private Collection<ClienteClub> clienteClubCollection;

    public Club() {
    }

    public Club(Integer idClub) {
        this.idClub = idClub;
    }

    public Integer getIdClub() {
        return idClub;
    }

    public void setIdClub(Integer idClub) {
        this.idClub = idClub;
    }

    public String getCodClub() {
        return codClub;
    }

    public void setCodClub(String codClub) {
        this.codClub = codClub;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaFundacion() {
        return fechaFundacion;
    }

    public void setFechaFundacion(Date fechaFundacion) {
        this.fechaFundacion = fechaFundacion;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @XmlTransient
    public Collection<ClubEmpleado> getClubEmpleadoCollection() {
        return clubEmpleadoCollection;
    }

    public void setClubEmpleadoCollection(Collection<ClubEmpleado> clubEmpleadoCollection) {
        this.clubEmpleadoCollection = clubEmpleadoCollection;
    }

    @XmlTransient
    public Collection<Equipo> getEquipoCollection() {
        return equipoCollection;
    }

    public void setEquipoCollection(Collection<Equipo> equipoCollection) {
        this.equipoCollection = equipoCollection;
    }

    @XmlTransient
    public Collection<ClienteClub> getClienteClubCollection() {
        return clienteClubCollection;
    }

    public void setClienteClubCollection(Collection<ClienteClub> clienteClubCollection) {
        this.clienteClubCollection = clienteClubCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idClub != null ? idClub.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Club)) {
            return false;
        }
        Club other = (Club) object;
        if ((this.idClub == null && other.idClub != null) || (this.idClub != null && !this.idClub.equals(other.idClub))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Club[ idClub=" + idClub + " ]";
    }
    
}
