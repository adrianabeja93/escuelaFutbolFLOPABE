/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Jugador_Partido")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "JugadorPartido.findAll", query = "SELECT j FROM JugadorPartido j")
    , @NamedQuery(name = "JugadorPartido.findByGoles", query = "SELECT j FROM JugadorPartido j WHERE j.goles = :goles")
    , @NamedQuery(name = "JugadorPartido.findByAsistencias", query = "SELECT j FROM JugadorPartido j WHERE j.asistencias = :asistencias")
    , @NamedQuery(name = "JugadorPartido.findByTarjetasAmarillas", query = "SELECT j FROM JugadorPartido j WHERE j.tarjetasAmarillas = :tarjetasAmarillas")
    , @NamedQuery(name = "JugadorPartido.findByTarjetaRoja", query = "SELECT j FROM JugadorPartido j WHERE j.tarjetaRoja = :tarjetaRoja")
    , @NamedQuery(name = "JugadorPartido.findByConvocado", query = "SELECT j FROM JugadorPartido j WHERE j.convocado = :convocado")
    , @NamedQuery(name = "JugadorPartido.findByMinutosDisputados", query = "SELECT j FROM JugadorPartido j WHERE j.minutosDisputados = :minutosDisputados")
    , @NamedQuery(name = "JugadorPartido.findById", query = "SELECT j FROM JugadorPartido j WHERE j.id = :id")})
public class JugadorPartido implements Serializable {

    private static final long serialVersionUID = 1L;
    @Column(name = "goles")
    private Integer goles;
    @Column(name = "asistencias")
    private Integer asistencias;
    @Column(name = "tarjetasAmarillas")
    private Integer tarjetasAmarillas;
    @Column(name = "tarjetaRoja")
    private Integer tarjetaRoja;
    @Column(name = "convocado")
    private int convocado;
    @Column(name = "minutosDisputados")
    private Integer minutosDisputados;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private Long id;
    @JoinColumn(name = "jugador", referencedColumnName = "idJugador")
    @ManyToOne(optional = false)
    private Jugador jugador;
    @JoinColumn(name = "partido", referencedColumnName = "idPartido")
    @ManyToOne(optional = false)
    private Partido partido;

    public JugadorPartido() {
    }

    public JugadorPartido(Long id) {
        this.id = id;
    }

    public Integer getGoles() {
        return goles;
    }

    public void setGoles(Integer goles) {
        this.goles = goles;
    }

    public Integer getAsistencias() {
        return asistencias;
    }

    public void setAsistencias(Integer asistencias) {
        this.asistencias = asistencias;
    }

    public Integer getTarjetasAmarillas() {
        return tarjetasAmarillas;
    }

    public void setTarjetasAmarillas(Integer tarjetasAmarillas) {
        this.tarjetasAmarillas = tarjetasAmarillas;
    }

    public Integer getTarjetaRoja() {
        return tarjetaRoja;
    }

    public void setTarjetaRoja(Integer tarjetaRoja) {
        this.tarjetaRoja = tarjetaRoja;
    }

    public int getConvocado() {
        return convocado;
    }

    public void setConvocado(int convocado) {
        this.convocado = convocado;
    }

    public Integer getMinutosDisputados() {
        return minutosDisputados;
    }

    public void setMinutosDisputados(Integer minutosDisputados) {
        this.minutosDisputados = minutosDisputados;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public Partido getPartido() {
        return partido;
    }

    public void setPartido(Partido partido) {
        this.partido = partido;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof JugadorPartido)) {
            return false;
        }
        JugadorPartido other = (JugadorPartido) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.JugadorPartido[ id=" + id + " ]";
    }
    
}
