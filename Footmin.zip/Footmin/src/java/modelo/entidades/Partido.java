/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Partido")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Partido.findAll", query = "SELECT p FROM Partido p")
    , @NamedQuery(name = "Partido.findByIdPartido", query = "SELECT p FROM Partido p WHERE p.idPartido = :idPartido")
    , @NamedQuery(name = "Partido.findByMarcadorLocal", query = "SELECT p FROM Partido p WHERE p.marcadorLocal = :marcadorLocal")
    , @NamedQuery(name = "Partido.findByMarcadorRival", query = "SELECT p FROM Partido p WHERE p.marcadorRival = :marcadorRival")
    , @NamedQuery(name = "Partido.findByFechaHora", query = "SELECT p FROM Partido p WHERE p.fechaHora = :fechaHora")
    , @NamedQuery(name = "Partido.findByLugar", query = "SELECT p FROM Partido p WHERE p.lugar = :lugar")
    , @NamedQuery(name = "Partido.findByTipo", query = "SELECT p FROM Partido p WHERE p.tipo = :tipo")
    , @NamedQuery(name = "Partido.findByTerrenoJuego", query = "SELECT p FROM Partido p WHERE p.terrenoJuego = :terrenoJuego")
    , @NamedQuery(name = "Partido.findByRival", query = "SELECT p FROM Partido p WHERE p.rival = :rival")
    , @NamedQuery(name = "Partido.findByJornada", query = "SELECT p FROM Partido p WHERE p.jornada = :jornada")})
public class Partido implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idPartido")
    private Long idPartido;
    @Column(name = "marcadorLocal")
    private Integer marcadorLocal;
    @Column(name = "marcadorRival")
    private Integer marcadorRival;
    @Column(name = "fechaHora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    @Size(max = 100)
    @Column(name = "lugar")
    private String lugar;
    @Size(max = 45)
    @Column(name = "tipo")
    private String tipo;
    @Size(max = 55)
    @Column(name = "terrenoJuego")
    private String terrenoJuego;
    @Size(max = 45)
    @Column(name = "rival")
    private String rival;
    @Size(max = 25)
    @Column(name = "jornada")
    private String jornada;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "partido")
    private Collection<JugadorPartido> jugadorPartidoCollection;

    public Partido() {
    }

    public Partido(Long idPartido) {
        this.idPartido = idPartido;
    }

    public Long getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(Long idPartido) {
        this.idPartido = idPartido;
    }

    public Integer getMarcadorLocal() {
        return marcadorLocal;
    }

    public void setMarcadorLocal(Integer marcadorLocal) {
        this.marcadorLocal = marcadorLocal;
    }

    public Integer getMarcadorRival() {
        return marcadorRival;
    }

    public void setMarcadorRival(Integer marcadorRival) {
        this.marcadorRival = marcadorRival;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTerrenoJuego() {
        return terrenoJuego;
    }

    public void setTerrenoJuego(String terrenoJuego) {
        this.terrenoJuego = terrenoJuego;
    }

    public String getRival() {
        return rival;
    }

    public void setRival(String rival) {
        this.rival = rival;
    }

    public String getJornada() {
        return jornada;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }

    @XmlTransient
    public Collection<JugadorPartido> getJugadorPartidoCollection() {
        return jugadorPartidoCollection;
    }

    public void setJugadorPartidoCollection(Collection<JugadorPartido> jugadorPartidoCollection) {
        this.jugadorPartidoCollection = jugadorPartidoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPartido != null ? idPartido.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Partido)) {
            return false;
        }
        Partido other = (Partido) object;
        if ((this.idPartido == null && other.idPartido != null) || (this.idPartido != null && !this.idPartido.equals(other.idPartido))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Partido[ idPartido=" + idPartido + " ]";
    }
    
}
