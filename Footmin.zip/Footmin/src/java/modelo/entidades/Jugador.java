/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Jugador")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Jugador.findAll", query = "SELECT j FROM Jugador j")
    , @NamedQuery(name = "Jugador.findByIdJugador", query = "SELECT j FROM Jugador j WHERE j.idJugador = :idJugador")
    , @NamedQuery(name = "Jugador.findByDni", query = "SELECT j FROM Jugador j WHERE j.dni = :dni")
    , @NamedQuery(name = "Jugador.findByActivo", query = "SELECT j FROM Jugador j WHERE j.activo = :activo")
    , @NamedQuery(name = "Jugador.findByFechaNacimiento", query = "SELECT j FROM Jugador j WHERE j.fechaNacimiento = :fechaNacimiento")
    , @NamedQuery(name = "Jugador.findByNombre", query = "SELECT j FROM Jugador j WHERE j.nombre = :nombre")
    , @NamedQuery(name = "Jugador.findByApellido1", query = "SELECT j FROM Jugador j WHERE j.apellido1 = :apellido1")
    , @NamedQuery(name = "Jugador.findByApellido2", query = "SELECT j FROM Jugador j WHERE j.apellido2 = :apellido2")})
public class Jugador implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idJugador")
    private Integer idJugador;
    @Size(max = 10)
    @Column(name = "dni")
    private String dni;
    @Basic(optional = false)
    @NotNull
    @Column(name = "activo")
    private short activo;
    @Column(name = "fechaNacimiento")
    @Temporal(TemporalType.DATE)
    private Date fechaNacimiento;
    @Size(max = 45)
    @Column(name = "nombre")
    private String nombre;
    @Size(max = 45)
    @Column(name = "apellido1")
    private String apellido1;
    @Size(max = 45)
    @Column(name = "apellido2")
    private String apellido2;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "jugador")
    private Collection<EquipoJugador> equipoJugadorCollection;
    @JoinColumn(name = "tutorLegal", referencedColumnName = "nombreUsuario")
    @OneToOne(optional = false)
    private Cliente tutorLegal;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "jugador")
    private Collection<JugadorPartido> jugadorPartidoCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "jugador")
    private Collection<JugadorEntrenamiento> jugadorEntrenamientoCollection;

    public Jugador() {
    }

    public Jugador(Integer idJugador) {
        this.idJugador = idJugador;
    }

    public Jugador(Integer idJugador, short activo) {
        this.idJugador = idJugador;
        this.activo = activo;
    }

    public Integer getIdJugador() {
        return idJugador;
    }

    public void setIdJugador(Integer idJugador) {
        this.idJugador = idJugador;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public short getActivo() {
        return activo;
    }

    public void setActivo(short activo) {
        this.activo = activo;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    @XmlTransient
    public Collection<EquipoJugador> getEquipoJugadorCollection() {
        return equipoJugadorCollection;
    }

    public void setEquipoJugadorCollection(Collection<EquipoJugador> equipoJugadorCollection) {
        this.equipoJugadorCollection = equipoJugadorCollection;
    }

    public Cliente getTutorLegal() {
        return tutorLegal;
    }

    public void setTutorLegal(Cliente tutorLegal) {
        this.tutorLegal = tutorLegal;
    }

    @XmlTransient
    public Collection<JugadorPartido> getJugadorPartidoCollection() {
        return jugadorPartidoCollection;
    }

    public void setJugadorPartidoCollection(Collection<JugadorPartido> jugadorPartidoCollection) {
        this.jugadorPartidoCollection = jugadorPartidoCollection;
    }

    @XmlTransient
    public Collection<JugadorEntrenamiento> getJugadorEntrenamientoCollection() {
        return jugadorEntrenamientoCollection;
    }

    public void setJugadorEntrenamientoCollection(Collection<JugadorEntrenamiento> jugadorEntrenamientoCollection) {
        this.jugadorEntrenamientoCollection = jugadorEntrenamientoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idJugador != null ? idJugador.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Jugador)) {
            return false;
        }
        Jugador other = (Jugador) object;
        if ((this.idJugador == null && other.idJugador != null) || (this.idJugador != null && !this.idJugador.equals(other.idJugador))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Jugador[ idJugador=" + idJugador + " ]";
    }
    
}
