/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adrian
 */
@Entity
@Table(name = "Equipo_Jugador")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EquipoJugador.findAll", query = "SELECT e FROM EquipoJugador e")
    , @NamedQuery(name = "EquipoJugador.findByTemporada", query = "SELECT e FROM EquipoJugador e WHERE e.temporada = :temporada")
    , @NamedQuery(name = "EquipoJugador.findByFederado", query = "SELECT e FROM EquipoJugador e WHERE e.federado = :federado")
    , @NamedQuery(name = "EquipoJugador.findById", query = "SELECT e FROM EquipoJugador e WHERE e.id = :id")})
public class EquipoJugador implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 20)
    @Column(name = "temporada")
    private String temporada;
    @Column(name = "federado")
    private Short federado;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private Long id;
    @JoinColumn(name = "equipo", referencedColumnName = "idEquipo")
    @ManyToOne(optional = false)
    private Equipo equipo;
    @JoinColumn(name = "jugador", referencedColumnName = "idJugador")
    @ManyToOne(optional = false)
    private Jugador jugador;

    public EquipoJugador() {
    }

    public EquipoJugador(Long id) {
        this.id = id;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public Short getFederado() {
        return federado;
    }

    public void setFederado(Short federado) {
        this.federado = federado;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EquipoJugador)) {
            return false;
        }
        EquipoJugador other = (EquipoJugador) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.EquipoJugador[ id=" + id + " ]";
    }
    
}
