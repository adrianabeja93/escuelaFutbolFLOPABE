/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.Club;
import modelo.entidades.EquipoEmpleado;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoJugador;

/**
 *
 * @author adrian
 */
public class EquipoJpaController implements Serializable {

    public EquipoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Equipo equipo) throws RollbackFailureException, Exception {
        if (equipo.getEquipoEmpleadoCollection() == null) {
            equipo.setEquipoEmpleadoCollection(new ArrayList<EquipoEmpleado>());
        }
        if (equipo.getEquipoJugadorCollection() == null) {
            equipo.setEquipoJugadorCollection(new ArrayList<EquipoJugador>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Club club = equipo.getClub();
            if (club != null) {
                club = em.getReference(club.getClass(), club.getIdClub());
                equipo.setClub(club);
            }
            Collection<EquipoEmpleado> attachedEquipoEmpleadoCollection = new ArrayList<EquipoEmpleado>();
            for (EquipoEmpleado equipoEmpleadoCollectionEquipoEmpleadoToAttach : equipo.getEquipoEmpleadoCollection()) {
                equipoEmpleadoCollectionEquipoEmpleadoToAttach = em.getReference(equipoEmpleadoCollectionEquipoEmpleadoToAttach.getClass(), equipoEmpleadoCollectionEquipoEmpleadoToAttach.getId());
                attachedEquipoEmpleadoCollection.add(equipoEmpleadoCollectionEquipoEmpleadoToAttach);
            }
            equipo.setEquipoEmpleadoCollection(attachedEquipoEmpleadoCollection);
            Collection<EquipoJugador> attachedEquipoJugadorCollection = new ArrayList<EquipoJugador>();
            for (EquipoJugador equipoJugadorCollectionEquipoJugadorToAttach : equipo.getEquipoJugadorCollection()) {
                equipoJugadorCollectionEquipoJugadorToAttach = em.getReference(equipoJugadorCollectionEquipoJugadorToAttach.getClass(), equipoJugadorCollectionEquipoJugadorToAttach.getId());
                attachedEquipoJugadorCollection.add(equipoJugadorCollectionEquipoJugadorToAttach);
            }
            equipo.setEquipoJugadorCollection(attachedEquipoJugadorCollection);
            em.persist(equipo);
            if (club != null) {
                club.getEquipoCollection().add(equipo);
                club = em.merge(club);
            }
            for (EquipoEmpleado equipoEmpleadoCollectionEquipoEmpleado : equipo.getEquipoEmpleadoCollection()) {
                Equipo oldEquipoOfEquipoEmpleadoCollectionEquipoEmpleado = equipoEmpleadoCollectionEquipoEmpleado.getEquipo();
                equipoEmpleadoCollectionEquipoEmpleado.setEquipo(equipo);
                equipoEmpleadoCollectionEquipoEmpleado = em.merge(equipoEmpleadoCollectionEquipoEmpleado);
                if (oldEquipoOfEquipoEmpleadoCollectionEquipoEmpleado != null) {
                    oldEquipoOfEquipoEmpleadoCollectionEquipoEmpleado.getEquipoEmpleadoCollection().remove(equipoEmpleadoCollectionEquipoEmpleado);
                    oldEquipoOfEquipoEmpleadoCollectionEquipoEmpleado = em.merge(oldEquipoOfEquipoEmpleadoCollectionEquipoEmpleado);
                }
            }
            for (EquipoJugador equipoJugadorCollectionEquipoJugador : equipo.getEquipoJugadorCollection()) {
                Equipo oldEquipoOfEquipoJugadorCollectionEquipoJugador = equipoJugadorCollectionEquipoJugador.getEquipo();
                equipoJugadorCollectionEquipoJugador.setEquipo(equipo);
                equipoJugadorCollectionEquipoJugador = em.merge(equipoJugadorCollectionEquipoJugador);
                if (oldEquipoOfEquipoJugadorCollectionEquipoJugador != null) {
                    oldEquipoOfEquipoJugadorCollectionEquipoJugador.getEquipoJugadorCollection().remove(equipoJugadorCollectionEquipoJugador);
                    oldEquipoOfEquipoJugadorCollectionEquipoJugador = em.merge(oldEquipoOfEquipoJugadorCollectionEquipoJugador);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Equipo equipo) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Equipo persistentEquipo = em.find(Equipo.class, equipo.getIdEquipo());
            Club clubOld = persistentEquipo.getClub();
            Club clubNew = equipo.getClub();
            Collection<EquipoEmpleado> equipoEmpleadoCollectionOld = persistentEquipo.getEquipoEmpleadoCollection();
            Collection<EquipoEmpleado> equipoEmpleadoCollectionNew = equipo.getEquipoEmpleadoCollection();
            Collection<EquipoJugador> equipoJugadorCollectionOld = persistentEquipo.getEquipoJugadorCollection();
            Collection<EquipoJugador> equipoJugadorCollectionNew = equipo.getEquipoJugadorCollection();
            List<String> illegalOrphanMessages = null;
            for (EquipoEmpleado equipoEmpleadoCollectionOldEquipoEmpleado : equipoEmpleadoCollectionOld) {
                if (!equipoEmpleadoCollectionNew.contains(equipoEmpleadoCollectionOldEquipoEmpleado)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain EquipoEmpleado " + equipoEmpleadoCollectionOldEquipoEmpleado + " since its equipo field is not nullable.");
                }
            }
            for (EquipoJugador equipoJugadorCollectionOldEquipoJugador : equipoJugadorCollectionOld) {
                if (!equipoJugadorCollectionNew.contains(equipoJugadorCollectionOldEquipoJugador)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain EquipoJugador " + equipoJugadorCollectionOldEquipoJugador + " since its equipo field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (clubNew != null) {
                clubNew = em.getReference(clubNew.getClass(), clubNew.getIdClub());
                equipo.setClub(clubNew);
            }
            Collection<EquipoEmpleado> attachedEquipoEmpleadoCollectionNew = new ArrayList<EquipoEmpleado>();
            for (EquipoEmpleado equipoEmpleadoCollectionNewEquipoEmpleadoToAttach : equipoEmpleadoCollectionNew) {
                equipoEmpleadoCollectionNewEquipoEmpleadoToAttach = em.getReference(equipoEmpleadoCollectionNewEquipoEmpleadoToAttach.getClass(), equipoEmpleadoCollectionNewEquipoEmpleadoToAttach.getId());
                attachedEquipoEmpleadoCollectionNew.add(equipoEmpleadoCollectionNewEquipoEmpleadoToAttach);
            }
            equipoEmpleadoCollectionNew = attachedEquipoEmpleadoCollectionNew;
            equipo.setEquipoEmpleadoCollection(equipoEmpleadoCollectionNew);
            Collection<EquipoJugador> attachedEquipoJugadorCollectionNew = new ArrayList<EquipoJugador>();
            for (EquipoJugador equipoJugadorCollectionNewEquipoJugadorToAttach : equipoJugadorCollectionNew) {
                equipoJugadorCollectionNewEquipoJugadorToAttach = em.getReference(equipoJugadorCollectionNewEquipoJugadorToAttach.getClass(), equipoJugadorCollectionNewEquipoJugadorToAttach.getId());
                attachedEquipoJugadorCollectionNew.add(equipoJugadorCollectionNewEquipoJugadorToAttach);
            }
            equipoJugadorCollectionNew = attachedEquipoJugadorCollectionNew;
            equipo.setEquipoJugadorCollection(equipoJugadorCollectionNew);
            equipo = em.merge(equipo);
            if (clubOld != null && !clubOld.equals(clubNew)) {
                clubOld.getEquipoCollection().remove(equipo);
                clubOld = em.merge(clubOld);
            }
            if (clubNew != null && !clubNew.equals(clubOld)) {
                clubNew.getEquipoCollection().add(equipo);
                clubNew = em.merge(clubNew);
            }
            for (EquipoEmpleado equipoEmpleadoCollectionNewEquipoEmpleado : equipoEmpleadoCollectionNew) {
                if (!equipoEmpleadoCollectionOld.contains(equipoEmpleadoCollectionNewEquipoEmpleado)) {
                    Equipo oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado = equipoEmpleadoCollectionNewEquipoEmpleado.getEquipo();
                    equipoEmpleadoCollectionNewEquipoEmpleado.setEquipo(equipo);
                    equipoEmpleadoCollectionNewEquipoEmpleado = em.merge(equipoEmpleadoCollectionNewEquipoEmpleado);
                    if (oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado != null && !oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado.equals(equipo)) {
                        oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado.getEquipoEmpleadoCollection().remove(equipoEmpleadoCollectionNewEquipoEmpleado);
                        oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado = em.merge(oldEquipoOfEquipoEmpleadoCollectionNewEquipoEmpleado);
                    }
                }
            }
            for (EquipoJugador equipoJugadorCollectionNewEquipoJugador : equipoJugadorCollectionNew) {
                if (!equipoJugadorCollectionOld.contains(equipoJugadorCollectionNewEquipoJugador)) {
                    Equipo oldEquipoOfEquipoJugadorCollectionNewEquipoJugador = equipoJugadorCollectionNewEquipoJugador.getEquipo();
                    equipoJugadorCollectionNewEquipoJugador.setEquipo(equipo);
                    equipoJugadorCollectionNewEquipoJugador = em.merge(equipoJugadorCollectionNewEquipoJugador);
                    if (oldEquipoOfEquipoJugadorCollectionNewEquipoJugador != null && !oldEquipoOfEquipoJugadorCollectionNewEquipoJugador.equals(equipo)) {
                        oldEquipoOfEquipoJugadorCollectionNewEquipoJugador.getEquipoJugadorCollection().remove(equipoJugadorCollectionNewEquipoJugador);
                        oldEquipoOfEquipoJugadorCollectionNewEquipoJugador = em.merge(oldEquipoOfEquipoJugadorCollectionNewEquipoJugador);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = equipo.getIdEquipo();
                if (findEquipo(id) == null) {
                    throw new NonexistentEntityException("The equipo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Equipo equipo;
            try {
                equipo = em.getReference(Equipo.class, id);
                equipo.getIdEquipo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The equipo with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<EquipoEmpleado> equipoEmpleadoCollectionOrphanCheck = equipo.getEquipoEmpleadoCollection();
            for (EquipoEmpleado equipoEmpleadoCollectionOrphanCheckEquipoEmpleado : equipoEmpleadoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Equipo (" + equipo + ") cannot be destroyed since the EquipoEmpleado " + equipoEmpleadoCollectionOrphanCheckEquipoEmpleado + " in its equipoEmpleadoCollection field has a non-nullable equipo field.");
            }
            Collection<EquipoJugador> equipoJugadorCollectionOrphanCheck = equipo.getEquipoJugadorCollection();
            for (EquipoJugador equipoJugadorCollectionOrphanCheckEquipoJugador : equipoJugadorCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Equipo (" + equipo + ") cannot be destroyed since the EquipoJugador " + equipoJugadorCollectionOrphanCheckEquipoJugador + " in its equipoJugadorCollection field has a non-nullable equipo field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Club club = equipo.getClub();
            if (club != null) {
                club.getEquipoCollection().remove(equipo);
                club = em.merge(club);
            }
            em.remove(equipo);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Equipo> findEquipoEntities() {
        return findEquipoEntities(true, -1, -1);
    }

    public List<Equipo> findEquipoEntities(int maxResults, int firstResult) {
        return findEquipoEntities(false, maxResults, firstResult);
    }

    private List<Equipo> findEquipoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Equipo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Equipo findEquipo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Equipo.class, id);
        } finally {
            em.close();
        }
    }

    public int getEquipoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Equipo> rt = cq.from(Equipo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
