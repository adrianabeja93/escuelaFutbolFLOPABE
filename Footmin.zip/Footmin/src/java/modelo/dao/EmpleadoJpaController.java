/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.EquipoEmpleado;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.ClubEmpleado;
import modelo.entidades.Empleado;

/**
 *
 * @author adrian
 */
public class EmpleadoJpaController implements Serializable {

    public EmpleadoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Empleado empleado) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (empleado.getEquipoEmpleadoCollection() == null) {
            empleado.setEquipoEmpleadoCollection(new ArrayList<EquipoEmpleado>());
        }
        if (empleado.getClubEmpleadoCollection() == null) {
            empleado.setClubEmpleadoCollection(new ArrayList<ClubEmpleado>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<EquipoEmpleado> attachedEquipoEmpleadoCollection = new ArrayList<EquipoEmpleado>();
            for (EquipoEmpleado equipoEmpleadoCollectionEquipoEmpleadoToAttach : empleado.getEquipoEmpleadoCollection()) {
                equipoEmpleadoCollectionEquipoEmpleadoToAttach = em.getReference(equipoEmpleadoCollectionEquipoEmpleadoToAttach.getClass(), equipoEmpleadoCollectionEquipoEmpleadoToAttach.getId());
                attachedEquipoEmpleadoCollection.add(equipoEmpleadoCollectionEquipoEmpleadoToAttach);
            }
            empleado.setEquipoEmpleadoCollection(attachedEquipoEmpleadoCollection);
            Collection<ClubEmpleado> attachedClubEmpleadoCollection = new ArrayList<ClubEmpleado>();
            for (ClubEmpleado clubEmpleadoCollectionClubEmpleadoToAttach : empleado.getClubEmpleadoCollection()) {
                clubEmpleadoCollectionClubEmpleadoToAttach = em.getReference(clubEmpleadoCollectionClubEmpleadoToAttach.getClass(), clubEmpleadoCollectionClubEmpleadoToAttach.getId());
                attachedClubEmpleadoCollection.add(clubEmpleadoCollectionClubEmpleadoToAttach);
            }
            empleado.setClubEmpleadoCollection(attachedClubEmpleadoCollection);
            em.persist(empleado);
            for (EquipoEmpleado equipoEmpleadoCollectionEquipoEmpleado : empleado.getEquipoEmpleadoCollection()) {
                Empleado oldEmpleadoOfEquipoEmpleadoCollectionEquipoEmpleado = equipoEmpleadoCollectionEquipoEmpleado.getEmpleado();
                equipoEmpleadoCollectionEquipoEmpleado.setEmpleado(empleado);
                equipoEmpleadoCollectionEquipoEmpleado = em.merge(equipoEmpleadoCollectionEquipoEmpleado);
                if (oldEmpleadoOfEquipoEmpleadoCollectionEquipoEmpleado != null) {
                    oldEmpleadoOfEquipoEmpleadoCollectionEquipoEmpleado.getEquipoEmpleadoCollection().remove(equipoEmpleadoCollectionEquipoEmpleado);
                    oldEmpleadoOfEquipoEmpleadoCollectionEquipoEmpleado = em.merge(oldEmpleadoOfEquipoEmpleadoCollectionEquipoEmpleado);
                }
            }
            for (ClubEmpleado clubEmpleadoCollectionClubEmpleado : empleado.getClubEmpleadoCollection()) {
                Empleado oldEmpleadoOfClubEmpleadoCollectionClubEmpleado = clubEmpleadoCollectionClubEmpleado.getEmpleado();
                clubEmpleadoCollectionClubEmpleado.setEmpleado(empleado);
                clubEmpleadoCollectionClubEmpleado = em.merge(clubEmpleadoCollectionClubEmpleado);
                if (oldEmpleadoOfClubEmpleadoCollectionClubEmpleado != null) {
                    oldEmpleadoOfClubEmpleadoCollectionClubEmpleado.getClubEmpleadoCollection().remove(clubEmpleadoCollectionClubEmpleado);
                    oldEmpleadoOfClubEmpleadoCollectionClubEmpleado = em.merge(oldEmpleadoOfClubEmpleadoCollectionClubEmpleado);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findEmpleado(empleado.getNombreUsuario()) != null) {
                throw new PreexistingEntityException("Empleado " + empleado + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Empleado empleado) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Empleado persistentEmpleado = em.find(Empleado.class, empleado.getNombreUsuario());
            Collection<EquipoEmpleado> equipoEmpleadoCollectionOld = persistentEmpleado.getEquipoEmpleadoCollection();
            Collection<EquipoEmpleado> equipoEmpleadoCollectionNew = empleado.getEquipoEmpleadoCollection();
            Collection<ClubEmpleado> clubEmpleadoCollectionOld = persistentEmpleado.getClubEmpleadoCollection();
            Collection<ClubEmpleado> clubEmpleadoCollectionNew = empleado.getClubEmpleadoCollection();
            List<String> illegalOrphanMessages = null;
            for (EquipoEmpleado equipoEmpleadoCollectionOldEquipoEmpleado : equipoEmpleadoCollectionOld) {
                if (!equipoEmpleadoCollectionNew.contains(equipoEmpleadoCollectionOldEquipoEmpleado)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain EquipoEmpleado " + equipoEmpleadoCollectionOldEquipoEmpleado + " since its empleado field is not nullable.");
                }
            }
            for (ClubEmpleado clubEmpleadoCollectionOldClubEmpleado : clubEmpleadoCollectionOld) {
                if (!clubEmpleadoCollectionNew.contains(clubEmpleadoCollectionOldClubEmpleado)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ClubEmpleado " + clubEmpleadoCollectionOldClubEmpleado + " since its empleado field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<EquipoEmpleado> attachedEquipoEmpleadoCollectionNew = new ArrayList<EquipoEmpleado>();
            for (EquipoEmpleado equipoEmpleadoCollectionNewEquipoEmpleadoToAttach : equipoEmpleadoCollectionNew) {
                equipoEmpleadoCollectionNewEquipoEmpleadoToAttach = em.getReference(equipoEmpleadoCollectionNewEquipoEmpleadoToAttach.getClass(), equipoEmpleadoCollectionNewEquipoEmpleadoToAttach.getId());
                attachedEquipoEmpleadoCollectionNew.add(equipoEmpleadoCollectionNewEquipoEmpleadoToAttach);
            }
            equipoEmpleadoCollectionNew = attachedEquipoEmpleadoCollectionNew;
            empleado.setEquipoEmpleadoCollection(equipoEmpleadoCollectionNew);
            Collection<ClubEmpleado> attachedClubEmpleadoCollectionNew = new ArrayList<ClubEmpleado>();
            for (ClubEmpleado clubEmpleadoCollectionNewClubEmpleadoToAttach : clubEmpleadoCollectionNew) {
                clubEmpleadoCollectionNewClubEmpleadoToAttach = em.getReference(clubEmpleadoCollectionNewClubEmpleadoToAttach.getClass(), clubEmpleadoCollectionNewClubEmpleadoToAttach.getId());
                attachedClubEmpleadoCollectionNew.add(clubEmpleadoCollectionNewClubEmpleadoToAttach);
            }
            clubEmpleadoCollectionNew = attachedClubEmpleadoCollectionNew;
            empleado.setClubEmpleadoCollection(clubEmpleadoCollectionNew);
            empleado = em.merge(empleado);
            for (EquipoEmpleado equipoEmpleadoCollectionNewEquipoEmpleado : equipoEmpleadoCollectionNew) {
                if (!equipoEmpleadoCollectionOld.contains(equipoEmpleadoCollectionNewEquipoEmpleado)) {
                    Empleado oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado = equipoEmpleadoCollectionNewEquipoEmpleado.getEmpleado();
                    equipoEmpleadoCollectionNewEquipoEmpleado.setEmpleado(empleado);
                    equipoEmpleadoCollectionNewEquipoEmpleado = em.merge(equipoEmpleadoCollectionNewEquipoEmpleado);
                    if (oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado != null && !oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado.equals(empleado)) {
                        oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado.getEquipoEmpleadoCollection().remove(equipoEmpleadoCollectionNewEquipoEmpleado);
                        oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado = em.merge(oldEmpleadoOfEquipoEmpleadoCollectionNewEquipoEmpleado);
                    }
                }
            }
            for (ClubEmpleado clubEmpleadoCollectionNewClubEmpleado : clubEmpleadoCollectionNew) {
                if (!clubEmpleadoCollectionOld.contains(clubEmpleadoCollectionNewClubEmpleado)) {
                    Empleado oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado = clubEmpleadoCollectionNewClubEmpleado.getEmpleado();
                    clubEmpleadoCollectionNewClubEmpleado.setEmpleado(empleado);
                    clubEmpleadoCollectionNewClubEmpleado = em.merge(clubEmpleadoCollectionNewClubEmpleado);
                    if (oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado != null && !oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado.equals(empleado)) {
                        oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado.getClubEmpleadoCollection().remove(clubEmpleadoCollectionNewClubEmpleado);
                        oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado = em.merge(oldEmpleadoOfClubEmpleadoCollectionNewClubEmpleado);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = empleado.getNombreUsuario();
                if (findEmpleado(id) == null) {
                    throw new NonexistentEntityException("The empleado with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Empleado empleado;
            try {
                empleado = em.getReference(Empleado.class, id);
                empleado.getNombreUsuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The empleado with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<EquipoEmpleado> equipoEmpleadoCollectionOrphanCheck = empleado.getEquipoEmpleadoCollection();
            for (EquipoEmpleado equipoEmpleadoCollectionOrphanCheckEquipoEmpleado : equipoEmpleadoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Empleado (" + empleado + ") cannot be destroyed since the EquipoEmpleado " + equipoEmpleadoCollectionOrphanCheckEquipoEmpleado + " in its equipoEmpleadoCollection field has a non-nullable empleado field.");
            }
            Collection<ClubEmpleado> clubEmpleadoCollectionOrphanCheck = empleado.getClubEmpleadoCollection();
            for (ClubEmpleado clubEmpleadoCollectionOrphanCheckClubEmpleado : clubEmpleadoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Empleado (" + empleado + ") cannot be destroyed since the ClubEmpleado " + clubEmpleadoCollectionOrphanCheckClubEmpleado + " in its clubEmpleadoCollection field has a non-nullable empleado field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(empleado);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Empleado> findEmpleadoEntities() {
        return findEmpleadoEntities(true, -1, -1);
    }

    public List<Empleado> findEmpleadoEntities(int maxResults, int firstResult) {
        return findEmpleadoEntities(false, maxResults, firstResult);
    }

    private List<Empleado> findEmpleadoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Empleado.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Empleado findEmpleado(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Empleado.class, id);
        } finally {
            em.close();
        }
    }

    public int getEmpleadoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Empleado> rt = cq.from(Empleado.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
