/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoJugador;
import modelo.entidades.Jugador;

/**
 *
 * @author adrian
 */
public class EquipoJugadorJpaController implements Serializable {

    public EquipoJugadorJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(EquipoJugador equipoJugador) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Equipo equipo = equipoJugador.getEquipo();
            if (equipo != null) {
                equipo = em.getReference(equipo.getClass(), equipo.getIdEquipo());
                equipoJugador.setEquipo(equipo);
            }
            Jugador jugador = equipoJugador.getJugador();
            if (jugador != null) {
                jugador = em.getReference(jugador.getClass(), jugador.getIdJugador());
                equipoJugador.setJugador(jugador);
            }
            em.persist(equipoJugador);
            if (equipo != null) {
                equipo.getEquipoJugadorCollection().add(equipoJugador);
                equipo = em.merge(equipo);
            }
            if (jugador != null) {
                jugador.getEquipoJugadorCollection().add(equipoJugador);
                jugador = em.merge(jugador);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findEquipoJugador(equipoJugador.getId()) != null) {
                throw new PreexistingEntityException("EquipoJugador " + equipoJugador + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(EquipoJugador equipoJugador) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            EquipoJugador persistentEquipoJugador = em.find(EquipoJugador.class, equipoJugador.getId());
            Equipo equipoOld = persistentEquipoJugador.getEquipo();
            Equipo equipoNew = equipoJugador.getEquipo();
            Jugador jugadorOld = persistentEquipoJugador.getJugador();
            Jugador jugadorNew = equipoJugador.getJugador();
            if (equipoNew != null) {
                equipoNew = em.getReference(equipoNew.getClass(), equipoNew.getIdEquipo());
                equipoJugador.setEquipo(equipoNew);
            }
            if (jugadorNew != null) {
                jugadorNew = em.getReference(jugadorNew.getClass(), jugadorNew.getIdJugador());
                equipoJugador.setJugador(jugadorNew);
            }
            equipoJugador = em.merge(equipoJugador);
            if (equipoOld != null && !equipoOld.equals(equipoNew)) {
                equipoOld.getEquipoJugadorCollection().remove(equipoJugador);
                equipoOld = em.merge(equipoOld);
            }
            if (equipoNew != null && !equipoNew.equals(equipoOld)) {
                equipoNew.getEquipoJugadorCollection().add(equipoJugador);
                equipoNew = em.merge(equipoNew);
            }
            if (jugadorOld != null && !jugadorOld.equals(jugadorNew)) {
                jugadorOld.getEquipoJugadorCollection().remove(equipoJugador);
                jugadorOld = em.merge(jugadorOld);
            }
            if (jugadorNew != null && !jugadorNew.equals(jugadorOld)) {
                jugadorNew.getEquipoJugadorCollection().add(equipoJugador);
                jugadorNew = em.merge(jugadorNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = equipoJugador.getId();
                if (findEquipoJugador(id) == null) {
                    throw new NonexistentEntityException("The equipoJugador with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            EquipoJugador equipoJugador;
            try {
                equipoJugador = em.getReference(EquipoJugador.class, id);
                equipoJugador.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The equipoJugador with id " + id + " no longer exists.", enfe);
            }
            Equipo equipo = equipoJugador.getEquipo();
            if (equipo != null) {
                equipo.getEquipoJugadorCollection().remove(equipoJugador);
                equipo = em.merge(equipo);
            }
            Jugador jugador = equipoJugador.getJugador();
            if (jugador != null) {
                jugador.getEquipoJugadorCollection().remove(equipoJugador);
                jugador = em.merge(jugador);
            }
            em.remove(equipoJugador);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<EquipoJugador> findEquipoJugadorEntities() {
        return findEquipoJugadorEntities(true, -1, -1);
    }

    public List<EquipoJugador> findEquipoJugadorEntities(int maxResults, int firstResult) {
        return findEquipoJugadorEntities(false, maxResults, firstResult);
    }

    private List<EquipoJugador> findEquipoJugadorEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(EquipoJugador.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public EquipoJugador findEquipoJugador(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(EquipoJugador.class, id);
        } finally {
            em.close();
        }
    }

    public int getEquipoJugadorCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<EquipoJugador> rt = cq.from(EquipoJugador.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
