/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.Cliente;
import modelo.entidades.EquipoJugador;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorPartido;
import modelo.entidades.JugadorEntrenamiento;

/**
 *
 * @author adrian
 */
public class JugadorJpaController implements Serializable {

    public JugadorJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Jugador jugador) throws IllegalOrphanException, RollbackFailureException, Exception {
        if (jugador.getEquipoJugadorCollection() == null) {
            jugador.setEquipoJugadorCollection(new ArrayList<EquipoJugador>());
        }
        if (jugador.getJugadorPartidoCollection() == null) {
            jugador.setJugadorPartidoCollection(new ArrayList<JugadorPartido>());
        }
        if (jugador.getJugadorEntrenamientoCollection() == null) {
            jugador.setJugadorEntrenamientoCollection(new ArrayList<JugadorEntrenamiento>());
        }
        List<String> illegalOrphanMessages = null;
        Cliente tutorLegalOrphanCheck = jugador.getTutorLegal();
        if (tutorLegalOrphanCheck != null) {
            Jugador oldJugadorOfTutorLegal = tutorLegalOrphanCheck.getJugador();
            if (oldJugadorOfTutorLegal != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("The Cliente " + tutorLegalOrphanCheck + " already has an item of type Jugador whose tutorLegal column cannot be null. Please make another selection for the tutorLegal field.");
            }
        }
        if (illegalOrphanMessages != null) {
            throw new IllegalOrphanException(illegalOrphanMessages);
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente tutorLegal = jugador.getTutorLegal();
            if (tutorLegal != null) {
                tutorLegal = em.getReference(tutorLegal.getClass(), tutorLegal.getNombreUsuario());
                jugador.setTutorLegal(tutorLegal);
            }
            Collection<EquipoJugador> attachedEquipoJugadorCollection = new ArrayList<EquipoJugador>();
            for (EquipoJugador equipoJugadorCollectionEquipoJugadorToAttach : jugador.getEquipoJugadorCollection()) {
                equipoJugadorCollectionEquipoJugadorToAttach = em.getReference(equipoJugadorCollectionEquipoJugadorToAttach.getClass(), equipoJugadorCollectionEquipoJugadorToAttach.getId());
                attachedEquipoJugadorCollection.add(equipoJugadorCollectionEquipoJugadorToAttach);
            }
            jugador.setEquipoJugadorCollection(attachedEquipoJugadorCollection);
            Collection<JugadorPartido> attachedJugadorPartidoCollection = new ArrayList<JugadorPartido>();
            for (JugadorPartido jugadorPartidoCollectionJugadorPartidoToAttach : jugador.getJugadorPartidoCollection()) {
                jugadorPartidoCollectionJugadorPartidoToAttach = em.getReference(jugadorPartidoCollectionJugadorPartidoToAttach.getClass(), jugadorPartidoCollectionJugadorPartidoToAttach.getId());
                attachedJugadorPartidoCollection.add(jugadorPartidoCollectionJugadorPartidoToAttach);
            }
            jugador.setJugadorPartidoCollection(attachedJugadorPartidoCollection);
            Collection<JugadorEntrenamiento> attachedJugadorEntrenamientoCollection = new ArrayList<JugadorEntrenamiento>();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach : jugador.getJugadorEntrenamientoCollection()) {
                jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach = em.getReference(jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach.getClass(), jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach.getId());
                attachedJugadorEntrenamientoCollection.add(jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach);
            }
            jugador.setJugadorEntrenamientoCollection(attachedJugadorEntrenamientoCollection);
            em.persist(jugador);
            if (tutorLegal != null) {
                tutorLegal.setJugador(jugador);
                tutorLegal = em.merge(tutorLegal);
            }
            for (EquipoJugador equipoJugadorCollectionEquipoJugador : jugador.getEquipoJugadorCollection()) {
                Jugador oldJugadorOfEquipoJugadorCollectionEquipoJugador = equipoJugadorCollectionEquipoJugador.getJugador();
                equipoJugadorCollectionEquipoJugador.setJugador(jugador);
                equipoJugadorCollectionEquipoJugador = em.merge(equipoJugadorCollectionEquipoJugador);
                if (oldJugadorOfEquipoJugadorCollectionEquipoJugador != null) {
                    oldJugadorOfEquipoJugadorCollectionEquipoJugador.getEquipoJugadorCollection().remove(equipoJugadorCollectionEquipoJugador);
                    oldJugadorOfEquipoJugadorCollectionEquipoJugador = em.merge(oldJugadorOfEquipoJugadorCollectionEquipoJugador);
                }
            }
            for (JugadorPartido jugadorPartidoCollectionJugadorPartido : jugador.getJugadorPartidoCollection()) {
                Jugador oldJugadorOfJugadorPartidoCollectionJugadorPartido = jugadorPartidoCollectionJugadorPartido.getJugador();
                jugadorPartidoCollectionJugadorPartido.setJugador(jugador);
                jugadorPartidoCollectionJugadorPartido = em.merge(jugadorPartidoCollectionJugadorPartido);
                if (oldJugadorOfJugadorPartidoCollectionJugadorPartido != null) {
                    oldJugadorOfJugadorPartidoCollectionJugadorPartido.getJugadorPartidoCollection().remove(jugadorPartidoCollectionJugadorPartido);
                    oldJugadorOfJugadorPartidoCollectionJugadorPartido = em.merge(oldJugadorOfJugadorPartidoCollectionJugadorPartido);
                }
            }
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionJugadorEntrenamiento : jugador.getJugadorEntrenamientoCollection()) {
                Jugador oldJugadorOfJugadorEntrenamientoCollectionJugadorEntrenamiento = jugadorEntrenamientoCollectionJugadorEntrenamiento.getJugador();
                jugadorEntrenamientoCollectionJugadorEntrenamiento.setJugador(jugador);
                jugadorEntrenamientoCollectionJugadorEntrenamiento = em.merge(jugadorEntrenamientoCollectionJugadorEntrenamiento);
                if (oldJugadorOfJugadorEntrenamientoCollectionJugadorEntrenamiento != null) {
                    oldJugadorOfJugadorEntrenamientoCollectionJugadorEntrenamiento.getJugadorEntrenamientoCollection().remove(jugadorEntrenamientoCollectionJugadorEntrenamiento);
                    oldJugadorOfJugadorEntrenamientoCollectionJugadorEntrenamiento = em.merge(oldJugadorOfJugadorEntrenamientoCollectionJugadorEntrenamiento);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Jugador jugador) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Jugador persistentJugador = em.find(Jugador.class, jugador.getIdJugador());
            Cliente tutorLegalOld = persistentJugador.getTutorLegal();
            Cliente tutorLegalNew = jugador.getTutorLegal();
            Collection<EquipoJugador> equipoJugadorCollectionOld = persistentJugador.getEquipoJugadorCollection();
            Collection<EquipoJugador> equipoJugadorCollectionNew = jugador.getEquipoJugadorCollection();
            Collection<JugadorPartido> jugadorPartidoCollectionOld = persistentJugador.getJugadorPartidoCollection();
            Collection<JugadorPartido> jugadorPartidoCollectionNew = jugador.getJugadorPartidoCollection();
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionOld = persistentJugador.getJugadorEntrenamientoCollection();
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionNew = jugador.getJugadorEntrenamientoCollection();
            List<String> illegalOrphanMessages = null;
            if (tutorLegalNew != null && !tutorLegalNew.equals(tutorLegalOld)) {
                Jugador oldJugadorOfTutorLegal = tutorLegalNew.getJugador();
                if (oldJugadorOfTutorLegal != null) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("The Cliente " + tutorLegalNew + " already has an item of type Jugador whose tutorLegal column cannot be null. Please make another selection for the tutorLegal field.");
                }
            }
            for (EquipoJugador equipoJugadorCollectionOldEquipoJugador : equipoJugadorCollectionOld) {
                if (!equipoJugadorCollectionNew.contains(equipoJugadorCollectionOldEquipoJugador)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain EquipoJugador " + equipoJugadorCollectionOldEquipoJugador + " since its jugador field is not nullable.");
                }
            }
            for (JugadorPartido jugadorPartidoCollectionOldJugadorPartido : jugadorPartidoCollectionOld) {
                if (!jugadorPartidoCollectionNew.contains(jugadorPartidoCollectionOldJugadorPartido)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain JugadorPartido " + jugadorPartidoCollectionOldJugadorPartido + " since its jugador field is not nullable.");
                }
            }
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionOldJugadorEntrenamiento : jugadorEntrenamientoCollectionOld) {
                if (!jugadorEntrenamientoCollectionNew.contains(jugadorEntrenamientoCollectionOldJugadorEntrenamiento)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain JugadorEntrenamiento " + jugadorEntrenamientoCollectionOldJugadorEntrenamiento + " since its jugador field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (tutorLegalNew != null) {
                tutorLegalNew = em.getReference(tutorLegalNew.getClass(), tutorLegalNew.getNombreUsuario());
                jugador.setTutorLegal(tutorLegalNew);
            }
            Collection<EquipoJugador> attachedEquipoJugadorCollectionNew = new ArrayList<EquipoJugador>();
            for (EquipoJugador equipoJugadorCollectionNewEquipoJugadorToAttach : equipoJugadorCollectionNew) {
                equipoJugadorCollectionNewEquipoJugadorToAttach = em.getReference(equipoJugadorCollectionNewEquipoJugadorToAttach.getClass(), equipoJugadorCollectionNewEquipoJugadorToAttach.getId());
                attachedEquipoJugadorCollectionNew.add(equipoJugadorCollectionNewEquipoJugadorToAttach);
            }
            equipoJugadorCollectionNew = attachedEquipoJugadorCollectionNew;
            jugador.setEquipoJugadorCollection(equipoJugadorCollectionNew);
            Collection<JugadorPartido> attachedJugadorPartidoCollectionNew = new ArrayList<JugadorPartido>();
            for (JugadorPartido jugadorPartidoCollectionNewJugadorPartidoToAttach : jugadorPartidoCollectionNew) {
                jugadorPartidoCollectionNewJugadorPartidoToAttach = em.getReference(jugadorPartidoCollectionNewJugadorPartidoToAttach.getClass(), jugadorPartidoCollectionNewJugadorPartidoToAttach.getId());
                attachedJugadorPartidoCollectionNew.add(jugadorPartidoCollectionNewJugadorPartidoToAttach);
            }
            jugadorPartidoCollectionNew = attachedJugadorPartidoCollectionNew;
            jugador.setJugadorPartidoCollection(jugadorPartidoCollectionNew);
            Collection<JugadorEntrenamiento> attachedJugadorEntrenamientoCollectionNew = new ArrayList<JugadorEntrenamiento>();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach : jugadorEntrenamientoCollectionNew) {
                jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach = em.getReference(jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach.getClass(), jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach.getId());
                attachedJugadorEntrenamientoCollectionNew.add(jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach);
            }
            jugadorEntrenamientoCollectionNew = attachedJugadorEntrenamientoCollectionNew;
            jugador.setJugadorEntrenamientoCollection(jugadorEntrenamientoCollectionNew);
            jugador = em.merge(jugador);
            if (tutorLegalOld != null && !tutorLegalOld.equals(tutorLegalNew)) {
                tutorLegalOld.setJugador(null);
                tutorLegalOld = em.merge(tutorLegalOld);
            }
            if (tutorLegalNew != null && !tutorLegalNew.equals(tutorLegalOld)) {
                tutorLegalNew.setJugador(jugador);
                tutorLegalNew = em.merge(tutorLegalNew);
            }
            for (EquipoJugador equipoJugadorCollectionNewEquipoJugador : equipoJugadorCollectionNew) {
                if (!equipoJugadorCollectionOld.contains(equipoJugadorCollectionNewEquipoJugador)) {
                    Jugador oldJugadorOfEquipoJugadorCollectionNewEquipoJugador = equipoJugadorCollectionNewEquipoJugador.getJugador();
                    equipoJugadorCollectionNewEquipoJugador.setJugador(jugador);
                    equipoJugadorCollectionNewEquipoJugador = em.merge(equipoJugadorCollectionNewEquipoJugador);
                    if (oldJugadorOfEquipoJugadorCollectionNewEquipoJugador != null && !oldJugadorOfEquipoJugadorCollectionNewEquipoJugador.equals(jugador)) {
                        oldJugadorOfEquipoJugadorCollectionNewEquipoJugador.getEquipoJugadorCollection().remove(equipoJugadorCollectionNewEquipoJugador);
                        oldJugadorOfEquipoJugadorCollectionNewEquipoJugador = em.merge(oldJugadorOfEquipoJugadorCollectionNewEquipoJugador);
                    }
                }
            }
            for (JugadorPartido jugadorPartidoCollectionNewJugadorPartido : jugadorPartidoCollectionNew) {
                if (!jugadorPartidoCollectionOld.contains(jugadorPartidoCollectionNewJugadorPartido)) {
                    Jugador oldJugadorOfJugadorPartidoCollectionNewJugadorPartido = jugadorPartidoCollectionNewJugadorPartido.getJugador();
                    jugadorPartidoCollectionNewJugadorPartido.setJugador(jugador);
                    jugadorPartidoCollectionNewJugadorPartido = em.merge(jugadorPartidoCollectionNewJugadorPartido);
                    if (oldJugadorOfJugadorPartidoCollectionNewJugadorPartido != null && !oldJugadorOfJugadorPartidoCollectionNewJugadorPartido.equals(jugador)) {
                        oldJugadorOfJugadorPartidoCollectionNewJugadorPartido.getJugadorPartidoCollection().remove(jugadorPartidoCollectionNewJugadorPartido);
                        oldJugadorOfJugadorPartidoCollectionNewJugadorPartido = em.merge(oldJugadorOfJugadorPartidoCollectionNewJugadorPartido);
                    }
                }
            }
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionNewJugadorEntrenamiento : jugadorEntrenamientoCollectionNew) {
                if (!jugadorEntrenamientoCollectionOld.contains(jugadorEntrenamientoCollectionNewJugadorEntrenamiento)) {
                    Jugador oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento = jugadorEntrenamientoCollectionNewJugadorEntrenamiento.getJugador();
                    jugadorEntrenamientoCollectionNewJugadorEntrenamiento.setJugador(jugador);
                    jugadorEntrenamientoCollectionNewJugadorEntrenamiento = em.merge(jugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                    if (oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento != null && !oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento.equals(jugador)) {
                        oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento.getJugadorEntrenamientoCollection().remove(jugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                        oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento = em.merge(oldJugadorOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = jugador.getIdJugador();
                if (findJugador(id) == null) {
                    throw new NonexistentEntityException("The jugador with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Jugador jugador;
            try {
                jugador = em.getReference(Jugador.class, id);
                jugador.getIdJugador();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The jugador with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<EquipoJugador> equipoJugadorCollectionOrphanCheck = jugador.getEquipoJugadorCollection();
            for (EquipoJugador equipoJugadorCollectionOrphanCheckEquipoJugador : equipoJugadorCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the EquipoJugador " + equipoJugadorCollectionOrphanCheckEquipoJugador + " in its equipoJugadorCollection field has a non-nullable jugador field.");
            }
            Collection<JugadorPartido> jugadorPartidoCollectionOrphanCheck = jugador.getJugadorPartidoCollection();
            for (JugadorPartido jugadorPartidoCollectionOrphanCheckJugadorPartido : jugadorPartidoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the JugadorPartido " + jugadorPartidoCollectionOrphanCheckJugadorPartido + " in its jugadorPartidoCollection field has a non-nullable jugador field.");
            }
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionOrphanCheck = jugador.getJugadorEntrenamientoCollection();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionOrphanCheckJugadorEntrenamiento : jugadorEntrenamientoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the JugadorEntrenamiento " + jugadorEntrenamientoCollectionOrphanCheckJugadorEntrenamiento + " in its jugadorEntrenamientoCollection field has a non-nullable jugador field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Cliente tutorLegal = jugador.getTutorLegal();
            if (tutorLegal != null) {
                tutorLegal.setJugador(null);
                tutorLegal = em.merge(tutorLegal);
            }
            em.remove(jugador);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Jugador> findJugadorEntities() {
        return findJugadorEntities(true, -1, -1);
    }

    public List<Jugador> findJugadorEntities(int maxResults, int firstResult) {
        return findJugadorEntities(false, maxResults, firstResult);
    }

    private List<Jugador> findJugadorEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Jugador.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Jugador findJugador(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Jugador.class, id);
        } finally {
            em.close();
        }
    }

    public int getJugadorCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Jugador> rt = cq.from(Jugador.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
