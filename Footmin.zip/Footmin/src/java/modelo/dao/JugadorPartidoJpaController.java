/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.JugadorPartido;
import modelo.entidades.Partido;

/**
 *
 * @author adrian
 */
public class JugadorPartidoJpaController implements Serializable {

    public JugadorPartidoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(JugadorPartido jugadorPartido) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Partido partido = jugadorPartido.getPartido();
            if (partido != null) {
                partido = em.getReference(partido.getClass(), partido.getIdPartido());
                jugadorPartido.setPartido(partido);
            }
            em.persist(jugadorPartido);
            if (partido != null) {
                partido.getJugadorPartidoCollection().add(jugadorPartido);
                partido = em.merge(partido);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findJugadorPartido(jugadorPartido.getId()) != null) {
                throw new PreexistingEntityException("JugadorPartido " + jugadorPartido + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(JugadorPartido jugadorPartido) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            JugadorPartido persistentJugadorPartido = em.find(JugadorPartido.class, jugadorPartido.getId());
            Partido partidoOld = persistentJugadorPartido.getPartido();
            Partido partidoNew = jugadorPartido.getPartido();
            if (partidoNew != null) {
                partidoNew = em.getReference(partidoNew.getClass(), partidoNew.getIdPartido());
                jugadorPartido.setPartido(partidoNew);
            }
            jugadorPartido = em.merge(jugadorPartido);
            if (partidoOld != null && !partidoOld.equals(partidoNew)) {
                partidoOld.getJugadorPartidoCollection().remove(jugadorPartido);
                partidoOld = em.merge(partidoOld);
            }
            if (partidoNew != null && !partidoNew.equals(partidoOld)) {
                partidoNew.getJugadorPartidoCollection().add(jugadorPartido);
                partidoNew = em.merge(partidoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = jugadorPartido.getId();
                if (findJugadorPartido(id) == null) {
                    throw new NonexistentEntityException("The jugadorPartido with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            JugadorPartido jugadorPartido;
            try {
                jugadorPartido = em.getReference(JugadorPartido.class, id);
                jugadorPartido.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The jugadorPartido with id " + id + " no longer exists.", enfe);
            }
            Partido partido = jugadorPartido.getPartido();
            if (partido != null) {
                partido.getJugadorPartidoCollection().remove(jugadorPartido);
                partido = em.merge(partido);
            }
            em.remove(jugadorPartido);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<JugadorPartido> findJugadorPartidoEntities() {
        return findJugadorPartidoEntities(true, -1, -1);
    }

    public List<JugadorPartido> findJugadorPartidoEntities(int maxResults, int firstResult) {
        return findJugadorPartidoEntities(false, maxResults, firstResult);
    }

    private List<JugadorPartido> findJugadorPartidoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(JugadorPartido.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public JugadorPartido findJugadorPartido(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(JugadorPartido.class, id);
        } finally {
            em.close();
        }
    }

    public int getJugadorPartidoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<JugadorPartido> rt = cq.from(JugadorPartido.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
