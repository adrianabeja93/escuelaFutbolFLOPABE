/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Club;
import modelo.entidades.Cliente;
import modelo.entidades.ClienteClub;

/**
 *
 * @author adrian
 */
public class ClienteClubJpaController implements Serializable {

    public ClienteClubJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ClienteClub clienteClub) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Club club = clienteClub.getClub();
            if (club != null) {
                club = em.getReference(club.getClass(), club.getIdClub());
                clienteClub.setClub(club);
            }
            Cliente usuario = clienteClub.getUsuario();
            if (usuario != null) {
                usuario = em.getReference(usuario.getClass(), usuario.getNombreUsuario());
                clienteClub.setUsuario(usuario);
            }
            em.persist(clienteClub);
            if (club != null) {
                club.getClienteClubCollection().add(clienteClub);
                club = em.merge(club);
            }
            if (usuario != null) {
                usuario.getClienteClubCollection().add(clienteClub);
                usuario = em.merge(usuario);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ClienteClub clienteClub) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ClienteClub persistentClienteClub = em.find(ClienteClub.class, clienteClub.getId());
            Club clubOld = persistentClienteClub.getClub();
            Club clubNew = clienteClub.getClub();
            Cliente usuarioOld = persistentClienteClub.getUsuario();
            Cliente usuarioNew = clienteClub.getUsuario();
            if (clubNew != null) {
                clubNew = em.getReference(clubNew.getClass(), clubNew.getIdClub());
                clienteClub.setClub(clubNew);
            }
            if (usuarioNew != null) {
                usuarioNew = em.getReference(usuarioNew.getClass(), usuarioNew.getNombreUsuario());
                clienteClub.setUsuario(usuarioNew);
            }
            clienteClub = em.merge(clienteClub);
            if (clubOld != null && !clubOld.equals(clubNew)) {
                clubOld.getClienteClubCollection().remove(clienteClub);
                clubOld = em.merge(clubOld);
            }
            if (clubNew != null && !clubNew.equals(clubOld)) {
                clubNew.getClienteClubCollection().add(clienteClub);
                clubNew = em.merge(clubNew);
            }
            if (usuarioOld != null && !usuarioOld.equals(usuarioNew)) {
                usuarioOld.getClienteClubCollection().remove(clienteClub);
                usuarioOld = em.merge(usuarioOld);
            }
            if (usuarioNew != null && !usuarioNew.equals(usuarioOld)) {
                usuarioNew.getClienteClubCollection().add(clienteClub);
                usuarioNew = em.merge(usuarioNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = clienteClub.getId();
                if (findClienteClub(id) == null) {
                    throw new NonexistentEntityException("The clienteClub with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ClienteClub clienteClub;
            try {
                clienteClub = em.getReference(ClienteClub.class, id);
                clienteClub.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The clienteClub with id " + id + " no longer exists.", enfe);
            }
            Club club = clienteClub.getClub();
            if (club != null) {
                club.getClienteClubCollection().remove(clienteClub);
                club = em.merge(club);
            }
            Cliente usuario = clienteClub.getUsuario();
            if (usuario != null) {
                usuario.getClienteClubCollection().remove(clienteClub);
                usuario = em.merge(usuario);
            }
            em.remove(clienteClub);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ClienteClub> findClienteClubEntities() {
        return findClienteClubEntities(true, -1, -1);
    }

    public List<ClienteClub> findClienteClubEntities(int maxResults, int firstResult) {
        return findClienteClubEntities(false, maxResults, firstResult);
    }

    private List<ClienteClub> findClienteClubEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ClienteClub.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ClienteClub findClienteClub(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ClienteClub.class, id);
        } finally {
            em.close();
        }
    }

    public int getClienteClubCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ClienteClub> rt = cq.from(ClienteClub.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
