/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.JugadorPartido;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Partido;

/**
 *
 * @author adrian
 */
public class PartidoJpaController implements Serializable {

    public PartidoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Partido partido) throws RollbackFailureException, Exception {
        if (partido.getJugadorPartidoCollection() == null) {
            partido.setJugadorPartidoCollection(new ArrayList<JugadorPartido>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<JugadorPartido> attachedJugadorPartidoCollection = new ArrayList<JugadorPartido>();
            for (JugadorPartido jugadorPartidoCollectionJugadorPartidoToAttach : partido.getJugadorPartidoCollection()) {
                jugadorPartidoCollectionJugadorPartidoToAttach = em.getReference(jugadorPartidoCollectionJugadorPartidoToAttach.getClass(), jugadorPartidoCollectionJugadorPartidoToAttach.getId());
                attachedJugadorPartidoCollection.add(jugadorPartidoCollectionJugadorPartidoToAttach);
            }
            partido.setJugadorPartidoCollection(attachedJugadorPartidoCollection);
            em.persist(partido);
            for (JugadorPartido jugadorPartidoCollectionJugadorPartido : partido.getJugadorPartidoCollection()) {
                Partido oldPartidoOfJugadorPartidoCollectionJugadorPartido = jugadorPartidoCollectionJugadorPartido.getPartido();
                jugadorPartidoCollectionJugadorPartido.setPartido(partido);
                jugadorPartidoCollectionJugadorPartido = em.merge(jugadorPartidoCollectionJugadorPartido);
                if (oldPartidoOfJugadorPartidoCollectionJugadorPartido != null) {
                    oldPartidoOfJugadorPartidoCollectionJugadorPartido.getJugadorPartidoCollection().remove(jugadorPartidoCollectionJugadorPartido);
                    oldPartidoOfJugadorPartidoCollectionJugadorPartido = em.merge(oldPartidoOfJugadorPartidoCollectionJugadorPartido);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Partido partido) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Partido persistentPartido = em.find(Partido.class, partido.getIdPartido());
            Collection<JugadorPartido> jugadorPartidoCollectionOld = persistentPartido.getJugadorPartidoCollection();
            Collection<JugadorPartido> jugadorPartidoCollectionNew = partido.getJugadorPartidoCollection();
            List<String> illegalOrphanMessages = null;
            for (JugadorPartido jugadorPartidoCollectionOldJugadorPartido : jugadorPartidoCollectionOld) {
                if (!jugadorPartidoCollectionNew.contains(jugadorPartidoCollectionOldJugadorPartido)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain JugadorPartido " + jugadorPartidoCollectionOldJugadorPartido + " since its partido field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<JugadorPartido> attachedJugadorPartidoCollectionNew = new ArrayList<JugadorPartido>();
            for (JugadorPartido jugadorPartidoCollectionNewJugadorPartidoToAttach : jugadorPartidoCollectionNew) {
                jugadorPartidoCollectionNewJugadorPartidoToAttach = em.getReference(jugadorPartidoCollectionNewJugadorPartidoToAttach.getClass(), jugadorPartidoCollectionNewJugadorPartidoToAttach.getId());
                attachedJugadorPartidoCollectionNew.add(jugadorPartidoCollectionNewJugadorPartidoToAttach);
            }
            jugadorPartidoCollectionNew = attachedJugadorPartidoCollectionNew;
            partido.setJugadorPartidoCollection(jugadorPartidoCollectionNew);
            partido = em.merge(partido);
            for (JugadorPartido jugadorPartidoCollectionNewJugadorPartido : jugadorPartidoCollectionNew) {
                if (!jugadorPartidoCollectionOld.contains(jugadorPartidoCollectionNewJugadorPartido)) {
                    Partido oldPartidoOfJugadorPartidoCollectionNewJugadorPartido = jugadorPartidoCollectionNewJugadorPartido.getPartido();
                    jugadorPartidoCollectionNewJugadorPartido.setPartido(partido);
                    jugadorPartidoCollectionNewJugadorPartido = em.merge(jugadorPartidoCollectionNewJugadorPartido);
                    if (oldPartidoOfJugadorPartidoCollectionNewJugadorPartido != null && !oldPartidoOfJugadorPartidoCollectionNewJugadorPartido.equals(partido)) {
                        oldPartidoOfJugadorPartidoCollectionNewJugadorPartido.getJugadorPartidoCollection().remove(jugadorPartidoCollectionNewJugadorPartido);
                        oldPartidoOfJugadorPartidoCollectionNewJugadorPartido = em.merge(oldPartidoOfJugadorPartidoCollectionNewJugadorPartido);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = partido.getIdPartido();
                if (findPartido(id) == null) {
                    throw new NonexistentEntityException("The partido with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Partido partido;
            try {
                partido = em.getReference(Partido.class, id);
                partido.getIdPartido();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The partido with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<JugadorPartido> jugadorPartidoCollectionOrphanCheck = partido.getJugadorPartidoCollection();
            for (JugadorPartido jugadorPartidoCollectionOrphanCheckJugadorPartido : jugadorPartidoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Partido (" + partido + ") cannot be destroyed since the JugadorPartido " + jugadorPartidoCollectionOrphanCheckJugadorPartido + " in its jugadorPartidoCollection field has a non-nullable partido field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(partido);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Partido> findPartidoEntities() {
        return findPartidoEntities(true, -1, -1);
    }

    public List<Partido> findPartidoEntities(int maxResults, int firstResult) {
        return findPartidoEntities(false, maxResults, firstResult);
    }

    private List<Partido> findPartidoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Partido.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Partido findPartido(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Partido.class, id);
        } finally {
            em.close();
        }
    }

    public int getPartidoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Partido> rt = cq.from(Partido.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
