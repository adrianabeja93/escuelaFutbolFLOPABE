/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.JugadorEntrenamiento;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Entrenamiento;

/**
 *
 * @author adrian
 */
public class EntrenamientoJpaController implements Serializable {

    public EntrenamientoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Entrenamiento entrenamiento) throws RollbackFailureException, Exception {
        if (entrenamiento.getJugadorEntrenamientoCollection() == null) {
            entrenamiento.setJugadorEntrenamientoCollection(new ArrayList<JugadorEntrenamiento>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<JugadorEntrenamiento> attachedJugadorEntrenamientoCollection = new ArrayList<JugadorEntrenamiento>();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach : entrenamiento.getJugadorEntrenamientoCollection()) {
                jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach = em.getReference(jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach.getClass(), jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach.getId());
                attachedJugadorEntrenamientoCollection.add(jugadorEntrenamientoCollectionJugadorEntrenamientoToAttach);
            }
            entrenamiento.setJugadorEntrenamientoCollection(attachedJugadorEntrenamientoCollection);
            em.persist(entrenamiento);
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionJugadorEntrenamiento : entrenamiento.getJugadorEntrenamientoCollection()) {
                Entrenamiento oldEntrenamientoOfJugadorEntrenamientoCollectionJugadorEntrenamiento = jugadorEntrenamientoCollectionJugadorEntrenamiento.getEntrenamiento();
                jugadorEntrenamientoCollectionJugadorEntrenamiento.setEntrenamiento(entrenamiento);
                jugadorEntrenamientoCollectionJugadorEntrenamiento = em.merge(jugadorEntrenamientoCollectionJugadorEntrenamiento);
                if (oldEntrenamientoOfJugadorEntrenamientoCollectionJugadorEntrenamiento != null) {
                    oldEntrenamientoOfJugadorEntrenamientoCollectionJugadorEntrenamiento.getJugadorEntrenamientoCollection().remove(jugadorEntrenamientoCollectionJugadorEntrenamiento);
                    oldEntrenamientoOfJugadorEntrenamientoCollectionJugadorEntrenamiento = em.merge(oldEntrenamientoOfJugadorEntrenamientoCollectionJugadorEntrenamiento);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Entrenamiento entrenamiento) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Entrenamiento persistentEntrenamiento = em.find(Entrenamiento.class, entrenamiento.getIdEntrenamiento());
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionOld = persistentEntrenamiento.getJugadorEntrenamientoCollection();
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionNew = entrenamiento.getJugadorEntrenamientoCollection();
            List<String> illegalOrphanMessages = null;
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionOldJugadorEntrenamiento : jugadorEntrenamientoCollectionOld) {
                if (!jugadorEntrenamientoCollectionNew.contains(jugadorEntrenamientoCollectionOldJugadorEntrenamiento)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain JugadorEntrenamiento " + jugadorEntrenamientoCollectionOldJugadorEntrenamiento + " since its entrenamiento field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<JugadorEntrenamiento> attachedJugadorEntrenamientoCollectionNew = new ArrayList<JugadorEntrenamiento>();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach : jugadorEntrenamientoCollectionNew) {
                jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach = em.getReference(jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach.getClass(), jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach.getId());
                attachedJugadorEntrenamientoCollectionNew.add(jugadorEntrenamientoCollectionNewJugadorEntrenamientoToAttach);
            }
            jugadorEntrenamientoCollectionNew = attachedJugadorEntrenamientoCollectionNew;
            entrenamiento.setJugadorEntrenamientoCollection(jugadorEntrenamientoCollectionNew);
            entrenamiento = em.merge(entrenamiento);
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionNewJugadorEntrenamiento : jugadorEntrenamientoCollectionNew) {
                if (!jugadorEntrenamientoCollectionOld.contains(jugadorEntrenamientoCollectionNewJugadorEntrenamiento)) {
                    Entrenamiento oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento = jugadorEntrenamientoCollectionNewJugadorEntrenamiento.getEntrenamiento();
                    jugadorEntrenamientoCollectionNewJugadorEntrenamiento.setEntrenamiento(entrenamiento);
                    jugadorEntrenamientoCollectionNewJugadorEntrenamiento = em.merge(jugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                    if (oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento != null && !oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento.equals(entrenamiento)) {
                        oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento.getJugadorEntrenamientoCollection().remove(jugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                        oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento = em.merge(oldEntrenamientoOfJugadorEntrenamientoCollectionNewJugadorEntrenamiento);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = entrenamiento.getIdEntrenamiento();
                if (findEntrenamiento(id) == null) {
                    throw new NonexistentEntityException("The entrenamiento with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Entrenamiento entrenamiento;
            try {
                entrenamiento = em.getReference(Entrenamiento.class, id);
                entrenamiento.getIdEntrenamiento();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The entrenamiento with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<JugadorEntrenamiento> jugadorEntrenamientoCollectionOrphanCheck = entrenamiento.getJugadorEntrenamientoCollection();
            for (JugadorEntrenamiento jugadorEntrenamientoCollectionOrphanCheckJugadorEntrenamiento : jugadorEntrenamientoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Entrenamiento (" + entrenamiento + ") cannot be destroyed since the JugadorEntrenamiento " + jugadorEntrenamientoCollectionOrphanCheckJugadorEntrenamiento + " in its jugadorEntrenamientoCollection field has a non-nullable entrenamiento field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(entrenamiento);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Entrenamiento> findEntrenamientoEntities() {
        return findEntrenamientoEntities(true, -1, -1);
    }

    public List<Entrenamiento> findEntrenamientoEntities(int maxResults, int firstResult) {
        return findEntrenamientoEntities(false, maxResults, firstResult);
    }

    private List<Entrenamiento> findEntrenamientoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Entrenamiento.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Entrenamiento findEntrenamiento(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Entrenamiento.class, id);
        } finally {
            em.close();
        }
    }

    public int getEntrenamientoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Entrenamiento> rt = cq.from(Entrenamiento.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
