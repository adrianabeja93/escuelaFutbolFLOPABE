/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.Jugador;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Cliente;
import modelo.entidades.ClienteClub;

/**
 *
 * @author adrian
 */
public class ClienteJpaController implements Serializable {

    public ClienteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cliente cliente) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (cliente.getJugadorCollection() == null) {
            cliente.setJugadorCollection(new ArrayList<Jugador>());
        }
        if (cliente.getClienteClubCollection() == null) {
            cliente.setClienteClubCollection(new ArrayList<ClienteClub>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Jugador> attachedJugadorCollection = new ArrayList<Jugador>();
            for (Jugador jugadorCollectionJugadorToAttach : cliente.getJugadorCollection()) {
                jugadorCollectionJugadorToAttach = em.getReference(jugadorCollectionJugadorToAttach.getClass(), jugadorCollectionJugadorToAttach.getIdJugador());
                attachedJugadorCollection.add(jugadorCollectionJugadorToAttach);
            }
            cliente.setJugadorCollection(attachedJugadorCollection);
            Collection<ClienteClub> attachedClienteClubCollection = new ArrayList<ClienteClub>();
            for (ClienteClub clienteClubCollectionClienteClubToAttach : cliente.getClienteClubCollection()) {
                clienteClubCollectionClienteClubToAttach = em.getReference(clienteClubCollectionClienteClubToAttach.getClass(), clienteClubCollectionClienteClubToAttach.getId());
                attachedClienteClubCollection.add(clienteClubCollectionClienteClubToAttach);
            }
            cliente.setClienteClubCollection(attachedClienteClubCollection);
            em.persist(cliente);
            for (Jugador jugadorCollectionJugador : cliente.getJugadorCollection()) {
                Cliente oldTutorLegalOfJugadorCollectionJugador = jugadorCollectionJugador.getTutorLegal();
                jugadorCollectionJugador.setTutorLegal(cliente);
                jugadorCollectionJugador = em.merge(jugadorCollectionJugador);
                if (oldTutorLegalOfJugadorCollectionJugador != null) {
                    oldTutorLegalOfJugadorCollectionJugador.getJugadorCollection().remove(jugadorCollectionJugador);
                    oldTutorLegalOfJugadorCollectionJugador = em.merge(oldTutorLegalOfJugadorCollectionJugador);
                }
            }
            for (ClienteClub clienteClubCollectionClienteClub : cliente.getClienteClubCollection()) {
                Cliente oldUsuarioOfClienteClubCollectionClienteClub = clienteClubCollectionClienteClub.getUsuario();
                clienteClubCollectionClienteClub.setUsuario(cliente);
                clienteClubCollectionClienteClub = em.merge(clienteClubCollectionClienteClub);
                if (oldUsuarioOfClienteClubCollectionClienteClub != null) {
                    oldUsuarioOfClienteClubCollectionClienteClub.getClienteClubCollection().remove(clienteClubCollectionClienteClub);
                    oldUsuarioOfClienteClubCollectionClienteClub = em.merge(oldUsuarioOfClienteClubCollectionClienteClub);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findCliente(cliente.getNombreUsuario()) != null) {
                throw new PreexistingEntityException("Cliente " + cliente + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cliente cliente) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente persistentCliente = em.find(Cliente.class, cliente.getNombreUsuario());
            Collection<Jugador> jugadorCollectionOld = persistentCliente.getJugadorCollection();
            Collection<Jugador> jugadorCollectionNew = cliente.getJugadorCollection();
            Collection<ClienteClub> clienteClubCollectionOld = persistentCliente.getClienteClubCollection();
            Collection<ClienteClub> clienteClubCollectionNew = cliente.getClienteClubCollection();
            List<String> illegalOrphanMessages = null;
            for (Jugador jugadorCollectionOldJugador : jugadorCollectionOld) {
                if (!jugadorCollectionNew.contains(jugadorCollectionOldJugador)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Jugador " + jugadorCollectionOldJugador + " since its tutorLegal field is not nullable.");
                }
            }
            for (ClienteClub clienteClubCollectionOldClienteClub : clienteClubCollectionOld) {
                if (!clienteClubCollectionNew.contains(clienteClubCollectionOldClienteClub)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ClienteClub " + clienteClubCollectionOldClienteClub + " since its usuario field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Jugador> attachedJugadorCollectionNew = new ArrayList<Jugador>();
            for (Jugador jugadorCollectionNewJugadorToAttach : jugadorCollectionNew) {
                jugadorCollectionNewJugadorToAttach = em.getReference(jugadorCollectionNewJugadorToAttach.getClass(), jugadorCollectionNewJugadorToAttach.getIdJugador());
                attachedJugadorCollectionNew.add(jugadorCollectionNewJugadorToAttach);
            }
            jugadorCollectionNew = attachedJugadorCollectionNew;
            cliente.setJugadorCollection(jugadorCollectionNew);
            Collection<ClienteClub> attachedClienteClubCollectionNew = new ArrayList<ClienteClub>();
            for (ClienteClub clienteClubCollectionNewClienteClubToAttach : clienteClubCollectionNew) {
                clienteClubCollectionNewClienteClubToAttach = em.getReference(clienteClubCollectionNewClienteClubToAttach.getClass(), clienteClubCollectionNewClienteClubToAttach.getId());
                attachedClienteClubCollectionNew.add(clienteClubCollectionNewClienteClubToAttach);
            }
            clienteClubCollectionNew = attachedClienteClubCollectionNew;
            cliente.setClienteClubCollection(clienteClubCollectionNew);
            cliente = em.merge(cliente);
            for (Jugador jugadorCollectionNewJugador : jugadorCollectionNew) {
                if (!jugadorCollectionOld.contains(jugadorCollectionNewJugador)) {
                    Cliente oldTutorLegalOfJugadorCollectionNewJugador = jugadorCollectionNewJugador.getTutorLegal();
                    jugadorCollectionNewJugador.setTutorLegal(cliente);
                    jugadorCollectionNewJugador = em.merge(jugadorCollectionNewJugador);
                    if (oldTutorLegalOfJugadorCollectionNewJugador != null && !oldTutorLegalOfJugadorCollectionNewJugador.equals(cliente)) {
                        oldTutorLegalOfJugadorCollectionNewJugador.getJugadorCollection().remove(jugadorCollectionNewJugador);
                        oldTutorLegalOfJugadorCollectionNewJugador = em.merge(oldTutorLegalOfJugadorCollectionNewJugador);
                    }
                }
            }
            for (ClienteClub clienteClubCollectionNewClienteClub : clienteClubCollectionNew) {
                if (!clienteClubCollectionOld.contains(clienteClubCollectionNewClienteClub)) {
                    Cliente oldUsuarioOfClienteClubCollectionNewClienteClub = clienteClubCollectionNewClienteClub.getUsuario();
                    clienteClubCollectionNewClienteClub.setUsuario(cliente);
                    clienteClubCollectionNewClienteClub = em.merge(clienteClubCollectionNewClienteClub);
                    if (oldUsuarioOfClienteClubCollectionNewClienteClub != null && !oldUsuarioOfClienteClubCollectionNewClienteClub.equals(cliente)) {
                        oldUsuarioOfClienteClubCollectionNewClienteClub.getClienteClubCollection().remove(clienteClubCollectionNewClienteClub);
                        oldUsuarioOfClienteClubCollectionNewClienteClub = em.merge(oldUsuarioOfClienteClubCollectionNewClienteClub);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = cliente.getNombreUsuario();
                if (findCliente(id) == null) {
                    throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
               em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente;
            try {
                cliente = em.getReference(Cliente.class, id);
                cliente.getNombreUsuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Jugador> jugadorCollectionOrphanCheck = cliente.getJugadorCollection();
            for (Jugador jugadorCollectionOrphanCheckJugador : jugadorCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Cliente (" + cliente + ") cannot be destroyed since the Jugador " + jugadorCollectionOrphanCheckJugador + " in its jugadorCollection field has a non-nullable tutorLegal field.");
            }
            Collection<ClienteClub> clienteClubCollectionOrphanCheck = cliente.getClienteClubCollection();
            for (ClienteClub clienteClubCollectionOrphanCheckClienteClub : clienteClubCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Cliente (" + cliente + ") cannot be destroyed since the ClienteClub " + clienteClubCollectionOrphanCheckClienteClub + " in its clienteClubCollection field has a non-nullable usuario field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cliente> findClienteEntities() {
        return findClienteEntities(true, -1, -1);
    }

    public List<Cliente> findClienteEntities(int maxResults, int firstResult) {
        return findClienteEntities(false, maxResults, firstResult);
    }

    private List<Cliente> findClienteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cliente.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cliente findCliente(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    public int getClienteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cliente> rt = cq.from(Cliente.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
