/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import modelo.entidades.ClubEmpleado;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.IllegalOrphanException;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Equipo;
import modelo.entidades.ClienteClub;
import modelo.entidades.Club;

/**
 *
 * @author adrian
 */
public class ClubJpaController implements Serializable {

    public ClubJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Club club) throws RollbackFailureException, Exception {
        if (club.getClubEmpleadoCollection() == null) {
            club.setClubEmpleadoCollection(new ArrayList<ClubEmpleado>());
        }
        if (club.getEquipoCollection() == null) {
            club.setEquipoCollection(new ArrayList<Equipo>());
        }
        if (club.getClienteClubCollection() == null) {
            club.setClienteClubCollection(new ArrayList<ClienteClub>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<ClubEmpleado> attachedClubEmpleadoCollection = new ArrayList<ClubEmpleado>();
            for (ClubEmpleado clubEmpleadoCollectionClubEmpleadoToAttach : club.getClubEmpleadoCollection()) {
                clubEmpleadoCollectionClubEmpleadoToAttach = em.getReference(clubEmpleadoCollectionClubEmpleadoToAttach.getClass(), clubEmpleadoCollectionClubEmpleadoToAttach.getId());
                attachedClubEmpleadoCollection.add(clubEmpleadoCollectionClubEmpleadoToAttach);
            }
            club.setClubEmpleadoCollection(attachedClubEmpleadoCollection);
            Collection<Equipo> attachedEquipoCollection = new ArrayList<Equipo>();
            for (Equipo equipoCollectionEquipoToAttach : club.getEquipoCollection()) {
                equipoCollectionEquipoToAttach = em.getReference(equipoCollectionEquipoToAttach.getClass(), equipoCollectionEquipoToAttach.getIdEquipo());
                attachedEquipoCollection.add(equipoCollectionEquipoToAttach);
            }
            club.setEquipoCollection(attachedEquipoCollection);
            Collection<ClienteClub> attachedClienteClubCollection = new ArrayList<ClienteClub>();
            for (ClienteClub clienteClubCollectionClienteClubToAttach : club.getClienteClubCollection()) {
                clienteClubCollectionClienteClubToAttach = em.getReference(clienteClubCollectionClienteClubToAttach.getClass(), clienteClubCollectionClienteClubToAttach.getId());
                attachedClienteClubCollection.add(clienteClubCollectionClienteClubToAttach);
            }
            club.setClienteClubCollection(attachedClienteClubCollection);
            em.persist(club);
            for (ClubEmpleado clubEmpleadoCollectionClubEmpleado : club.getClubEmpleadoCollection()) {
                Club oldClubOfClubEmpleadoCollectionClubEmpleado = clubEmpleadoCollectionClubEmpleado.getClub();
                clubEmpleadoCollectionClubEmpleado.setClub(club);
                clubEmpleadoCollectionClubEmpleado = em.merge(clubEmpleadoCollectionClubEmpleado);
                if (oldClubOfClubEmpleadoCollectionClubEmpleado != null) {
                    oldClubOfClubEmpleadoCollectionClubEmpleado.getClubEmpleadoCollection().remove(clubEmpleadoCollectionClubEmpleado);
                    oldClubOfClubEmpleadoCollectionClubEmpleado = em.merge(oldClubOfClubEmpleadoCollectionClubEmpleado);
                }
            }
            for (Equipo equipoCollectionEquipo : club.getEquipoCollection()) {
                Club oldClubOfEquipoCollectionEquipo = equipoCollectionEquipo.getClub();
                equipoCollectionEquipo.setClub(club);
                equipoCollectionEquipo = em.merge(equipoCollectionEquipo);
                if (oldClubOfEquipoCollectionEquipo != null) {
                    oldClubOfEquipoCollectionEquipo.getEquipoCollection().remove(equipoCollectionEquipo);
                    oldClubOfEquipoCollectionEquipo = em.merge(oldClubOfEquipoCollectionEquipo);
                }
            }
            for (ClienteClub clienteClubCollectionClienteClub : club.getClienteClubCollection()) {
                Club oldClubOfClienteClubCollectionClienteClub = clienteClubCollectionClienteClub.getClub();
                clienteClubCollectionClienteClub.setClub(club);
                clienteClubCollectionClienteClub = em.merge(clienteClubCollectionClienteClub);
                if (oldClubOfClienteClubCollectionClienteClub != null) {
                    oldClubOfClienteClubCollectionClienteClub.getClienteClubCollection().remove(clienteClubCollectionClienteClub);
                    oldClubOfClienteClubCollectionClienteClub = em.merge(oldClubOfClienteClubCollectionClienteClub);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Club club) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Club persistentClub = em.find(Club.class, club.getIdClub());
            Collection<ClubEmpleado> clubEmpleadoCollectionOld = persistentClub.getClubEmpleadoCollection();
            Collection<ClubEmpleado> clubEmpleadoCollectionNew = club.getClubEmpleadoCollection();
            Collection<Equipo> equipoCollectionOld = persistentClub.getEquipoCollection();
            Collection<Equipo> equipoCollectionNew = club.getEquipoCollection();
            Collection<ClienteClub> clienteClubCollectionOld = persistentClub.getClienteClubCollection();
            Collection<ClienteClub> clienteClubCollectionNew = club.getClienteClubCollection();
            List<String> illegalOrphanMessages = null;
            for (ClubEmpleado clubEmpleadoCollectionOldClubEmpleado : clubEmpleadoCollectionOld) {
                if (!clubEmpleadoCollectionNew.contains(clubEmpleadoCollectionOldClubEmpleado)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ClubEmpleado " + clubEmpleadoCollectionOldClubEmpleado + " since its club field is not nullable.");
                }
            }
            for (Equipo equipoCollectionOldEquipo : equipoCollectionOld) {
                if (!equipoCollectionNew.contains(equipoCollectionOldEquipo)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Equipo " + equipoCollectionOldEquipo + " since its club field is not nullable.");
                }
            }
            for (ClienteClub clienteClubCollectionOldClienteClub : clienteClubCollectionOld) {
                if (!clienteClubCollectionNew.contains(clienteClubCollectionOldClienteClub)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain ClienteClub " + clienteClubCollectionOldClienteClub + " since its club field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<ClubEmpleado> attachedClubEmpleadoCollectionNew = new ArrayList<ClubEmpleado>();
            for (ClubEmpleado clubEmpleadoCollectionNewClubEmpleadoToAttach : clubEmpleadoCollectionNew) {
                clubEmpleadoCollectionNewClubEmpleadoToAttach = em.getReference(clubEmpleadoCollectionNewClubEmpleadoToAttach.getClass(), clubEmpleadoCollectionNewClubEmpleadoToAttach.getId());
                attachedClubEmpleadoCollectionNew.add(clubEmpleadoCollectionNewClubEmpleadoToAttach);
            }
            clubEmpleadoCollectionNew = attachedClubEmpleadoCollectionNew;
            club.setClubEmpleadoCollection(clubEmpleadoCollectionNew);
            Collection<Equipo> attachedEquipoCollectionNew = new ArrayList<Equipo>();
            for (Equipo equipoCollectionNewEquipoToAttach : equipoCollectionNew) {
                equipoCollectionNewEquipoToAttach = em.getReference(equipoCollectionNewEquipoToAttach.getClass(), equipoCollectionNewEquipoToAttach.getIdEquipo());
                attachedEquipoCollectionNew.add(equipoCollectionNewEquipoToAttach);
            }
            equipoCollectionNew = attachedEquipoCollectionNew;
            club.setEquipoCollection(equipoCollectionNew);
            Collection<ClienteClub> attachedClienteClubCollectionNew = new ArrayList<ClienteClub>();
            for (ClienteClub clienteClubCollectionNewClienteClubToAttach : clienteClubCollectionNew) {
                clienteClubCollectionNewClienteClubToAttach = em.getReference(clienteClubCollectionNewClienteClubToAttach.getClass(), clienteClubCollectionNewClienteClubToAttach.getId());
                attachedClienteClubCollectionNew.add(clienteClubCollectionNewClienteClubToAttach);
            }
            clienteClubCollectionNew = attachedClienteClubCollectionNew;
            club.setClienteClubCollection(clienteClubCollectionNew);
            club = em.merge(club);
            for (ClubEmpleado clubEmpleadoCollectionNewClubEmpleado : clubEmpleadoCollectionNew) {
                if (!clubEmpleadoCollectionOld.contains(clubEmpleadoCollectionNewClubEmpleado)) {
                    Club oldClubOfClubEmpleadoCollectionNewClubEmpleado = clubEmpleadoCollectionNewClubEmpleado.getClub();
                    clubEmpleadoCollectionNewClubEmpleado.setClub(club);
                    clubEmpleadoCollectionNewClubEmpleado = em.merge(clubEmpleadoCollectionNewClubEmpleado);
                    if (oldClubOfClubEmpleadoCollectionNewClubEmpleado != null && !oldClubOfClubEmpleadoCollectionNewClubEmpleado.equals(club)) {
                        oldClubOfClubEmpleadoCollectionNewClubEmpleado.getClubEmpleadoCollection().remove(clubEmpleadoCollectionNewClubEmpleado);
                        oldClubOfClubEmpleadoCollectionNewClubEmpleado = em.merge(oldClubOfClubEmpleadoCollectionNewClubEmpleado);
                    }
                }
            }
            for (Equipo equipoCollectionNewEquipo : equipoCollectionNew) {
                if (!equipoCollectionOld.contains(equipoCollectionNewEquipo)) {
                    Club oldClubOfEquipoCollectionNewEquipo = equipoCollectionNewEquipo.getClub();
                    equipoCollectionNewEquipo.setClub(club);
                    equipoCollectionNewEquipo = em.merge(equipoCollectionNewEquipo);
                    if (oldClubOfEquipoCollectionNewEquipo != null && !oldClubOfEquipoCollectionNewEquipo.equals(club)) {
                        oldClubOfEquipoCollectionNewEquipo.getEquipoCollection().remove(equipoCollectionNewEquipo);
                        oldClubOfEquipoCollectionNewEquipo = em.merge(oldClubOfEquipoCollectionNewEquipo);
                    }
                }
            }
            for (ClienteClub clienteClubCollectionNewClienteClub : clienteClubCollectionNew) {
                if (!clienteClubCollectionOld.contains(clienteClubCollectionNewClienteClub)) {
                    Club oldClubOfClienteClubCollectionNewClienteClub = clienteClubCollectionNewClienteClub.getClub();
                    clienteClubCollectionNewClienteClub.setClub(club);
                    clienteClubCollectionNewClienteClub = em.merge(clienteClubCollectionNewClienteClub);
                    if (oldClubOfClienteClubCollectionNewClienteClub != null && !oldClubOfClienteClubCollectionNewClienteClub.equals(club)) {
                        oldClubOfClienteClubCollectionNewClienteClub.getClienteClubCollection().remove(clienteClubCollectionNewClienteClub);
                        oldClubOfClienteClubCollectionNewClienteClub = em.merge(oldClubOfClienteClubCollectionNewClienteClub);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = club.getIdClub();
                if (findClub(id) == null) {
                    throw new NonexistentEntityException("The club with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Club club;
            try {
                club = em.getReference(Club.class, id);
                club.getIdClub();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The club with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<ClubEmpleado> clubEmpleadoCollectionOrphanCheck = club.getClubEmpleadoCollection();
            for (ClubEmpleado clubEmpleadoCollectionOrphanCheckClubEmpleado : clubEmpleadoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Club (" + club + ") cannot be destroyed since the ClubEmpleado " + clubEmpleadoCollectionOrphanCheckClubEmpleado + " in its clubEmpleadoCollection field has a non-nullable club field.");
            }
            Collection<Equipo> equipoCollectionOrphanCheck = club.getEquipoCollection();
            for (Equipo equipoCollectionOrphanCheckEquipo : equipoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Club (" + club + ") cannot be destroyed since the Equipo " + equipoCollectionOrphanCheckEquipo + " in its equipoCollection field has a non-nullable club field.");
            }
            Collection<ClienteClub> clienteClubCollectionOrphanCheck = club.getClienteClubCollection();
            for (ClienteClub clienteClubCollectionOrphanCheckClienteClub : clienteClubCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Club (" + club + ") cannot be destroyed since the ClienteClub " + clienteClubCollectionOrphanCheckClienteClub + " in its clienteClubCollection field has a non-nullable club field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(club);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Club> findClubEntities() {
        return findClubEntities(true, -1, -1);
    }

    public List<Club> findClubEntities(int maxResults, int firstResult) {
        return findClubEntities(false, maxResults, firstResult);
    }

    private List<Club> findClubEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Club.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Club findClub(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Club.class, id);
        } finally {
            em.close();
        }
    }

    public int getClubCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Club> rt = cq.from(Club.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
