/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Club;
import modelo.entidades.ClubEmpleado;
import modelo.entidades.Empleado;

/**
 *
 * @author adrian
 */
public class ClubEmpleadoJpaController implements Serializable {

    public ClubEmpleadoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ClubEmpleado clubEmpleado) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Club club = clubEmpleado.getClub();
            if (club != null) {
                club = em.getReference(club.getClass(), club.getIdClub());
                clubEmpleado.setClub(club);
            }
            Empleado empleado = clubEmpleado.getEmpleado();
            if (empleado != null) {
                empleado = em.getReference(empleado.getClass(), empleado.getNombreUsuario());
                clubEmpleado.setEmpleado(empleado);
            }
            em.persist(clubEmpleado);
            if (club != null) {
                club.getClubEmpleadoCollection().add(clubEmpleado);
                club = em.merge(club);
            }
            if (empleado != null) {
                empleado.getClubEmpleadoCollection().add(clubEmpleado);
                empleado = em.merge(empleado);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findClubEmpleado(clubEmpleado.getId()) != null) {
                throw new PreexistingEntityException("ClubEmpleado " + clubEmpleado + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ClubEmpleado clubEmpleado) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ClubEmpleado persistentClubEmpleado = em.find(ClubEmpleado.class, clubEmpleado.getId());
            Club clubOld = persistentClubEmpleado.getClub();
            Club clubNew = clubEmpleado.getClub();
            Empleado empleadoOld = persistentClubEmpleado.getEmpleado();
            Empleado empleadoNew = clubEmpleado.getEmpleado();
            if (clubNew != null) {
                clubNew = em.getReference(clubNew.getClass(), clubNew.getIdClub());
                clubEmpleado.setClub(clubNew);
            }
            if (empleadoNew != null) {
                empleadoNew = em.getReference(empleadoNew.getClass(), empleadoNew.getNombreUsuario());
                clubEmpleado.setEmpleado(empleadoNew);
            }
            clubEmpleado = em.merge(clubEmpleado);
            if (clubOld != null && !clubOld.equals(clubNew)) {
                clubOld.getClubEmpleadoCollection().remove(clubEmpleado);
                clubOld = em.merge(clubOld);
            }
            if (clubNew != null && !clubNew.equals(clubOld)) {
                clubNew.getClubEmpleadoCollection().add(clubEmpleado);
                clubNew = em.merge(clubNew);
            }
            if (empleadoOld != null && !empleadoOld.equals(empleadoNew)) {
                empleadoOld.getClubEmpleadoCollection().remove(clubEmpleado);
                empleadoOld = em.merge(empleadoOld);
            }
            if (empleadoNew != null && !empleadoNew.equals(empleadoOld)) {
                empleadoNew.getClubEmpleadoCollection().add(clubEmpleado);
                empleadoNew = em.merge(empleadoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = clubEmpleado.getId();
                if (findClubEmpleado(id) == null) {
                    throw new NonexistentEntityException("The clubEmpleado with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ClubEmpleado clubEmpleado;
            try {
                clubEmpleado = em.getReference(ClubEmpleado.class, id);
                clubEmpleado.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The clubEmpleado with id " + id + " no longer exists.", enfe);
            }
            Club club = clubEmpleado.getClub();
            if (club != null) {
                club.getClubEmpleadoCollection().remove(clubEmpleado);
                club = em.merge(club);
            }
            Empleado empleado = clubEmpleado.getEmpleado();
            if (empleado != null) {
                empleado.getClubEmpleadoCollection().remove(clubEmpleado);
                empleado = em.merge(empleado);
            }
            em.remove(clubEmpleado);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ClubEmpleado> findClubEmpleadoEntities() {
        return findClubEmpleadoEntities(true, -1, -1);
    }

    public List<ClubEmpleado> findClubEmpleadoEntities(int maxResults, int firstResult) {
        return findClubEmpleadoEntities(false, maxResults, firstResult);
    }

    private List<ClubEmpleado> findClubEmpleadoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ClubEmpleado.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ClubEmpleado findClubEmpleado(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ClubEmpleado.class, id);
        } finally {
            em.close();
        }
    }

    public int getClubEmpleadoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ClubEmpleado> rt = cq.from(ClubEmpleado.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
