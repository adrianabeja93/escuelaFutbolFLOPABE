/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Empleado;
import modelo.entidades.Equipo;
import modelo.entidades.EquipoEmpleado;

/**
 *
 * @author adrian
 */
public class EquipoEmpleadoJpaController implements Serializable {

    public EquipoEmpleadoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(EquipoEmpleado equipoEmpleado) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Empleado empleado = equipoEmpleado.getEmpleado();
            if (empleado != null) {
                empleado = em.getReference(empleado.getClass(), empleado.getNombreUsuario());
                equipoEmpleado.setEmpleado(empleado);
            }
            Equipo equipo = equipoEmpleado.getEquipo();
            if (equipo != null) {
                equipo = em.getReference(equipo.getClass(), equipo.getIdEquipo());
                equipoEmpleado.setEquipo(equipo);
            }
            em.persist(equipoEmpleado);
            if (empleado != null) {
                empleado.getEquipoEmpleadoCollection().add(equipoEmpleado);
                empleado = em.merge(empleado);
            }
            if (equipo != null) {
                equipo.getEquipoEmpleadoCollection().add(equipoEmpleado);
                equipo = em.merge(equipo);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findEquipoEmpleado(equipoEmpleado.getId()) != null) {
                throw new PreexistingEntityException("EquipoEmpleado " + equipoEmpleado + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(EquipoEmpleado equipoEmpleado) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            EquipoEmpleado persistentEquipoEmpleado = em.find(EquipoEmpleado.class, equipoEmpleado.getId());
            Empleado empleadoOld = persistentEquipoEmpleado.getEmpleado();
            Empleado empleadoNew = equipoEmpleado.getEmpleado();
            Equipo equipoOld = persistentEquipoEmpleado.getEquipo();
            Equipo equipoNew = equipoEmpleado.getEquipo();
            if (empleadoNew != null) {
                empleadoNew = em.getReference(empleadoNew.getClass(), empleadoNew.getNombreUsuario());
                equipoEmpleado.setEmpleado(empleadoNew);
            }
            if (equipoNew != null) {
                equipoNew = em.getReference(equipoNew.getClass(), equipoNew.getIdEquipo());
                equipoEmpleado.setEquipo(equipoNew);
            }
            equipoEmpleado = em.merge(equipoEmpleado);
            if (empleadoOld != null && !empleadoOld.equals(empleadoNew)) {
                empleadoOld.getEquipoEmpleadoCollection().remove(equipoEmpleado);
                empleadoOld = em.merge(empleadoOld);
            }
            if (empleadoNew != null && !empleadoNew.equals(empleadoOld)) {
                empleadoNew.getEquipoEmpleadoCollection().add(equipoEmpleado);
                empleadoNew = em.merge(empleadoNew);
            }
            if (equipoOld != null && !equipoOld.equals(equipoNew)) {
                equipoOld.getEquipoEmpleadoCollection().remove(equipoEmpleado);
                equipoOld = em.merge(equipoOld);
            }
            if (equipoNew != null && !equipoNew.equals(equipoOld)) {
                equipoNew.getEquipoEmpleadoCollection().add(equipoEmpleado);
                equipoNew = em.merge(equipoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = equipoEmpleado.getId();
                if (findEquipoEmpleado(id) == null) {
                    throw new NonexistentEntityException("The equipoEmpleado with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            EquipoEmpleado equipoEmpleado;
            try {
                equipoEmpleado = em.getReference(EquipoEmpleado.class, id);
                equipoEmpleado.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The equipoEmpleado with id " + id + " no longer exists.", enfe);
            }
            Empleado empleado = equipoEmpleado.getEmpleado();
            if (empleado != null) {
                empleado.getEquipoEmpleadoCollection().remove(equipoEmpleado);
                empleado = em.merge(empleado);
            }
            Equipo equipo = equipoEmpleado.getEquipo();
            if (equipo != null) {
                equipo.getEquipoEmpleadoCollection().remove(equipoEmpleado);
                equipo = em.merge(equipo);
            }
            em.remove(equipoEmpleado);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<EquipoEmpleado> findEquipoEmpleadoEntities() {
        return findEquipoEmpleadoEntities(true, -1, -1);
    }

    public List<EquipoEmpleado> findEquipoEmpleadoEntities(int maxResults, int firstResult) {
        return findEquipoEmpleadoEntities(false, maxResults, firstResult);
    }

    private List<EquipoEmpleado> findEquipoEmpleadoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(EquipoEmpleado.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public EquipoEmpleado findEquipoEmpleado(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(EquipoEmpleado.class, id);
        } finally {
            em.close();
        }
    }

    public int getEquipoEmpleadoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<EquipoEmpleado> rt = cq.from(EquipoEmpleado.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
