/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.dao;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.UserTransaction;
import modelo.dao.exceptions.NonexistentEntityException;
import modelo.dao.exceptions.PreexistingEntityException;
import modelo.dao.exceptions.RollbackFailureException;
import modelo.entidades.Entrenamiento;
import modelo.entidades.Jugador;
import modelo.entidades.JugadorEntrenamiento;

/**
 *
 * @author adrian
 */
public class JugadorEntrenamientoJpaController implements Serializable {

    public JugadorEntrenamientoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(JugadorEntrenamiento jugadorEntrenamiento) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Entrenamiento entrenamiento = jugadorEntrenamiento.getEntrenamiento();
            if (entrenamiento != null) {
                entrenamiento = em.getReference(entrenamiento.getClass(), entrenamiento.getIdEntrenamiento());
                jugadorEntrenamiento.setEntrenamiento(entrenamiento);
            }
            Jugador jugador = jugadorEntrenamiento.getJugador();
            if (jugador != null) {
                jugador = em.getReference(jugador.getClass(), jugador.getIdJugador());
                jugadorEntrenamiento.setJugador(jugador);
            }
            em.persist(jugadorEntrenamiento);
            if (entrenamiento != null) {
                entrenamiento.getJugadorEntrenamientoCollection().add(jugadorEntrenamiento);
                entrenamiento = em.merge(entrenamiento);
            }
            if (jugador != null) {
                jugador.getJugadorEntrenamientoCollection().add(jugadorEntrenamiento);
                jugador = em.merge(jugador);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findJugadorEntrenamiento(jugadorEntrenamiento.getId()) != null) {
                throw new PreexistingEntityException("JugadorEntrenamiento " + jugadorEntrenamiento + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(JugadorEntrenamiento jugadorEntrenamiento) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            JugadorEntrenamiento persistentJugadorEntrenamiento = em.find(JugadorEntrenamiento.class, jugadorEntrenamiento.getId());
            Entrenamiento entrenamientoOld = persistentJugadorEntrenamiento.getEntrenamiento();
            Entrenamiento entrenamientoNew = jugadorEntrenamiento.getEntrenamiento();
            Jugador jugadorOld = persistentJugadorEntrenamiento.getJugador();
            Jugador jugadorNew = jugadorEntrenamiento.getJugador();
            if (entrenamientoNew != null) {
                entrenamientoNew = em.getReference(entrenamientoNew.getClass(), entrenamientoNew.getIdEntrenamiento());
                jugadorEntrenamiento.setEntrenamiento(entrenamientoNew);
            }
            if (jugadorNew != null) {
                jugadorNew = em.getReference(jugadorNew.getClass(), jugadorNew.getIdJugador());
                jugadorEntrenamiento.setJugador(jugadorNew);
            }
            jugadorEntrenamiento = em.merge(jugadorEntrenamiento);
            if (entrenamientoOld != null && !entrenamientoOld.equals(entrenamientoNew)) {
                entrenamientoOld.getJugadorEntrenamientoCollection().remove(jugadorEntrenamiento);
                entrenamientoOld = em.merge(entrenamientoOld);
            }
            if (entrenamientoNew != null && !entrenamientoNew.equals(entrenamientoOld)) {
                entrenamientoNew.getJugadorEntrenamientoCollection().add(jugadorEntrenamiento);
                entrenamientoNew = em.merge(entrenamientoNew);
            }
            if (jugadorOld != null && !jugadorOld.equals(jugadorNew)) {
                jugadorOld.getJugadorEntrenamientoCollection().remove(jugadorEntrenamiento);
                jugadorOld = em.merge(jugadorOld);
            }
            if (jugadorNew != null && !jugadorNew.equals(jugadorOld)) {
                jugadorNew.getJugadorEntrenamientoCollection().add(jugadorEntrenamiento);
                jugadorNew = em.merge(jugadorNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = jugadorEntrenamiento.getId();
                if (findJugadorEntrenamiento(id) == null) {
                    throw new NonexistentEntityException("The jugadorEntrenamiento with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            JugadorEntrenamiento jugadorEntrenamiento;
            try {
                jugadorEntrenamiento = em.getReference(JugadorEntrenamiento.class, id);
                jugadorEntrenamiento.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The jugadorEntrenamiento with id " + id + " no longer exists.", enfe);
            }
            Entrenamiento entrenamiento = jugadorEntrenamiento.getEntrenamiento();
            if (entrenamiento != null) {
                entrenamiento.getJugadorEntrenamientoCollection().remove(jugadorEntrenamiento);
                entrenamiento = em.merge(entrenamiento);
            }
            Jugador jugador = jugadorEntrenamiento.getJugador();
            if (jugador != null) {
                jugador.getJugadorEntrenamientoCollection().remove(jugadorEntrenamiento);
                jugador = em.merge(jugador);
            }
            em.remove(jugadorEntrenamiento);
            em.getTransaction().commit();
        } catch (Exception ex) {
            try {
                em.getTransaction().rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<JugadorEntrenamiento> findJugadorEntrenamientoEntities() {
        return findJugadorEntrenamientoEntities(true, -1, -1);
    }

    public List<JugadorEntrenamiento> findJugadorEntrenamientoEntities(int maxResults, int firstResult) {
        return findJugadorEntrenamientoEntities(false, maxResults, firstResult);
    }

    private List<JugadorEntrenamiento> findJugadorEntrenamientoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(JugadorEntrenamiento.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public JugadorEntrenamiento findJugadorEntrenamiento(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(JugadorEntrenamiento.class, id);
        } finally {
            em.close();
        }
    }

    public int getJugadorEntrenamientoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<JugadorEntrenamiento> rt = cq.from(JugadorEntrenamiento.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
